public class CricketPlayer

{

  private String name;

  private String teamName;

  private int noOfMatches;

   

  public CricketPlayer(String name,String teamName,int noOfMatches)

  {

    this.name=name;

    this.teamName=teamName;

    this.noOfMatches=noOfMatches;

  }

   

  public String getName()

  {

    return name;

  }

   

  public String getTeamName()

  {

    return teamName;

  }

   

  public int getNoOfMatches()

  {

    return noOfMatches;

  }

}

