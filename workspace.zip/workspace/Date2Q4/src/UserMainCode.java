import java.util.Calendar;

import java.util.Date;

import java.text.SimpleDateFormat;



public class UserMainCode {

	public static void displayTime(String time)throws Exception

	{

		SimpleDateFormat sdf=new SimpleDateFormat("HH:mm:ss");

		Date dat=sdf.parse(time);

		Calendar calendar=Calendar.getInstance();

		calendar.setTime(dat);

		calendar.add(Calendar.HOUR, 2);

		dat=calendar.getTime();

		System.out.println(sdf.format(dat));

	}



}