import java.util.*;

public class Main {

public static void main(String[] args) {

	Scanner sc = new Scanner(System.in);

	Delivery delivery = new Delivery();

	

	System.out.println("Enter the over"); 

	delivery.over = sc.nextLong();

	System.out.println("Enter the ball");

	delivery.ball = sc.nextLong();

	System.out.println("Enter the runs");

	delivery.runs = sc.nextLong();

	sc.nextLine();

	System.out.println("Enter the batsman name");

	delivery.batsman=sc.nextLine();

	System.out.println("Enter the bowler name"); 

	delivery.bowler = sc.nextLine();

	System.out.println("Enter the nonStriker name");

	delivery.nonStriker = sc.nextLine(); 

	delivery.displayDeliveryDetails();

	}

}

