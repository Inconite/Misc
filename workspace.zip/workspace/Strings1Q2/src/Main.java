import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter venue1");
		String a=sc.nextLine();
		System.out.println("Enter venue2");
		String b=sc.nextLine();
		if(a.equalsIgnoreCase(b))
			System.out.println("Both the venues are same.");
		else 
			System.out.println("Both the venues are different.");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
