import java.text.SimpleDateFormat;



import java.util.Calendar;



import java.util.Date;







public class UserMainCode 



{



	public static void displayDate(int a, int b) throws Exception



	{



		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");



		String d = a+"-"+01+"-"+01;



		Date dt = sdf.parse(d);



		Calendar c = Calendar.getInstance();



		c.setTime(dt);



		c.set(Calendar.YEAR, a);



		c.set(Calendar.MONTH, 0);



		c.set(Calendar.DATE, 0);



		c.add(Calendar.DATE, b);



		dt = c.getTime();



		System.out.println(+b+"th day of "+a+" : "+sdf.format(dt));



	}



}