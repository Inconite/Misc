import java.util.*;

public class Main {

public static void main(String arag[]){

	Scanner sc=new Scanner(System.in);

	int n,sum=0,i;

	n=sc.nextInt();

	sc.nextLine();

	ArrayList<String> ve=new ArrayList<String>();

	

	for(i=0;i<n;i++){

		ve.add(sc.nextLine());

		

	}

	String s=sc.nextLine();

	Iterator it=ve.iterator();

	while(it.hasNext()){

		if(it.next().equals(s)){

			sum++;

		}

	}

	

	System.out.println(sum);

	

}

}