import java.util.Scanner;

public class Main {

	public static void main(String[] args){

		Scanner sc=new Scanner(System.in);

															

        String s[];

		System.out.println("Enter user 1 detail:");

		//Your code here

		String user1=sc.nextLine();

		s=user1.split(",");

		User u1=new User(s[0],s[1],s[2],s[3]);

		System.out.println("Enter user 2 detail:");

		//Your code here

		String user2=sc.nextLine();

		s=user2.split(",");

		User u2=new User(s[0],s[1],s[2],s[3]);

		System.out.println();

		System.out.println("User 1");

		System.out.println(u1.toString());

		System.out.println();



		System.out.println("User 2");

		System.out.println(u2.toString());

		System.out.println();

		if(u1.equals(u2))

			System.out.println("User 1 is same as User 2");

		else

			System.out.println("User 1 and User 2 are different");

	}

}

