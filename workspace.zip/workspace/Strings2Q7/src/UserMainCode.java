public class UserMainCode {

	public static void OrangeCapDetails(String s)

	{

		int count=3;

		char ch;

		String s1="";

		s1=s.substring(0,3);

		String s2="",s3="";

		int l=s.length();

		for(int i=3;i<l;i++)

		{

			ch=s.charAt(i);

			if(Character.isLetter(ch)==true || ch==' ')

			{

				s2=s2.concat(Character.toString(ch));

				count++;

			}

		}

		s3=s.substring(count,l);

		System.out.println(s1);

		System.out.println(s2);

		System.out.println(s3);

	}



}

