public class Customer {

	

	private String name;

	private String gender;

	private String contactNumber;

	private String email;

	

	

	public String getName() {

		return name;

	}

	public void setName(String name) {

		this.name = name;

	}

	public String getGender() {

		return gender;

	}

	public void setGender(String gender) {

		this.gender = gender;

	}

	public String getContactNumber() {

		return contactNumber;

	}

	public void setContactNumber(String contactNumber) {

		this.contactNumber = contactNumber;

	}

	public String getEmail() {

		return email;

	}

	public void setEmail(String email) {

		this.email = email;

	}

	

	Customer(){}

	public Customer(String name,String gender,String contactNumber, String email) {

		super();

		this.name = name;

		this.gender = gender;

		this.contactNumber = contactNumber;

		this.email = email;

	}

	

	

public String toString()

	{

	return ("Name:"+name+"\nGender:"+gender+"\nContact Number:"+contactNumber+"\nEmail:"+email);

	}

	public boolean equals(Customer u)

	{

		if((this.name.equalsIgnoreCase(u.getName()) && (this.contactNumber.equalsIgnoreCase(u.getContactNumber()))))

	     return true;

	     else

	    	 return false;

	}	

}

