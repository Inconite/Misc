
import java.util.Scanner;

 

public class Main {

	public static void main(String[] args){

		//BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		Scanner sc=new Scanner(System.in);

		

		String s[];

		

		System.out.println("Enter customer 1 details:");

		//Your code here

		//String v1=br.readLine();

		String customer1=sc.nextLine();

		s=customer1.split(",");

		

		Customer u1=new Customer(s[0],s[1],s[2],s[3]);



		System.out.println("Enter customer 2 details:");

		//Your code here

		//String v2=br.readLine();

		String customer2=sc.nextLine();

		s=customer2.split(",");

		Customer u2=new Customer(s[0],s[1],s[2],s[3]);

		System.out.println();

		System.out.println("Customer 1");

		

		System.out.println(u1.toString());

		System.out.println();

		System.out.println("Customer 2");

		System.out.println(u2.toString());

		System.out.println();

		if(u1.equals(u2))

		System.out.println("Customer 1 is same as Customer 2\n");

		else 

		System.out.println("Customer 1 and Customer 2 are different\n");

	}

}

