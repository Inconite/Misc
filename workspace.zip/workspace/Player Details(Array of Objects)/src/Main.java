import java.util.*;



public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		

		System.out.println("Enter the number of players");

		int n=sc.nextInt();

		sc.nextLine();

		int i;

		String name=null;

		String country=null;

		String skill=null;

		Player p[]=new Player[n];

		for(i=0;i<n;i++)

		{

			System.out.println("Enter the player name");

			name=sc.nextLine();

			System.out.println("Enter the country name");

			country=sc.nextLine();

			System.out.println("Enter the skill");

			skill=sc.nextLine();

			p[i]=new Player(name, country, skill);

			//p[i].setName(name);

			//p[i].setCountry(country);

			//p[i].setSkill(skill);

		}

		PlayerBO pl=new PlayerBO();

		

		//for(i=0;i<n;i++)

		{

			pl.displayAllPlayerDetails(p);

			//System.out.println(p[i].toString());

		}

		sc.close();

	}



}