public  class UtilityCar extends Car {

Boolean rearCooloingVents;

 

public Boolean getRearCooloingVents() {

return rearCooloingVents;

}

 

public void setRearCooloingVents(Boolean rearCooloingVents) {

this.rearCooloingVents = rearCooloingVents;

}

 

public UtilityCar(Long id, String name, Boolean rearCooloingVents) {

super(id, name);

this.rearCooloingVents = rearCooloingVents;

}

@Override

Double calculateDriveCost(Double dist)

 {

 return dist*18.0;

 }

 

}