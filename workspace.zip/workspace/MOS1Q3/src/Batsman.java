public class Batsman extends Player

{

	private long noOfRuns;



	public long getNoOfRuns() {

		return noOfRuns;

	}



	public void setNoOfRuns(long noOfRuns) {

		this.noOfRuns = noOfRuns;

	}

	

	Batsman()

	{

		

	}

	

	Batsman(String name,String teamName,long noOfMatches,long noOfRuns)

	{

		super(name,teamName,noOfMatches);

		this.setNoOfRuns(noOfRuns);

	}

	

	void displayDetails()

	{

		System.out.println("Batsman : "+getName());

		System.out.println("Team : "+getTeamName());

		System.out.println("Number of matches : "+getNoOfMatches());

		System.out.println("Number of runs scored : "+getNoOfRuns());

	}

	

}



