public class Bowler extends Player {

	

	private long noOfWickets;

	

	

	public long getNoOfWickets() {

		return noOfWickets;

	}



	public void setNoOfWickets(long noOfWickets) {

		this.noOfWickets = noOfWickets;

	}

	

	Bowler()

	{

		

	}

	

	Bowler(String name,String teamName,long noOfMatches,long noOfWickets)

	{

		super(name,teamName,noOfMatches);

		this.setNoOfWickets(noOfWickets);

		

	}

	

	void displayDetails()

	{

		System.out.println("Bowler : "+getName());

		System.out.println("Team : "+getTeamName());

		System.out.println("Number of matches : "+getNoOfMatches());

		System.out.println("Number of wickets taken : "+getNoOfWickets());

		

	}

}