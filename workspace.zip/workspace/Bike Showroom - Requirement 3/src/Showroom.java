import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Showroom {
	private String id;
	private String name;
	private String email;
	private String brand;
	private String city;
	
	public Showroom() {
		super();
	}
	
	public Showroom(String id, String name, String email, String brand, String city) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.brand = brand;
		this.city = city;
	}
	
	static Map<String,Integer> cityWiseShowroomCount(List<Showroom> list){
		Map<String, Integer> showroomCount=new TreeMap<String, Integer>();
		Iterator<Showroom> itr=list.iterator();
		while(itr.hasNext())
		{
			Showroom showroom=itr.next();
			int count=showroomCount.containsKey(showroom.getCity()) ? showroomCount.get(showroom.getCity()):0;
			showroomCount.put(showroom.getCity(), count+1);
		}
		return showroomCount;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
		
}
