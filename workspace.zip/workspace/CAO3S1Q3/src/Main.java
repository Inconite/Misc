import java.util.Scanner;

public class Main {



	public static void main(String[] args) 

	{

		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the number of deliveries");

		int a = sc.nextInt();

		Delivery delivery[] = new Delivery[a];

		for(int i=0;i<a;i++)

		{

			long over=0;

			long ball=0;

			String batsman =null;

			String bowler=null;

			String nonStriker=null;

			

			System.out.println("Enter the over");

			over=sc.nextLong();

			System.out.println("Enter the ball");

			ball=sc.nextLong();

			sc.nextLine();

			System.out.println("Enter the batsman");

			batsman=sc.nextLine();

			System.out.println("Enter the bowler");

			bowler=sc.nextLine();

			System.out.println("Enter the nonStriker");

			nonStriker=sc.nextLine();

			delivery[i]=new Delivery(over, ball, batsman, bowler, nonStriker);

		}

		

		DeliveryBO deliverybo = new DeliveryBO();

		deliverybo.displayAllDeliveryDetails(delivery);

	}

}
