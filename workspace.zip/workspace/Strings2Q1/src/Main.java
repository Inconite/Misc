import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Scanner sc=new Scanner(System.in);
       //System.out.println("")
       String s=sc.nextLine();
       char ch[] = s.toCharArray();
       int n=s.length();
       String s1="";
       int z=0;
       for(int i=0;i<n;i++)
       {
    	   if(i<n-2)
    	   {
    		   int a=((ch[i]*100)+(ch[i+1]*10)+(ch[i+2]));
    		   if(a%4==0)
    		   {
    			   z++;
    		   }
    	   }
       }
		System.out.println(z);
	}
}