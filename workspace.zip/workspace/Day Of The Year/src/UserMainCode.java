import java.text.*;

import java.text.SimpleDateFormat;

import java.util.Date;

public class UserMainCode {

public static void displayDay(String s) throws Exception

{

	SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM-dd");

	SimpleDateFormat sdf2=new SimpleDateFormat("D");

	Date d1=sdf1.parse(s);

	String s2=sdf2.format(d1);

	System.out.println("Day of year : " +s2);

	}

}