import java.util.Scanner;

public class Main 

{



	public static void main(String[] args) 

	{

		Scanner sc=new Scanner(System.in);

		

		System.out.println("Enter the number of venues");

		int n =sc.nextInt();

		sc.nextLine();

		String str[]=new String[n];

		

		

		for(int i=0;i<n;i++)

		{

			System.out.println("Enter the details of venue " +(i+1));

			str[i]=sc.nextLine();

			

		}

		Venue v= new Venue();

		

		System.out.println("Venue Details");

		

		for(int i=0;i<n;i++)

		{

			String s[]=str[i].split(",");

			v.setStadiumName(s[0]);

			v.setCity(s[1]);

			System.out.println("Venue "+(i+1));

			System.out.println("Stadium Name : "+v.getStadiumName());

			System.out.println("City Name : "+v.getCity());

		}

		

	}



}