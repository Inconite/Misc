import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	int n,i;
	n=sc.nextInt();
	sc.nextLine();
	TreeSet<String> a=new TreeSet<String>();
for(i=0;i<n;i++)
{
	a.add(sc.nextLine());
}
	Iterator it=a.iterator();
	for(i=0;i<a.size();i++)
	{
		System.out.println(it.next());
	}

}
}
