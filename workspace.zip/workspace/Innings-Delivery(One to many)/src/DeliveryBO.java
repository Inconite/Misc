public class DeliveryBO {

  

	public Delivery createDelivery(String data, Innings [] inningsList)

{

 String s[]=data.split(",");

 

 Delivery d=new Delivery();

 

 long inningsNumber=Long.valueOf(s[4]);

 

 for(int i=0;i<inningsList.length;i++)

{

 if(inningsList[i].getInningsNumber()==(inningsNumber))

{

 d=new Delivery(Long.valueOf(s[0]), s[1], s[2], Long.valueOf(s[3]),inningsNumber, inningsList[i]);

}

}

 return d;

}



	public String findInningsNumber(Delivery[] deliveryList,long deliveryNumber)

{

 String s=null;

 

 for(int i=0;i<deliveryList.length;i++)

{

 if(deliveryList[i].getDeliveryNumber()==deliveryNumber)

{

 s="Innings : "+deliveryList[i].innings.getInningsNumber();

}

}

 return s;

}



}