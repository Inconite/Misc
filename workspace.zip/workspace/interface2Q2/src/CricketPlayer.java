 

public class CricketPlayer extends Player implements IPlayerStatistics {

 

	private long totalRunsScored,noOfWicketsTaken;

 



	public CricketPlayer(String name, String teamName, long noOfMatches,

 

 long totalRunsScored, long noOfWicketsTaken) {

 

 super(name, teamName, noOfMatches);

 

 this.totalRunsScored = totalRunsScored;

 

 this.noOfWicketsTaken = noOfWicketsTaken;

}







	public long getTotalRunsScored() {

 

 return totalRunsScored;

}







	public void setTotalRunsScored(long totalRunsScored) {

 

 this.totalRunsScored = totalRunsScored;

}







	public long getNoOfWicketsTaken() {

 

 return noOfWicketsTaken;

}







	public void setNoOfWicketsTaken(long noOfWicketsTaken) {

 

 this.noOfWicketsTaken = noOfWicketsTaken;

}







	public void displayPlayerStatistics()

{

 System.out.println("Player name : "+getName());

 

 System.out.println("Team name : "+getTeamName());

 

 System.out.println("No of matches : "+getNoOfMatches());

 

 System.out.println("Total runsscored : "+getTotalRunsScored());

 

 System.out.println("No of wickets taken : "+getNoOfWicketsTaken());

}

}





