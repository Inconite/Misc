import java.util.*;

public class Main {



	public static void main(String[] args) {

		// TODO Auto-generated method stub

Scanner sc=new Scanner(System.in);

Player p=new Player();

System.out.println("Enter the player details");

p.name=sc.nextLine();

String s[]=p.name.split(",");

System.out.println("Player Details :");

System.out.println("Player Name : "+s[0]);

System.out.println("Country Name : "+s[1]);

System.out.println("Skill : "+s[2]);

	}



}




