public class Player {

String name,country,skill;

}


