import java.util.Scanner;
public class Main
{

	public static void main(String[] args) 
	{
		int n, b, rev = 0;
		Scanner sc=new Scanner(System.in);
		int limit1=sc.nextInt();
		int limit2=sc.nextInt();
	       for (int i = limit1; i <= limit2; i++)
		{
			n = i;
			while (n > 0)
			{
				b = n % 10;
				rev = rev * 10 + b;
				n = n / 10;
			}
			if (rev == i)
			{
				System.out.print(i + " ");
			}
			rev = 0;
		}
		
	}

}