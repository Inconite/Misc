
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
        // TODO Auto-generated method stub
          int n1,n2,temp,rev=0;
          Scanner sc = new Scanner(System.in);
           n1 = sc.nextInt();
           n2 = sc.nextInt();
          for(int i=n1;i<=n2;i++)
           {
               if(checkPalindrome(i))
               {
                   System.out.printf("%d ",i);
               }
           }
           sc.close();
    }
    public static boolean checkPalindrome(int a)
    {
        int temp=a;
        int rev=0;
       while(temp!=0)
       {
           int rem = temp%10;
           rev = rev*10+rem;
           temp=temp/10;
       }
       if(rev==a)
       {
           return true;
       }
       else 
       {
           return false;
       }
    }
}
		
