import java.io.BufferedReader;

import java.io.IOException;

import java.io.InputStreamReader;

import java.text.SimpleDateFormat;

import java.time.LocalDate;

import java.time.Period;

import java.time.format.DateTimeFormatter;

import java.util.Calendar;

import java.util.GregorianCalendar;

import java.util.regex.Matcher;

import java.util.regex.Pattern;

public class Main 
{


public static void main(String[] args) throws IOException 
{
String menu = "Menu:\n 1) Valid Car registration Number\n 2) Convert Car registration Number\n "
+ "3) Valid Driving License";
System.out.println(menu);
System.out.println("Enter choice");
BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
int x = Integer.parseInt(br.readLine());
String regnum = "",input="";
switch(x) 
{
case 1: 
{
System.out.println("car registration number");
regnum = br.readLine();
validateRegNum(regnum);
break;
}
case 2: 
{
System.out.println("car registration number");
regnum = br.readLine();
convertRegNum(regnum);
break;
}
case 3: 
{
System.out.println("driving license issue date");
input = br.readLine();
validateDrivingLicense(input);
break;
}
}
}
public static void validateRegNum(String reg) 
{
if(reg.substring(2,3).equals("-")&&reg.substring(5,6).equals("-")&&reg.substring(8, 9).equals("-"))
System.out.println(reg+" is Valid");
else
System.out.println(reg+" is Invalid");
}
public static void convertRegNum(String reg) 
{
System.out.println(reg.subSequence(0, 2)+"-"+reg.subSequence(3, 5)+"-"+reg.subSequence(6, 8)+"-"+reg.substring(9));
}
public static void validateDrivingLicense(String inp) 
{
DateTimeFormatter dtf =DateTimeFormatter.ofPattern("dd-MM-yyyy");
LocalDate date1=LocalDate.parse(inp,dtf);
LocalDate date2=LocalDate.parse("15-06-2017",dtf);
Period p=Period.between(date1,date2);
if(p.getYears()<=10)
System.out.println(p.getYears()+" years old license - valid");
else
System.out.println(p.getYears()+" years old license - expired");
}
}
