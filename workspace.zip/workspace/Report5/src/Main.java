import java.util.*;
import java.text.*;
public class Main 
{

	public static void main(String[] args) throws ParseException
	{
		Scanner lol = new Scanner(System.in);
		System.out.println("Enter the number of students:");
		int a = lol.nextInt();
		lol.nextLine();
		List<Student> stu = new ArrayList<>();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		
		for(int i=0;i<a;i++)
		{
			String str=lol.nextLine();
			String sp[] = str.split(",");
			stu.add(new Student(sp[0],sp[1],sdf.parse(sp[2]),Integer.parseInt(sp[3])));
		}
		
		System.out.println("Enter a search type:\n1.By date of birth\n2.By standard");
		int choice = lol.nextInt();
		
		
		switch(choice)

		{

		case 1:

			lol.nextLine();

		System.out.println("Enter the date of birth:");

		String dob = lol.nextLine();
		StudentBO sbo = new StudentBO();
		
		List<Student> vb=sbo.findStudent(stu, sdf.parse(dob));
	    
		if(vb.size()==0)
			System.out.println("No such student is present");

		else
		{
			System.out.format("%-10s %-10s %-15s %s\n","Roll No","Name","Date of Birth","Standard");

		for(Student s: sbo.findStudent(stu,sdf.parse(dob)))
			System.out.format("%-10s %-10s %-15s %s\n",s.getRollNo(),s.getName(),sdf.format(s.getDateOfBirth()),s.getStandard());
		}

		break;

		case 2:

			System.out.println("Enter the standard:");

			Integer stan = lol.nextInt();

			StudentBO sbo1 = new StudentBO();

			List<Student> vb1=sbo1.findStudent(stu,stan);
		    
			if(vb1.size()==0)
				System.out.println("No such student is present");
			else

			{

				System.out.format("%-10s %-10s %-15s %s\n","Roll No","Name","Date of Birth","Standard");

			for(Student s: sbo1.findStudent(stu,stan))
				System.out.format("%-10s %-10s %-15s %s\n",s.getRollNo(),s.getName(),sdf.format(s.getDateOfBirth()),s.getStandard());

			}

			break;

    default:

    	System.out.println("Invalid choice");

  	}

		
	}

}
