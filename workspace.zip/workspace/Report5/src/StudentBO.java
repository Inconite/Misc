import java.util.*;
public class StudentBO 
{
	public List<Student> findStudent(List<Student> studentList,java.util.Date dateOfBirth)
	{
		List<Student> haha = new ArrayList<Student>();

		for(Student s: studentList)
		{
			if(s.getDateOfBirth().equals(dateOfBirth))
				haha.add(s);
		}

		return haha;
	}
	
	public List<Student> findStudent(List<Student> studentList,Integer standard)
	{
		List<Student> rofl = new ArrayList<Student>();

		for(Student s: studentList)
		{
			if(s.getStandard()==standard)
				rofl.add(s);
		}

		return rofl;
	}
}
