import java.util.*;
public class Main {

	public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
       System.out.println("Enter the player details"); 
       String gh=  in.nextLine();
       String hj[] = gh.split(",");
      Player ob = new Player();
       ob.setName(hj[0]);
       ob.setCountry(hj[1]);
       ob.setSkill(hj[2]);
       ob.viewPlayerDetails();
      
		
		
		
	}
	
}
