import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class UserMainCode 
{
	public static void displayDate(String s) throws Exception
	{
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Date dt = sdf.parse(s);
		Calendar c = Calendar.getInstance();
		c.setTime(dt);
		c.add(Calendar.MONTH, 20);
		dt = c.getTime();
		System.out.println("20 months after "+s+" will be "+sdf.format(dt));
	}
}
