
import java.util.*;

public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		

		System.out.println("Enter team details");

		String s=sc.nextLine();

		System.out.println("After replacement");

		System.out.println(s.replaceAll("Captain","Skipper"));

		

	}



}