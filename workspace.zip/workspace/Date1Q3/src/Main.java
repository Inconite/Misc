import java.util.*;
import java.text.*;
public class Main {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		UserMainCode.displayDate(s);
		
		
		
		
		
		
		
		
		
		

	}

}
