import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class Main {
	public static void main(String[] args)throws IOException{
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    	
    	System.out.println("Enter the rollNo to be validated:");
    	//Your code goes here
    	String roll= reader.readLine();
    	if(validateRollNo(roll))System.out.println("RollNo is valid");
    	else System.out.println("RollNo is invalid");
    		
    }
    static Boolean validateRollNo(String rollNo){
		//Your code goes here
    	String m="[1-9][0-9]\\-[A-Z]{3,4}\\-([0-9]){2,3}";
    	if(rollNo.matches(m))return true;
    	else return false;	
    	
    	
    }  
	
}
