import java.text.SimpleDateFormat;

import java.util.Calendar;

import java.util.Date;



public class UserMainCode {

	

	public static Date nextFriday(Date dt,int n)

	{

		Calendar cal=Calendar.getInstance();

		cal.setTime(dt);

		cal.add(Calendar.DATE, n);

		dt=cal.getTime();

		return dt;

	}

	public static Date previousFriday(Date dt,int n)

	{

		Calendar cal=Calendar.getInstance();

		cal.setTime(dt);

		cal.add(Calendar.DATE, n);

		dt=cal.getTime();

		return dt;

	}

	

	public static void DisplayDate(int year,int month,int day)throws Exception

	{

		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");

		String date=year+"-"+month+"-"+day;

		Date dt=sdf.parse(date);

		Date nextFriday=new Date();

		Date previousFriday=new Date();

		SimpleDateFormat sdf1=new SimpleDateFormat("EEE");

		String weekDay=sdf1.format(dt);

		if(weekDay.equals("Mon"))

		{

			nextFriday=UserMainCode.nextFriday(dt, 4);

			previousFriday=UserMainCode.previousFriday(dt, -3);

		}

		else if(weekDay.equals("Tue"))

		{

			nextFriday=UserMainCode.nextFriday(dt, 3);

			previousFriday=UserMainCode.previousFriday(dt, -4);

		}

		else if(weekDay.equals("Wed"))

		{

			nextFriday=UserMainCode.nextFriday(dt, 2);

			previousFriday=UserMainCode.previousFriday(dt, -5);

		}

		else if(weekDay.equals("Thu"))

		{

			nextFriday=UserMainCode.nextFriday(dt, 1);

			previousFriday=UserMainCode.previousFriday(dt, -6);

		}

		else if(weekDay.equals("Fri"))

		{

			nextFriday=UserMainCode.nextFriday(dt, 7);

			previousFriday=UserMainCode.previousFriday(dt, -7);

		}

		else if(weekDay.equals("Sat"))

		{

			nextFriday=UserMainCode.nextFriday(dt, 6);

			previousFriday=UserMainCode.previousFriday(dt, -1);

		}

		else if(weekDay.equals("Sun"))

		{

			nextFriday=UserMainCode.nextFriday(dt, 5);

			previousFriday=UserMainCode.previousFriday(dt, -2);

		}

		System.out.println("Next Friday: "+sdf.format(nextFriday));

		System.out.println("Previous Friday: "+sdf.format(previousFriday));

	}



}