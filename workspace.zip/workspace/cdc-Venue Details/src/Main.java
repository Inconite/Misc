import java.util.*;
public class Main{
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		String sn,c;
		System.out.println("Enter the stadium  name");
		sn=sc.nextLine();
		System.out.println("Enter the city name");
		c=sc.nextLine();
		Venue v=new Venue();
		v.setCity(c);
		v.setStadiumName(sn);
		System.out.println("Venue Details");
		System.out.println(v.toString());
	}
}