public class UserMainCode {



	public static void validateTeam(String s) {

		String a=" ";

		int i;

		String d="";

		int count=0;

		a=a.concat(s);

		int l=a.length();

		int n=s.length();

		for(i=0;i<l;i++)

		{

			if(a.charAt(i)==' ')

			{

				count++;

				d=d.concat(Character.toString(a.charAt(i+1)));

			}

		}

		String str=a.substring(l-count,l);

		str=("-").concat(str);

		String str1=s.substring(n-(count+1),n);

		if(str.equalsIgnoreCase(str1))

		{

			System.out.println("Valid");

		}

		else

		{

			System.out.println("Invalid");

		}

	}



}