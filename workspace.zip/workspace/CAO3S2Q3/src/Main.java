import java.util.Scanner;

public class Main {



	public static void main(String[] args)

	{

		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the number of matches");

		int n = sc.nextInt();

		sc.nextLine();

		Match[] match = new Match[n];

		

		for(int i=0;i<n;i++)

		{

			System.out.println("Enter match "+(i+1)+ " details");

			System.out.println("Enter the match date");

			String date = sc.nextLine();

			System.out.println("Enter the team one");

			String teamOne = sc.nextLine();

			System.out.println("Enter the team two");

			String teamTwo = sc.nextLine();

			System.out.println("Enter the Venue");

			String venue = sc.nextLine();

			match[i] = new Match(date, teamOne, teamTwo, venue);

		}

		

		MatchBO matchbo = new MatchBO();

		matchbo.displayAllMatchDetails(match);

		System.out.println("Enter the date to be searched");

		String date = sc.nextLine();

		matchbo.displaySpecificMatchDetails(match,date);

	}

}