import java.util.*;

import java.io.*;

public class Main {



	public static void main(String[] args) {

		// TODO Auto-generated method stub

		Scanner a=new Scanner(System.in);

		try

		{

			System.out.println("Enter the total runs scored");

			float r=a.nextFloat();

			System.out.println("Enter the total overs faced");

			float o=a.nextFloat();

			if(o>=0 && o<=20)

			{

				System.out.printf("Current Run Rate :%.2f",(r/o));

			}

			else

			{

				throw new OverRangeException("Over is not in the specified range");

			}

		}

		catch(Exception e)

		{

			System.out.println(e);

		}

	}



}