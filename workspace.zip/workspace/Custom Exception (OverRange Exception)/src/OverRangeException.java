public class OverRangeException extends Exception

{

	public OverRangeException(String s)

	{

		super (s);

	}

}