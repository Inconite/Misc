import java.util.*;

  public class Main {

  

	public static void main(String[] args) {

 

 Scanner sc=new Scanner(System.in);



 System.out.println("Enter number of Players");

 

 int n=sc.nextInt();

 

 sc.nextLine();



 int i;

 

 String name;

 

 String country;

 

 String skill;

 

 Player p[]=new Player[n];

 

 Skill s[]=new Skill[n];

 

 int choice;

 

 boolean flag=true;





 for(i=0;i<n;i++)

{

 System.out.println("Enter player "+(i+1)+" details:");

 

 System.out.println("Enter player name");

 

 name=sc.nextLine();

 

 System.out.println("Enter country name");

 

 country=sc.nextLine();

 

 System.out.println("Enter skill");

 

 skill=sc.nextLine();

 

 s[i]=new Skill(skill);

 

 p[i]=new Player(name, country, s[i]);

}



 PlayerBO pbo=new PlayerBO();



 do{

 

 System.out.println("Menu:\n1.View details\n2.Filter players with skill\n3.Exit");

 

 choice=sc.nextInt();



 switch(choice)

{

 case 1:

 

 pbo.viewDetails(p);

 

 break;

 

 case 2:

 

 sc.nextLine();

 

 System.out.println("Enter skill");

 

 skill=sc.nextLine();

 

 pbo.printPlayerDetailsWithSkill(p, skill);

 

 break;

 

 case 3:

 

 flag=false;

 

 break;

 

 default:

System.exit(0);

}

 }while(flag);



 sc.close();

 }

}

