import java.sql.*;
import java.util.Properties;
public class JDBCDemo3 {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
         Properties p=new Properties();
         p.put("user","root");
         p.put("password","root");
		Class.forName("com.mysql.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3306/JDBCDb";
		Connection con = DriverManager.getConnection(url,p);
		
		Statement stmt=con.createStatement();
		//String sql="select * from employee";
		String createCommand="create table employee2(empID int primary key,empName varchar(50),empDep varchar(50),sal float);";
		/*ResultSet rs=stmt.executeQuery(sql);
		while(rs.next())
		{
			int empID=rs.getInt(1);
			String empName=rs.getString(2);
			String empDep=rs.getString(3);
			System.out.println(empID+" "+empName+" "+empDep);
			
		}*/
		try{
			stmt.execute("drop table employee2" );
		}
		catch(SQLException e){
			System.out.println(e.getMessage());
		}
		stmt.execute(createCommand);
		System.out.println("Table successfully created");
		stmt.close();
		con.close();
		
	}

}
