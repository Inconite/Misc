import java.sql.*;
import java.util.*;
public class JDBCDemo4{

	public static void main(String[] args)throws Exception {
		
         Properties p=new Properties();
         p.put("user","root");
         p.put("password","root");
		Class.forName("com.mysql.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3306/JDBCDb";
		Connection con = DriverManager.getConnection(url,p);
		String insertCommand="insert into employee values("+ args[0]+",'"+ args[1]+"','"+ args[2]+"')";
		Statement stmt=con.createStatement();
		
	//	Statement stmt=con.createStatement();
		
		int count=stmt.executeUpdate(insertCommand);
		System.out.println(count +" rows inserted");
		stmt.close();
		con.close();
		
	}

}
