import java.sql.*;
public class JDBCDemo1 {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub

		Class.forName("com.mysql.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3306/JDBCDb";
		Connection con = DriverManager.getConnection(url,"root","root");
		
		Statement stmt=con.createStatement();
		String sql="select * from employee";
		ResultSet rs=stmt.executeQuery(sql);
		while(rs.next())
		{
			int empID=rs.getInt(1);
			String empName=rs.getString(2);
			String empDep=rs.getString(3);
			System.out.println(empID+" "+empName+" "+empDep);
			
		}
			
	}

}
