import java.sql.*;
public class JDBCDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/JDBCDb"
		}
		
		
		
		
		
		
		
		
		
		
		
	}

}
