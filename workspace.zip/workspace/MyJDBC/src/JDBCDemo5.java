import java.sql.*;
import java.util.*;
public class JDBCDemo5{

	public static void main(String[] args)throws Exception {
		
         Properties p=new Properties();
         p.put("user","root");
         p.put("password","root");
		Class.forName("com.mysql.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3306/JDBCDb";
		Connection con = DriverManager.getConnection(url,p);
		//String insertCommand="insert into employee values("+ args[0]+",'"+ args[1]+"','"+ args[2]+"')";
		Statement stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		ResultSet rs=stmt.executeQuery("Select * from employee2");
		rs.moveToInsertRow();
	//	Statement stmt=con.createStatement();
		rs.moveToInsertRow();
		rs.updateInt("empId",105);
		rs.updateString("empName","Amma");
		rs.updateFloat("sal",105.06f);
		rs.insertRow();
		System.out.println("Roe inserted");
		while(rs.next()){
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getFloat(3));
		}
		rs.close();
		stmt.close();
		con.close();

		
	}

}

