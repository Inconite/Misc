import java.util.*;

public class Main {



	public static void main(String[] args) {

		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);

		ArrayList al=new ArrayList();

		System.out.println("Enter the player details");

		System.out.println("Enter player name");

		String n=sc.nextLine();

		al.add(n);

		System.out.println("Enter age");

		int age=sc.nextInt();

		al.add(age);

		sc.nextLine();

		System.out.println("Enter Country");

		String country=sc.nextLine();

		al.add(country);

		System.out.println("Player Details");

		Iterator it=al.iterator();

		while(it.hasNext())

		{

			System.out.println(it.next());

		}

		System.out.println("Enter Skill");

		String skill=sc.nextLine();

		System.out.println("Enter the position to add the skill");

		int a=sc.nextInt();

		al.set(a, skill);

		System.out.println("Player Details");

		Iterator it1=al.iterator();

		while(it1.hasNext())

		{

			System.out.println(it1.next());

		}

		System.out.println("Enter the position of the detail to be removed");

		int b=sc.nextInt();

		al.remove(b);

		System.out.println("Player Details");

		Iterator it2=al.iterator();

		while(it2.hasNext())

		{

			System.out.println(it2.next());

		}

	}



}