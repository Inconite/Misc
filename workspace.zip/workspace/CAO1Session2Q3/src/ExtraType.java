
import java.util.*;

public class ExtraType 

{

	String name;

	Long runs;

	public String getName() {

		return name;

	}

	public void setName(String name) {

		this.name = name;

	}

	public Long getRuns() {

		return runs;

	}

	public void setRuns(Long runs) {

		this.runs = runs;

	}

	

	

}