import java.util.Scanner;

public class Main 

{

public static void main(String args[])



 {



	 Scanner sc = new Scanner(System.in);



	 ExtraType etr = new ExtraType();



	 String str = new String();



	 System.out.println("Enter the extratype details");



	 str = sc.nextLine();



	 String arr[] = str.split("#");



	 String str1 = arr[0];



	 long a = Integer.parseInt(arr[1]); 



	 etr.setName(str1);



	 etr.setRuns(a);



	 System.out.println("ExtraType Details");



	 System.out.println("Extra Type:"+etr.getName());



	 System.out.println("Runs:"+etr.getRuns());



 }



}
