import java.util.*;
public class Main {

	
static	boolean validateEmailId(String email) {
	if(email.matches("[a-z|A-Z]{1}[a-z|A-Z|.|_|0-9]{1,}[@]{1}[a-z|A-Z]{1,}[.]{1}[a-z|A-Z]{2,6}")){
		return true;
	}
			
	else
		return false;
}
static String identifyServiceProvider(String mobile) {
	String s;

if(mobile.substring(0,4).equals("9870"))
	s="Mobile number belongs to Airtel";

else if(mobile.substring(0,4).equals("7012"))
	s="Mobile number belongs to Jio";

else if(mobile.substring(0,4).equals("8180"))
	s="Mobile number belongs to Vodafone";

else 
	s="Mobile number is not identified";
return (s);

}

public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	
	System.out.println("1.Email Validation");
	System.out.println("2.Service Provider Identification");
	System.out.println("Enter your choice:");
	
	int i=sc.nextInt();
	sc.nextLine();
	if(i==1) {
System.out.println("Enter the email to be validated:");
		if(validateEmailId(sc.nextLine()))
			System.out.println("Email is valid");
		
		else
			System.out.println("Email is invalid");
	}
	else if(i==2){
		System.out.println("Enter the mobile number to identify the service provider:");
	System.out.println(identifyServiceProvider(sc.nextLine()));
	
}
}
}