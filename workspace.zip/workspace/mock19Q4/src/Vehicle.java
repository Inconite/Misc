
public class Vehicle {

}
