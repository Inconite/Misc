
public class VehicleBO {

}
