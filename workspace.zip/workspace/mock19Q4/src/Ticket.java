
public class Ticket {

}
