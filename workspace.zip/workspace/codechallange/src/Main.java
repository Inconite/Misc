import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
for(int i=0;i<n;i++)
{
	for(int j=0;j<n;j++)
	{
		if(i==j)
			System.out.print(j);
		else
		System.out.print("0");
	}
	System.out.println("");

}

	}

}




