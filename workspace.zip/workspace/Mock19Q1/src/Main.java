import java.io.BufferedReader;

import java.io.IOException;

import java.io.InputStreamReader;

import java.text.ParseException;

import java.text.SimpleDateFormat;





public class Main {

	public static void main(String args[]) throws IOException, NumberFormatException, ParseException{

		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");

				

		Vehicle[] vehicleList = new Vehicle[2];

		for(int i=0;i<2;i++)

		{

			System.out.println("Enter Vehicle "+(i+1)+" details:");

			String input =reader.readLine(); 

			String[] inputArray = input.split(",");

			Ticket ticket = new Ticket(inputArray[4],formatter.parse(inputArray[5]),Double.parseDouble(inputArray[6]));

			vehicleList[i] = new Vehicle(inputArray[0],inputArray[1],inputArray[2],Double.parseDouble(inputArray[3]),ticket);

		}

		System.out.println();

		for(int i=0;i<2;i++)

		{

			System.out.println("Vehicle "+(i+1));

			
			System.out.println(vehicleList[i].toString());

			System.out.println();

		}

		//System.out.println();

		if(vehicleList[0].equals(vehicleList[1]))

			System.out.print("Vehicle 1 is same as Vehicle 2");

		else

			System.out.print("Vehicle 1 and Vehicle 2 are different");

	} 

}