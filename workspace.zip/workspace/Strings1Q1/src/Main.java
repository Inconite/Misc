import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter team1");
		String a=sc.nextLine();
		System.out.println("Enter team2");
		String b=sc.nextLine();
		System.out.println("Enter third character");
		String c=sc.nextLine();
		char ch=c.charAt(0);
		if(a.charAt(2)==ch)

		{

			System.out.println("Winner Team : "+a);

		}

		else

		{

			System.out.println("Winner Team : "+b);

		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
