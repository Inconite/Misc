import java.util.Map;



public class PaymentUtil {



	public Double makePayment(Map<String, Float> bankTax, String bankName,

			Double amount) {

		// Double d = 0.0;

		// Double d1;

		// System.out.print(amount);

		// System.out.println(bankName);

		for (String s : bankTax.keySet()) {

			// System.out.print(bankTax.get(s) + " \n");

			// System.out.println(s);

			if (s.equalsIgnoreCase(bankName)) {

				// System.out.printf("%.2f \n",

				// (amount + (amount * (bankTax.get(s)) / 100))); // d1 =

				// // Double.parseDouble(bankTax.get(s).toString());

				Double d = ((bankTax.get(s) / 100) * amount) + amount;

				return d;

			}

		}



		// System.out.printf("%.2f", d);

		// Double d = 0.0;

		return 0.0;

		// fill code here.

	}



	public Double makePayment(Double amount) {

		Float serviceTax = 5.2f;

		Float vat = 2.3f;



		amount = amount + (amount * (serviceTax) / 100);

		amount = amount + (amount * (vat) / 100);

		return amount;

		// fill code here.

	}



	public Double makePayment(Double amount, Float discountPercent) {



		return amount - (amount * discountPercent / 100);

		// fill code here.

	}



}