
import java.util.*;

public class Main {



	public static void main(String[] args) 

	{

		Scanner sc=new Scanner(System.in);

		Wicket wicket=new Wicket();

		Long l1,l2;

		String w,p,b;

		

		System.out.println("Enter the over");

		l1=sc.nextLong();

		System.out.println("Enter the ball");

		l2=sc.nextLong();

		sc.nextLine();

		System.out.println("Enter the wicket type");

		w=sc.nextLine();

		System.out.println("Enter the player name");

		p=sc.nextLine();

		System.out.println("Enter the bowler name");

		b=sc.nextLine();

		

		wicket.setOver(l1);

		wicket.setBall(l2);

		wicket.setWicketType(w);

		wicket.setPlayerName(p);

		wicket.setBowlerName(b);

		

		System.out.println("Wicket Details");

		System.out.println("Over : "+wicket.getOver());

		System.out.println("Ball : "+wicket.getBall());

		System.out.println("Wicket Type : "+wicket.getWicketType());

		System.out.println("Player Name : "+wicket.getPlayerName());

		System.out.println("Bowler Name : "+wicket.getBowlerName());



	}



}