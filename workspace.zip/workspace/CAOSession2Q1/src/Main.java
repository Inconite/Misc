
import java.util.*;

public class Main {



	public static void main(String[] args) {

		// TODO Auto-generated method stub

Scanner sc=new Scanner(System.in);

Wicket w=new Wicket();

System.out.println("Enter the over");

w.setOver(sc.nextLong());

System.out.println("Enter the ball");

w.setBall(sc.nextLong());

System.out.println("Enter the wicket type");

sc.nextLine();

w.setWicketType(sc.nextLine());

System.out.println("Enter the player name");

w.setPlayerName(sc.nextLine());

System.out.println("Enter the bowler name");

w.setBowlerName(sc.nextLine());

System.out.println("Wicket Details");

System.out.println("Over : "+w.getOver());

System.out.println("Ball : "+w.getBall());

System.out.println("Wicket Type : "+w.getWicketType());

System.out.println("Player Name : "+w.getPlayerName());

System.out.println("Bowler Name : "+w.getBowlerName());



	}



}

