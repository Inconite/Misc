import java.util.*;

public class Wicket

{

	private Long over;

	private Long ball;

	private String wicketType; 

	private String playerName;

	private String bowlerName;

	

	public long getOver()

	{

		return over;

	}

	public long getBall()

	{

		return ball;

	}

	public String getWicketType()

	{

		return wicketType;

	}

	public String getPlayerName()

	{

		return playerName;

	}

	public String getBowlerName()

	{

		return bowlerName;

	}

	

	public void setOver(long Over)

	{

		this.over=Over;

	}

	public void setBall(long Ball)

	{

		this.ball=Ball;

	}

	public void setWicketType(String WicketType)

	{

		this.wicketType=WicketType;

	}

	public void setPlayerName(String PlayerName)

	{

		this.playerName=PlayerName;

	}

	public void setBowlerName(String BowlerName)

	{

		this.bowlerName=BowlerName;

	}

	

}