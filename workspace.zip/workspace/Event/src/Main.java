import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	long in,en,rp,dp;
	String r,d;
	System.out.println("Enter the innings");
	in=sc.nextLong();
	System.out.println("Enter the event");
	en=sc.nextLong();
	sc.nextLine();
	System.out.println("Enter the raider");
	r=sc.nextLine();
	System.out.println("Enter the defenders");
	d=sc.nextLine();
	System.out.println("Enter the raiderPoints");
	rp=sc.nextLong();
	System.out.println("Enter the defenderPoints");
	dp=sc.nextLong();
	Event e=new Event();
	e.setDefenderPoints(dp);
	e.setDefenders(d);
	e.setEventNumber(en);
	e.setInnings(in);
	e.setRaider(r);
	e.setRaiderPoints(rp);
	System.out.println("Event Details");
	System.out.println("Innings :"+e.getInnings());
	System.out.println("Event :"+e.getEventNumber());
	System.out.println("Raider :"+e.getRaider());
	System.out.println("Defenders :"+e.getDefenders());
	System.out.println("Raider Points :"+e.getRaiderPoints());
	System.out.println("Defender Points :"+e.getDefenderPoints());
}
}
