
public class Event {
private long innings,eventNumber,raiderPoints,defenderPoints;
private String raider,defenders;
public long getInnings() {
	return innings;
}
public void setInnings(long innings) {
	this.innings = innings;
}
public long getEventNumber() {
	return eventNumber;
}
public void setEventNumber(long eventNumber) {
	this.eventNumber = eventNumber;
}
public long getRaiderPoints() {
	return raiderPoints;
}
public void setRaiderPoints(long raiderPoints) {
	this.raiderPoints = raiderPoints;
}
public long getDefenderPoints() {
	return defenderPoints;
}
public void setDefenderPoints(long defenderPoints) {
	this.defenderPoints = defenderPoints;
}
public String getRaider() {
	return raider;
}
public void setRaider(String raider) {
	this.raider = raider;
}
public String getDefenders() {
	return defenders;
}
public void setDefenders(String defenders) {
	this.defenders = defenders;
}

}
