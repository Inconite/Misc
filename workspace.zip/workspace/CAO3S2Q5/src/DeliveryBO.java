class DeliveryBO



{



DeliveryBO(){}



void displayAllDeliveryDetails(Delivery[] deliveryList)



{



    System.out.println("Delivery Details");



    String a="Over";



    String b="Ball";



    String c="Runs";



    String d="Batsman";



    String e="Bowler";



    String f="NonStriker";



    System.out.println( String.format("%-20s %-20s %-20s %-20s %-20s %s",a,b,c,d,e,f));



    for(int i=0;i<deliveryList.length;i++)



    {



      System.out.println(deliveryList[i].toString());



    }



}



void displayBatsmanBowlerDetails(Delivery[] deliveryList, Long ball,Long over)



{



    for(int i=0;i<deliveryList.length;i++)



    {



     if(ball.equals(deliveryList[i].getBall()) && over.equals(deliveryList[i].getOver()))



     {



       System.out.println("Batsman : "+deliveryList[i].getBatsman());



       System.out.println("Bowler : "+deliveryList[i].getBowler());



     }



    }



}



void displayMaximumRunDetails(Delivery[] deliveryList)



{



    Long maxRuns=0L,ball=0L,over=0L;



    int index=0;



    for(int i=0;i<deliveryList.length;i++)



    {



      if(deliveryList[i].getRuns()>maxRuns)



      {



        maxRuns=deliveryList[i].getRuns();



        index=i;



      }



    }



    for(int i=0;i<deliveryList.length;i++)



    {



      if(i==index)



      {



        System.out.println("Maximum Runs : "+deliveryList[i].getRuns());



        System.out.println("Over : "+deliveryList[i].getOver());



        System.out.println("Ball : "+deliveryList[i].getBall());



      }



    }



}



}