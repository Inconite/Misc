
import java.util.Scanner;



 import java.io.*;



public class Main



{



  public static void main(String args[]) throws IOException



  {



    Long over;



    Long ball;



    Long runs; 



    String batsman;



    String bowler;



    String nonStriker;



    Scanner scanner = new Scanner(System.in);



    System.out.println("Enter the number of deliveries");



    int n=scanner.nextInt();



    Delivery[] delivery=new Delivery[n];



    for(int i=0;i<n;i++)



    {



    System.out.println("Enter the over");



    over=scanner.nextLong();     



    System.out.println("Enter the ball");



    ball=scanner.nextLong();     



    System.out.println("Enter the runs");



    runs=scanner.nextLong();     



    scanner.nextLine();



    System.out.println("Enter the batsman name");



    batsman=scanner.nextLine();



    System.out.println("Enter the bowler name");



    bowler=scanner.nextLine();



    System.out.println("Enter the nonStriker name");



    nonStriker=scanner.nextLine();



    delivery[i] = new Delivery(over,ball,runs,batsman,bowler,nonStriker);



  }



    System.out.println("Enter your choice\n1.View delivery details\n2.Batsman and Bowler\n3.Maximum runs");



    int ch=scanner.nextInt();



    DeliveryBO dBo=new DeliveryBO();



    switch(ch)



    {



    case 1:



    dBo.displayAllDeliveryDetails(delivery);



    break;



    case 2:



    System.out.println("Enter the over for which batsman and bowler to be known");



    Long oversearch=scanner.nextLong();



    System.out.println("Enter the ball for which batsman and bowler to be known");



    Long ballsearch=scanner.nextLong();



    dBo.displayBatsmanBowlerDetails(delivery,ballsearch,oversearch); 



    break; 



    case 3:



    dBo.displayMaximumRunDetails(delivery);  



    break;



    }



  }



}









