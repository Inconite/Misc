
public class Delivery 

{

	private long over;

	private long ball;

	private long runs;

	private String nonStriker;

	private String batsman;

	private String bowler;

	

	Delivery()

	{

		

	}



	public Delivery(long over, long ball, long runs, String nonStriker, String batsman, String bowler) {

		super();

		this.over = over;

		this.ball = ball;

		this.runs = runs;

		this.nonStriker = nonStriker;

		this.batsman = batsman;

		this.bowler = bowler;

	}

	

	public String toString()

	{

		return (String.format("%-20s %-20s %-20s %-20s %-20s %s",over,ball,runs,batsman,bowler,nonStriker));

	}



	public long getOver() {

		return over;

	}



	public void setOver(long over) {

		this.over = over;

	}



	public long getBall() {

		return ball;

	}



	public void setBall(long ball) {

		this.ball = ball;

	}



	public long getRuns() {

		return runs;

	}



	public void setRuns(long runs) {

		this.runs = runs;

	}



	public String getNonStriker() {

		return nonStriker;

	}



	public void setNonStriker(String nonStriker) {

		this.nonStriker = nonStriker;

	}



	public String getBatsman() {

		return batsman;

	}



	public void setBatsman(String batsman) {

		this.batsman = batsman;

	}



	public String getBowler() {

		return bowler;

	}



	public void setBowler(String bowler) {

		this.bowler = bowler;

	}

	

}

