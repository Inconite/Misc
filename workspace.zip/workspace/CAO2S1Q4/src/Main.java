
import java.util.Scanner;



public class Main {



	public static void main(String[] args) {

		long over;

		long ball;

		String wicketType;

		String playerName;

		String bowlerName;

		Scanner sc=new Scanner(System.in);

		System.out.println("Enter the number of wickets");

		int a=sc.nextInt();

		sc.nextLine();

		String s[]=new String[a];

		for(int i=0;i<a;i++)

		{



			  System.out.println("Enter the details of wicket "+(i+1));

			 s[i]=sc.nextLine();

		}

		 Wicket w=new Wicket();

		

	

		System.out.println("Wicket Details");

		for(int i=0;i<a;i++)

		{

	    String s1[]=s[i].split(",");	  

		  over=Long.parseLong(s1[0]);

		  w.setOver(over);

		  ball=Long.parseLong(s1[1]);

		  w.setBall(ball);

		  wicketType=s1[2];

		  w.setWicketType(wicketType);

		  playerName=s1[3];

		  w.setPlayerName(playerName);

		  bowlerName=s1[4];

		  w.setBowlerName(bowlerName);

		  System.out.println("Over : "+w.getOver());

		  System.out.println("Ball : "+w.getBall()); 

		  System.out.println("Wicket Type : "+w.getWicketType());

		  System.out.println("Player Name : "+w.getPlayerName()); 

		  System.out.println("Bowler Name : "+w.getBowlerName());

		  

	  }

		

    

}

	

}











