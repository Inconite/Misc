import java.util.Scanner;



public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the number of wickets");

		int n = sc.nextInt();

		sc.nextLine();

		

		Wicket[] wicket = new Wicket[n];

		

		for(int i=0;i<n;i++)

		{

			System.out.println("Enter the details of wicket " +(i+1));



			String str = sc.nextLine();

			String[] strarr = str.split(",");

			wicket[i] = new Wicket(Long.parseLong(strarr[0]),Long.parseLong(strarr[1]),strarr[2],strarr[3],strarr[4]);

		}

		

		WicketBO wicketBO = new WicketBO();

		wicketBO.displayAllWicketDetails(wicket);

		

		System.out.println("Enter the wicket type to be searched");



		String wicketType = sc.nextLine();

		

		wicketBO.displaySpecificWicketDetails(wicket, wicketType);

	}

}

