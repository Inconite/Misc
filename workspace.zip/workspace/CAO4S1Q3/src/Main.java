
import java.util.*;

  public class Main {

  

	public static void main(String[] args) {

 

 Scanner sc=new Scanner(System.in);



 System.out.println("Enter the team count");

 

 int n=sc.nextInt();

 

 sc.nextLine();

 

 int i;

 

 String s[]=new String[n];

 

 Team t[]=new Team[n];

 

 TeamBO tbo=new TeamBO();

 

 for(i=0;i<n;i++)

{

 System.out.println("Enter team "+(i+1)+" details");

 

 s[i]=sc.nextLine();

 

 t[i]=tbo.createTeam(s[i]);

}



 System.out.println("Enter the player count");

 

 int p=sc.nextInt();

 

 sc.nextLine();

 

 String pl[]=new String[p];

 

 Player play[]=new Player[p];

 

 PlayerBO pbo=new PlayerBO();

 

 for(i=0;i<p;i++)

{

 System.out.println("Enter player "+(i+1)+" details");

 

 pl[i]=sc.nextLine();

 

 play[i]=pbo.createPlayer(pl[i], t);

}



 System.out.println("Enter the player name for which you need to find the team name");

 

 String playername=sc.nextLine();

 

 System.out.println(playername+" belongs to "+pbo.findTeamName(play, playername));



 System.out.println("Enter 2 player names");

 

 String p1=sc.nextLine();

 

 String p2=sc.nextLine();

 

 boolean flag=pbo.findWhetherPlayersAreInSameTeam(play, p1, p2);

 

 if(flag)

{

 System.out.println("The 2 player are in the same team");

}

 else

 {

 System.out.println("The 2 player are in the different teams");

}



 sc.close();

}

}