public class TeamBO {



	public Team createTeam(String data)

{

 String s[]=data.split(",");

 

 Team t=new Team(s[0],s[1]);



 return t;

}

}

