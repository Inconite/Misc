public class Team {



	private String name;

 

	private String home;



Team()

{



}

 

	public Team(String name, String home) {

 

 super();

 

 this.name = name;

 

 this.home = home;

}

 

	public String getName() {

 

 return name;

}

 

	public void setName(String name) {

 

 this.name = name;

}

 

	public String getHome() {

 

 return home;

}

 

	public void setHome(String home) {

 

 this.home = home;

}



}





