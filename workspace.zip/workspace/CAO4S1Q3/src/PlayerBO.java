public class PlayerBO

{



	public Player createPlayer(String data, Team[] teamList)

{

 String p[]=data.split(",");

 

 Player pl=new Player();

 

 for(int i=0;i<teamList.length;i++)

{

 if(p[1].equals(teamList[i].getName()))

{

 pl=new Player(p[0], teamList[i]);

}

}

 return pl;

}



	public String findTeamName(Player[] playerList, String playername)

{

 String team=null;

 

 for(int i=0;i<playerList.length;i++)

{

 if(playerList[i].getName().equals(playername))

{

 team=playerList[i].team.getName();

}

}

 return team;

}



	public Boolean findWhetherPlayersAreInSameTeam (Player[] playerList, String playername1, String playername2)

{

 int i;

 

 Team t1=new Team();

 

 Team t2=new Team();

 

 for(i=0;i<playerList.length;i++)

{

 if(playerList[i].getName().equals(playername1))

{

 t1=playerList[i].getTeam();

}

 if(playerList[i].getName().equals(playername2))

{

 t2=playerList[i].getTeam();

}

}

 if(t1.getName().equals(t2.getName()))

{

 return true;

}

 return false;

}

}







