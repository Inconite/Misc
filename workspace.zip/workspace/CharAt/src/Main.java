import java.util.*;
public class Main {
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter team1");
	String a=sc.nextLine();
	System.out.println("Enter team2");
	String b=sc.nextLine();
	System.out.println("Enter third character");
	String ch1=sc.nextLine();
	char ch=ch1.charAt(0);
	if(a.charAt(2)==ch)
	{
		System.out.println("Winner Team : "+a);
	}
	else
	{
		System.out.println("Winner Team : "+b);
	}
}
}
