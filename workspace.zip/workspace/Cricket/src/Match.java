

import java.text.DecimalFormat;

 

abstract class Match {





	private int currentScore;

 

	private float currentOver;

 

	private int target;

 

	public int getCurrentScore() {

 

 return currentScore;

}

	public void setCurrentScore(int currentScore) {

 

 this.currentScore = currentScore;

}

	public float getCurrentOver() {

 

 return currentOver;

}

	public void setCurrentOver(float currentOver) {

 

 this.currentOver = currentOver;

}

	public int getTarget() {

 

 return target;

}

	public void setTarget(int target) {

 

 this.target = target;

}

	DecimalFormat df=new DecimalFormat("0.00");

 

	abstract float calculateRunrate();

 

	abstract int calculateBalls();

 

	void display(double reqRunRate,int balls)

{

 System.out.println("Requirements:");

 

 System.out.println("Need "+(target-currentScore)+" Runs in "+balls+" balls");

 

 System.out.println("Required Run Rate - "+df.format(reqRunRate));

}

}