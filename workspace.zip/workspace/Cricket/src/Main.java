import java.util.Scanner;

 

public class Main {

  

	public static void main(String[] args) {





 Scanner sc=new Scanner(System.in);

 

 System.out.println("Enter the Cricket Format");

 

 System.out.println("1.ODI\n2.T20\n3.Test");



 int n=sc.nextInt();



 switch(n)

{

 case 1:System.out.println("Enter the Current Score");

 

 int cs=sc.nextInt();

 

 System.out.println("Enter the Current Over");

 

 float co=sc.nextFloat();

 

 System.out.println("Enter the Target Score");

 

 int ts=sc.nextInt();

 

 //System.out.println("Requirements:");

 

 ODIMatch odi=new ODIMatch();

odi.setCurrentScore(cs);

odi.setCurrentOver(co);

odi.setTarget(ts);



odi.display(odi.calculateRunrate(),odi.calculateBalls());

 break;



 case 2:System.out.println("Enter the Current Score");

cs=sc.nextInt();

 System.out.println("Enter the Current Over");

co=sc.nextFloat();

 System.out.println("Enter the Target Score");

ts=sc.nextInt();





 T20Match tt=new T20Match();

tt.setCurrentScore(cs);

tt.setCurrentOver(co);

tt.setTarget(ts);

tt.display(tt.calculateRunrate(), tt.calculateBalls());

 break;



 case 3:System.out.println("Enter the Current Score");

cs=sc.nextInt();

 System.out.println("Enter the Current Over");

co=sc.nextFloat();

 System.out.println("Enter the Target Score");

ts=sc.nextInt();

 //System.out.println("Requirements:");

 

 TestMatch tm=new TestMatch();

tm.setCurrentScore(cs);

tm.setCurrentOver(co);

tm.setTarget(ts);

tm.display(tm.calculateRunrate(), tm.calculateBalls());

 break;



 default:System.out.println("Invalid Format type");

 

 break;



}



}

}