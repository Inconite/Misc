public  class Sedan extends Car {



Boolean absEnabled;



Integer bootSpace;



public Boolean getAbsEnabled() {



return absEnabled;



}



public void setAbsEnabled(Boolean absEnabled) {



this.absEnabled = absEnabled;



}



public Integer getBootSpace() {



return bootSpace;



}



public void setBootSpace(Integer bootSpace) {



this.bootSpace = bootSpace;



}



public Sedan(Long id, String name, Boolean absEnabled, Integer bootSpace) {



super(id, name);



this.absEnabled = absEnabled;



this.bootSpace = bootSpace;



}



@Override



Double calculateDriveCost(Double dist)



 {



Double c;



if(bootSpace>600)



{



c=(15.0*dist);



c=c+(0.2*c);



return c;



}



else



{



c=15.0*dist;



return c;



}



 }



 



}

