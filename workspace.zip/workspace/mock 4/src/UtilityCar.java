public  class UtilityCar extends Car {



Boolean rearCooloingVents;



 



public Boolean getRearCooloingVents() {



return rearCooloingVents;



}



 



public void setRearCooloingVents(Boolean rearCooloingVents) {



this.rearCooloingVents = rearCooloingVents;



}
}