import java.util.Scanner;



public class Main {



	public static void main(String[] args) {

		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);

		Venue v=new Venue();

		System.out.println("Enter the venue name");

		v.setName(sc.nextLine());

		System.out.println("Enter the city name");

		v.setCity(sc.nextLine());

		System.out.println("Venue Details");

		System.out.println("Venue Name : "+v.getName());

		System.out.println("City Name : "+v.getCity());

		while(true)

		{

			System.out.println("Verify and Update Venue Details");

		System.out.println("Menu");

		System.out.println("1.Update Venue Name");

		System.out.println("2.Update City Name");

		System.out.println("3.All informations Correct/Exit");

		System.out.println("Type 1 or 2 or 3");

		int i=sc.nextInt();

		switch(i)                                                                                                                                                                                                                                                                                                                                           

		{

		case 1:

		System.out.println("Enter the venue name");

		sc.nextLine();

		String s=sc.nextLine();

		v.setName(s);

		System.out.println("Venue Details");

		System.out.println("Venue Name : "+v.getName());

		System.out.println("City Name : "+v.getCity());

		break;

		case 2:

		System.out.println("Enter the city name");

		sc.nextLine();

		String s1=sc.nextLine();

		v.setCity(s1);

		System.out.println("Venue Details");

		System.out.println("Venue Name : "+v.getName());

		System.out.println("City Name : "+v.getCity());

		break;

		case 3:System.out.println("Venue Details");

		System.out.println("Venue Name : "+v.getName());

		System.out.println("City Name : "+v.getCity());

		System.exit(0);

		break;

		}

			}



	}



}

