import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,k;
       Scanner sc=new Scanner(System.in);
       int a=sc.nextInt();
       int b=sc.nextInt();
       int count1=0,count2=0;
       for( i=a;i<=b;i++)
       {
    	    k=i;
    	   while(k>0)
    	   {
    		   int m=k%10;
    		   k=k/10;
    		   if(m!=0)
    		   {
    		   if(m%2==0)
    			   count1++;
    		   else count2++;
    		   }
    		   
    		   
    	   }
    	   if(count1==2 && count2==2)
    		   System.out.print(i+" ");
    	   
    	   count1=0;
    	   count2=0;
    	   
    	   
       }
		
		
		
		
		
		
		
		
		
		
	}

}
