import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the VIN to be validated:");
		String v=sc.nextLine();
		if(validateVIN(v))
		{
			System.out.println("VIN is valid");
		}
		else
		{
			System.out.println("VIN is invalid");
		}

	}
	
	public static boolean validateVIN(String vin)
	{
		if(vin.length()==17 && vin.matches("[A-Z0-9]{3}[A-Z]{2}[0-9][A-Z0-9][0-9]{2}[A-Z0-9]{2}[0-9]{6}"))
		{
			return true;
		}
		else
			return false;
		
	}

}
