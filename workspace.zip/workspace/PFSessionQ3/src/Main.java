import java.util.Scanner;
public class Main {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int flag=0;
		int d=sc.nextInt();
		int s1=sc.nextInt();
		int s2=sc.nextInt();
		int s3=sc.nextInt();
		int x=sc.nextInt();
		int diff=x-d;
		if(diff>=(s1+s2+s3))
			flag=flag+3;
		else if(diff>=(s1+s2))
			flag=flag+2;
		else if(diff>=(s1+s3))
			flag=flag+2;
		else if(diff>=(s2+s3))
			flag=flag+2;
		else if((diff>=s1)||(diff>=s2)||(diff>=s3))
			flag=flag+1;
		else
			flag=0;
		System.out.println(flag);
	}

}
