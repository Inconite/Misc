import java.text.SimpleDateFormat;

import java.util.Date;

public class UserMainCode {

	public static boolean checkDay(String date,int day) throws Exception

	{

		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");

		Date dt=sdf.parse(date);

		SimpleDateFormat sdf1=new SimpleDateFormat("DD");

		int i=Integer.valueOf(sdf1.format(dt));

		if(i==day)

		{

			return true;

		}

		return false;

	}

	public static String buffer(int m,int year,int d)

	{

		String buffer=null;

		if(m<=9)

		{

			buffer=year+"-0"+m+"-"+d;

		}

		else

		{

			buffer=year+"-"+m+"-"+d;

		}

		return buffer;

	}

	public static void displayDate(int year,int day) throws Exception

	{

		int m,d,leapDay=28;

		boolean flag=false;

		String buffer=null;

		if(year%400==0)

		{

			flag=true;

		}

		else if(year%100==0)

		{

			flag=false;

		}

		else if(year%4==0)

		{

			flag=true;

		}

		if(flag)

		{

			leapDay=29;

		}

		flag=false;

		for(m=1;m<=12;m++)

		{

			if(flag)

			{

				break;

			}

			if(m==1 || m==3 || m==5 || m==7 || m==8 || m==10 || m==12)

			{

				for(d=1;d<=31;d++)

				{

					buffer=UserMainCode.buffer(m, year, d);

					flag=UserMainCode.checkDay(buffer, day);

					if(flag)

					{

						break;

					}

					else

					{

						continue;

					}

				}

			}

			else if(m==2)

			{

				for(d=1;d<=leapDay;d++)

				{

					buffer=UserMainCode.buffer(m, year, d);

					flag=UserMainCode.checkDay(buffer, day);

					if(flag)

					{

						break;

					}

					else

					{

						continue;

					}

				}

			}

			else if(m==4 || m==6 || m==9 || m==11)

			{

				for(d=1;d<=30;d++)

				{

					buffer=UserMainCode.buffer(m, year, d);

					flag=UserMainCode.checkDay(buffer, day);

					if(flag)

					{

						break;

					}

					else

					{

						continue;

					}

				}

			}

		}

		System.out.println(day+"th day of "+year+" : "+buffer);	

	}

}