import java.util.Scanner;



public class Main {



	public static void main(String[] args) throws Exception

	{

		Scanner sc=new Scanner(System.in);

		UserMainCode.displayDate(sc.nextInt(), sc.nextInt());

		sc.close();



	}



}