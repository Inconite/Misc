import java.util.Scanner;
public class UserMainCode {
public static boolean validDate(String s)
{
int a=Integer.parseInt(s.substring(0,2));
int b=Integer.parseInt(s.substring(3,5));

if((a<=31) && (b<=12) && (s.charAt(2)=='-')&& (s.charAt(5)=='-'))
{
	return true;
}
else
	return false;
}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
