import java.util.Scanner;

public class Main {



	public static void main(String[] args) 

	{

		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the number of players");

		int a = sc.nextInt();

		sc.nextLine();

		Player player[] = new Player[a];

		for(int i=0;i<a;i++)

		{

			String name = null;

			String country = null;

			String skill = null;

			

			System.out.println("Enter the player name");

			name = sc.nextLine();

			System.out.println("Enter the country name");

			country = sc.nextLine();

			System.out.println("Enter the skill");

			skill = sc.nextLine();

			

			player[i]=new Player(name, country, skill);

		}

		

		PlayerBO playerbo = new PlayerBO();

		playerbo.displayAllPlayerDetails(player);

	}

}