import java.text.SimpleDateFormat;

import java.util.Date;

import java.util.Scanner;



public class Main {

	

	public static void main(String args[]) throws Exception

	{

		Customer c1[] = new Customer[2];

		Scanner sc = new Scanner(System.in);

		long id;

		String name=null,email=null,contact=null;

		char gender;

		String date;

		

		for(int i=0;i<2;i++)

		{

			System.out.println("Customer"+(i+1)+" :");

			System.out.println("id: ");

			id = sc.nextLong();

			sc.nextLine();

			System.out.println("name: ");

			name = sc.nextLine();

			System.out.println("Gender: ");

			gender = sc.next().charAt(0);

			sc.nextLine();

			System.out.println("email: ");

			email = sc.nextLine();

			System.out.println("contact number: ");

			contact = sc.nextLine();

			System.out.println("createdOn: ");

			date = sc.nextLine();

			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

			Date d = sdf.parse(date);

			

			c1[i] = new Customer(id, name, gender, email, contact, d);

		}

		

		for(int i=0;i<2;i++)

		{

			System.out.println("Customer id "+ c1[i].getId());

			System.out.println(c1[i].toString());

		}

		

		if((c1[0]).equals(c1[1]))

		{

			System.out.println("Customer 1 is same as Customer 2");

		}

		else

			System.out.println("Customer 1 and Customer 2 are different");

		

		sc.close();

	}

}