import java.util.*;

import java.text.*;

public class UserMainCode {

public void displayDate(String s) throws Exception{

		SimpleDateFormat sdf=new SimpleDateFormat("MMM dd, yyyy");

Date d=sdf.parse(s);

SimpleDateFormat sdf2=new SimpleDateFormat("yyyy-MM-dd");

String fd2=sdf2.format(d);



System.out.println(fd2);



}

}

