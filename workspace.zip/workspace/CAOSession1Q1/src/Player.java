
public class Player {
String name;
String country;
String skill;
}
