import java.util.*; 
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String pname;
		String cname;
		String pskill;
System.out.println("Enter the player name");
pname=sc.nextLine();
System.out.println("Enter the country name");
cname=sc.nextLine();
System.out.println("Enter the skill");
pskill=sc.nextLine();
Player player=new Player();
player.name=pname;
player.country=cname;
player.skill=pskill;
System.out.println("Player Details :");
System.out.println("Player Name : "+player.name);
System.out.println("Country Name : "+player.country);
System.out.println("Skill : "+player.skill);



}

}
