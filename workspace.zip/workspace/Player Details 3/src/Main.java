import java.util.*;

  public class Main {

  

	public static void main(String[] args) {

 

 Scanner sc=new Scanner(System.in);



 Player p=new Player();

 

 System.out.println("Enter the player name");

 

 p.setName(sc.nextLine());

 

 System.out.println("Enter the country name");

 

 p.setCountry(sc.nextLine());

 

 System.out.println("Enter the skill");

 

 p.setSkill(sc.nextLine());



 PlayerBO pl=new PlayerBO();

 

 pl.displayPlayerDetails(p);



 sc.close();

 }

}





