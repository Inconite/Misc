import java.util.*;

public class Main {

public static void main(String arag[]){

	Scanner sc=new Scanner(System.in);

	int n,i,l,flag=0;

	n=sc.nextInt();

	sc.nextLine();

	ArrayList<String> s=new ArrayList<String>();

	for(i=0;i<n;i++){

		s.add(sc.nextLine());

	}

	String x;

	

	for(i=0;i<s.size();i++){

		x=s.get(i);

		String a[]= x.split("-");

		if(a[1].equals(a[2])&&(a[1].equals("0"))){

			

			System.out.println(a[0]);

			flag=1;

		}

		

		

	}

	if(flag==0)

		System.out.println("No player has scored a duck");

	

	

}

}

