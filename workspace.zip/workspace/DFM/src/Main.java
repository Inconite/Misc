import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	int n,t1=2;
	n=sc.nextInt();
	while(t1<=n) {
		if(t1==n) {
			System.out.println("Yes");
			System.exit(1);
		}
		t1=t1+3;
	}
	System.out.println("No");
}
}
