import java.util.*;

import java.io.*;

public class Main {



	public static void main(String[] args) {

		// TODO Auto-generated method stub

		Scanner a=new Scanner(System.in);

		String l[]={"Chennai Super Kings","Deccan Chargers","Delhi Daredevils","Kings XI Punjab","Kolkata Knight Riders","Mumbai Indians","Rajasthan Royals","Royal Challengers Bangalore"};

		try

		{

			System.out.println("Enter the expected winner team of IPL Season 4");

			String w=a.nextLine();

			int flag=0;

			for(int i=0; i<l.length; i++)

			{

				if(w.equals(l[i]))

				{

					flag=1;

				}

			}

			if(flag==0)

			{

				throw new TeamNameNotFoundException("Entered team is not a part of IPL Season 4");

			}

			flag=0;

			System.out.println("Enter the expected runner Team of IPL Season 4");

			String r=a.nextLine();

			for(int i=0; i<l.length; i++)

			{

				if(r.equals(l[i]))

				{

					flag=1;

				}

			}

			if(flag==0)

			{

				throw new TeamNameNotFoundException("Entered team is not a part of IPL Season 4");

			}

			System.out.println("Expected IPL Season 4 winner: "+w);

			System.out.println("Expected IPL Season 4 runner: "+r);

		}

		catch(Exception e)

		{

			System.out.println(e);

		}

		

	}



}