public class TeamNameNotFoundException extends Exception

{

	public TeamNameNotFoundException(String s)

	{

		super (s);

	}

}