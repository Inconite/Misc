import java.text.ParseException;

import java.text.SimpleDateFormat;

import java.util.ArrayList;

import java.util.Collections;

import java.util.Comparator;

import java.util.Date;

import java.util.Iterator;

import java.util.Scanner;



public class Main {



	public static void main(String[] args) throws ParseException 

	{

		Scanner sc=new Scanner(System.in);

		ArrayList<Match> ar=new ArrayList<>();

		

		SimpleDateFormat sf=new SimpleDateFormat("MM-dd-yyyy");

		System.out.println("Enter the number of matches"); 

		int a=sc.nextInt();

		sc.nextLine();

		int j=1;

		for(int i=0;i<a;i++)

		{

		  

			System.out.println("Enter match date in (MM-dd-yyyy)"); 

		String date=sc.nextLine(); 

		Date d=sf.parse(date);

		System.out.println("Enter Team "+j); 

		String s=sc.nextLine();

		System.out.println("Enter Team "+(j+1)); 

		String s1=sc.nextLine();

		ar.add(new Match(d,s,s1));

		}

		Collections.sort(ar);

		Iterator<Match> i=ar.iterator();

		System.out.println("Match Details");

		while(i.hasNext())

		{

			System.out.println(i.next());

		}



	}



}





