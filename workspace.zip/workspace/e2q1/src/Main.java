import java.io.IOException;

import java.util.*;

public class Main {



	public static void main(String[] args)throws IOException {

		// TODO Auto-generated method stub

		Scanner a=new Scanner(System.in);

		System.out.println("Enter the player name");

		String s=a.nextLine();

		System.out.println("Enter the player age");

		int n=a.nextInt();

		try

		{

			if(n>=19)

			{

				System.out.println("Player name : "+s);

				System.out.println("Player age : "+n);

			}

			else

			{

				throw new CustomException("InvalidAgeRangeException");

			}

		}

		catch(Exception e)

		{

			System.out.println(e);

		}

	}



}