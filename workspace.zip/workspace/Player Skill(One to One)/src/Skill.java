public class Skill {

 

	private String skillName;



Skill()

{



}

 

	public Skill(String skillName) {

 

 super();

 

 this.skillName = skillName;

}



	public String toString()

{

 return (String.format("%-15s", skillName));

}

 

	public String getSkillName() {

 

 return skillName;

}

 

	public void setSkillName(String skillName) {

 

 this.skillName = skillName;

}





}