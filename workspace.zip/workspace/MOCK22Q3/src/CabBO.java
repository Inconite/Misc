import java.util.ArrayList;

import java.util.List;

public class CabBO {

	public List<Cab> findCab(List<Cab> cabList,String vehicletype){

		//Your code goes here...

		List<Cab> l=new ArrayList<Cab>();

		for(int i=0;i<cabList.size();i++)

		{

			if(cabList.get(i).getVehicleType().equals(vehicletype))

			{

				l.add(cabList.get(i));

			}

			

		}

		return l;

	}

	

	public List<Cab> findCab(List<Cab> cabList,Integer capacity){

		//Your code goes here...

		List<Cab> l1=new ArrayList<Cab>();

		for(int i=0;i<cabList.size();i++)

		{

			if(cabList.get(i).getCapacity()==(capacity))

			{

				l1.add(cabList.get(i));

			}

			

		}

		return l1;

	 }

}









