import java.util.*;

public class Main {



	public static void main(String[] args) {

		// TODO Auto-generated method stub

Scanner sc=new Scanner(System.in);

String n,c,s;

int i;

System.out.println("Enter the player name");

n=sc.nextLine();

System.out.println("Enter the country name");

c=sc.nextLine();

System.out.println("Enter the skill");

s=sc.nextLine();

Player p=new Player();

p.setCountry(c);

p.setName(n);

p.setSkill(s);



System.out.println("Player Details");

System.out.println("Player Name :"+p.getName());

System.out.println("Country Name :"+p.getCountry());

System.out.println("Skill :"+p.getSkill());

System.out.println("Verify and Update Player Details");



do{

	System.out.println("Menu");

	System.out.println("1.Update Player Name");

	System.out.println("2.Update Country Name");

	System.out.println("3.Update Skill");

	System.out.println("4.All informations Correct/Exit");

	System.out.println("Type 1 or 2 or 3 or 4");

	i=sc.nextInt();

	switch(i){

	case 1:

		sc.nextLine();

		System.out.println("The current player name is "+p.getName());

		System.out.println("Enter the player name");

		n=sc.nextLine();

		p.setName(n);

		break;

		

	case 2:

		sc.nextLine();

		System.out.println("The current country name is "+p.getCountry());

		System.out.println("Enter the country name");

		c=sc.nextLine();

		p.setCountry(c);

		break;

		

	case 3:

		sc.nextLine();

		System.out.println("The current skill is "+p.getSkill());

		System.out.println("Enter the skill");

		s=sc.nextLine();

		p.setSkill(s);

		break;

		

	default:

		System.out.println("Player Details");

		System.out.println("Player Name :"+p.getName());

		System.out.println("Country Name :"+p.getCountry());

		System.out.println("Skill :"+p.getSkill());

		System.exit(1);

		

	}

}while(4==4);

	}



}

