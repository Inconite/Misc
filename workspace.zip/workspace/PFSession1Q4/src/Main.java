import java.util.Scanner;
public class Main {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int f1=sc.nextInt();
		int f2=sc.nextInt();
		int f3=sc.nextInt();
		
		if(((f1>=100)&&(f2>=100)&&(f3>=100))||((f1>=100)&&(f2>=100))||((f2>=100)&&(f3>=100))||((f1>=100)&&(f3>=100))||((f1>=50)&&(f2>=50)&&(f3>=50)))
			System.out.println("Selected");
		else if(((f1>=100)||(f2>=100)||(f3>=100))||((f1>=50)&&(f2>=50))||((f1>=50)&&(f3>=50))||((f2>=50)&&(f3>=50)))
			System.out.println("Waitlisted");
		else
			System.out.println("Rejected");
	}

}

