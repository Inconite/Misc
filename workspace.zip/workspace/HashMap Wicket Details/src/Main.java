import java.util.HashMap;

import java.util.LinkedHashMap;

import java.util.Map;

import java.util.Scanner;

import java.util.TreeMap;



public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		LinkedHashMap<String,String> t=new LinkedHashMap<>();

		boolean b=true;

		while(b)

		{

		 

			 System.out.println("Enter the player name"); 

			 String name=sc.nextLine(); 

			 System.out.println("Enter wickets - seperated by \"|\" symbol"); 

			 String name1=sc.nextLine();

			 String s[]=name1.split("\\|");

			 System.out.println("Do you want to add another player (yes/no)"); 

			 String ch=sc.nextLine();

	

			 for(int i=0;i<s.length;i++)

			 {

			   t.put(s[i],name);

			 }

			 if(ch.equalsIgnoreCase("yes"))

			 {

				 b=true;

			 }

			 else b=false;

		   

		}

		

		boolean c=true;

		int flag=0;

		while(c)

		{

			flag=0;

			System.out.println("Enter the player name to search");

			String name2=sc.nextLine();

			int k=0;

			for(Map.Entry e:t.entrySet())

			{

				if(((String)e.getValue()).equalsIgnoreCase(name2))

				{

					while(k==0)

					{

					System.out.println("Player Name : "+name2);

					k++;

					System.out.println("Wickets :");

					}

					

					System.out.println(e.getKey());

					flag++;

					

				}

			}

			if(flag==0)

			System.out.println("No player found with the name "+name2);

			/*No player found with the name Morkel */

			 System.out.println("Do you want to search another player (yes/no)");

			String y=sc.nextLine();

			if(y.equalsIgnoreCase("yes"))

			{

			   c=true; 

			}

			else 

			{

				c=false;

			}

			

		}



	}



}



