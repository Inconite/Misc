import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	String s;
	System.out.println("Enter the player details");
s=sc.nextLine();
String d[]=s.split(",");
Player p=new Player();
p.name=d[0];
p.country=d[1];
p.skill=d[2];
System.out.println("Player Details :");
System.out.println("Player Name : "+d[0]);
System.out.println("Country Name : "+d[1]);
System.out.println("Skill : "+d[2]);
}
}
