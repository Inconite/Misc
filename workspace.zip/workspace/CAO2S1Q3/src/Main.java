import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the values for Innings 1"); 

		System.out.println("Enter the BattingTeam"); 

		 String s=sc.nextLine();

		System.out.println("Enter the runs scored"); 

		long a=sc.nextLong();

		sc.nextLine();

		System.out.println("Enter the values for Innings 2"); 

		System.out.println("Enter the BattingTeam"); 

		String s1=sc.nextLine();

		System.out.println("Enter the runs scored"); 

		long b=sc.nextLong();

		System.out.println("Innings 1 Details");

		Innings i=new Innings(s,a);

		i.display();

		System.out.println("Innings 2 Details");

		Innings i1=new Innings(s1,b);

		

		i1.display();

		

		



			
		
		
		
		
		
		
		
		
		
	}

}
