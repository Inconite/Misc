import java.util.*;

public class Main {



	public static void main(String[] args) {

		// TODO Auto-generated method stub

Scanner sc=new Scanner(System.in);

ExtraType et=new ExtraType();

System.out.println("Enter the extratype details");

String st=sc.nextLine();

String s[]=st.split("#");

String s2=s[0];

long a=Integer.parseInt(s[1]);

et.setName(s2);

et.setRuns(a);

System.out.println("ExtraType Details");

System.out.println("Extra Type:"+et.getName());

System.out.println("Runs:"+et.getRuns());

	}



}



