public class ExtraType {

String name;

long runs;

public String getName() {

	return name;

}

public void setName(String name) {

	this.name = name;

}

public long getRuns() {

	return runs;

}

public void setRuns(long runs) {

	this.runs = runs;

}



}