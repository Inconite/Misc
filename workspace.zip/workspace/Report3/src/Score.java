import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Score {
	//Your code goes here...
	private String examName;
	private Integer english;
	private Integer physics;
	private Integer chemistry;
	private Integer biology;
	private Integer computerScience;
	private Integer maths;
	private String studentName;
	Score(){}
	
	public Score(String examName, Integer english, Integer physics, Integer chemistry, Integer biology,
			Integer computerScience, Integer maths, String studentName) {
		super();
		this.examName = examName;
		this.english = english;
		this.physics = physics;
		this.chemistry = chemistry;
		this.biology = biology;
		this.computerScience = computerScience;
		this.maths = maths;
		this.studentName = studentName;
	}


	public String getExamName() {
		return examName;
	}


	public void setExamName(String examName) {
		this.examName = examName;
	}


	public Integer getEnglish() {
		return english;
	}


	public void setEnglish(Integer english) {
		this.english = english;
	}


	public Integer getPhysics() {
		return physics;
	}


	public void setPhysics(Integer physics) {
		this.physics = physics;
	}


	public Integer getChemistry() {
		return chemistry;
	}


	public void setChemistry(Integer chemistry) {
		this.chemistry = chemistry;
	}


	public Integer getBiology() {
		return biology;
	}


	public void setBiology(Integer biology) {
		this.biology = biology;
	}


	public Integer getComputerScience() {
		return computerScience;
	}


	public void setComputerScience(Integer computerScience) {
		this.computerScience = computerScience;
	}


	public Integer getMaths() {
		return maths;
	}


	public void setMaths(Integer maths) {
		this.maths = maths;
	}


	public String getStudentName() {
		return studentName;
	}


	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}


	static Map<String,Integer> subjectWiseCentumCount(List<Score> list){
		//Your code goes here...
		TreeMap<String, Integer> tm=new TreeMap();
		int bio=0,che=0,com=0,eng=0,mat=0,phy=0;
		for(Score sco:list)
		{
			if(sco.biology==100 )
				bio++;
			if( sco.chemistry==100)
				che++;
			if(sco.computerScience==100)
				com++;
			if(sco.english==100)
				eng++;
			if(sco.maths==100)
				mat++;
			if(sco.physics==100)
				phy++;
		}
				tm.put("Biology",bio );
				tm.put("Chemistry",che );
				tm.put("Computer Science",com );
				tm.put("English",eng );
				tm.put("Maths",mat );
				tm.put("Physics",phy );
				return tm;
		}
		
	}

