import java.util.*;
public class Main {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of scores");
		//Your code goes here...
		int n=Integer.parseInt(sc.nextLine());
		String ss[]=new String[n];
		List<Score> list=new ArrayList<Score>();
	
		Score s[]=new Score[n];
		String str[];
		for(int x=0;x<n;x++)
		{
			ss[x]=sc.nextLine();
			str=ss[x].split(",");
			s[x]=new Score(str[0],Integer.parseInt(str[1]),Integer.parseInt(str[2]),Integer.parseInt(str[3]),Integer.parseInt(str[4]),Integer.parseInt(str[5]),Integer.parseInt(str[6]),str[7]);
			list.add(s[x]);
		}
		Map tm=Score.subjectWiseCentumCount(list);
		Set set=tm.entrySet();
		Iterator i=set.iterator();
		System.out.format("%-16s %s\n","Subject","Count");
		while(i.hasNext())
		{
			Map.Entry me=(Map.Entry)i.next();
			System.out.format("%-16s %s\n",me.getKey(),me.getValue());
		}
	}
	   
}
