import java.util.Scanner;

public class Main {

	public static void main(String[] args) {



		// TODO Auto-generated method stub

  Scanner sc = new Scanner(System.in);

  Player play = new Player();

  System.out.println("Enter the player name");

  play.setName(sc.nextLine());

  System.out.println("Enter the country name");

  play.setCountry(sc.nextLine());

  System.out.println("Enter the skill");

  play.setSkill(sc.nextLine());

  System.out.println("Player Details");

  System.out.println("Player Name :"+play.getName());

  System.out.println("Country Name :"+play.getCountry());

  System.out.println("Skill :"+play.getSkill());

  System.out.println("Verify and Update Player Details");

  int n=0;

   

  do

  {

	  System.out.println("Menu");

 	System.out.println("1.Update Player Name");

 	System.out.println("2.Update Country Name");

 	System.out.println("3.Update Skill");

  System.out.println("4.All informations Correct/Exit");

  System.out.println("Type 1 or 2 or 3 or 4");

  n = sc.nextInt();

   

  switch(n)

  {

  case 1:

  {

   sc.nextLine();

   System.out.println("The current player name is "+play.getName());

  	System.out.println("Enter the player name");

  	String str2 = sc.nextLine();

   play.setName(str2);	

  	break;

  }



  case 2:

  {

   sc.nextLine();

   System.out.println("The current country name is "+play.getCountry());

  	System.out.println("Enter the country name");

   String str3 = sc.nextLine();

   play.setCountry(str3);

  	break;

  }



  case 3:

  {

   sc.nextLine();

   System.out.println("The current skill is "+play.getSkill());

  	System.out.println("Enter skill");

  	String str4 = sc.nextLine();

  	play.setSkill(str4);

  	break;

  }



  case 4:

  	 break;

  }



  }while(n!=4);



  System.out.println("Player Details");

  System.out.println("Player Name :"+play.getName());

  System.out.println("Country Name :"+play.getCountry());

  System.out.println("Skill :"+play.getSkill());

  sc.close(); 

	}



}