import java.util.*;

public class Main {

	public static void main(String args[])

	{

		Scanner sc=new Scanner(System.in);

		

		System.out.println("Enter player name");

		String name=sc.nextLine();

		System.out.println("Enter team name");

		String teamName=sc.nextLine();

		System.out.println("Enter number of matches");

		long noOfMatches=sc.nextLong();

		

		//Player p=new Player(name, teamName, noOfMatches);

		

		System.out.println("Menu");

		System.out.println("1.Bowler details");

		System.out.println("2.Batsman details");

		

		System.out.println("Enter choice");

		int ch=sc.nextInt();

		

		switch(ch)

		{

		case 1:

			System.out.println("Enter number of wickets taken");

			long noOfWickets=sc.nextLong();

			 Bowler b=new Bowler(name, teamName, noOfMatches, noOfWickets);

			 b.displayDetails();

			 break;

		case 2:

			System.out.println("Enter number of runs scored");

			long noOfRuns=sc.nextLong();

			Batsman b1=new Batsman(name,teamName, noOfMatches, noOfRuns);

			b1.displayDetails();

		}

	}



}



