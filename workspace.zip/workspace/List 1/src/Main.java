import java.util.*;

public class Main {

public static void main(String arag[]){

	Scanner sc=new Scanner(System.in);

	int n,i,sum=0;

	

	n=sc.nextInt();

	

	ArrayList<Integer> s=new ArrayList<Integer>();

	

	for(i=0;i<n;i++){

		s.add(sc.nextInt());

		

	}

	Iterator<Integer> it=s.iterator();

	while(it.hasNext())

	{

		sum=sum+it.next();

	}

	float fl=(float)sum/n;

System.out.println(sum);

System.out.printf("%.1f",fl);

	

	

	

	

}

}

