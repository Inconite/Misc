  import java.util.*;

import java.text.*;

public class UserMainCode {

public static void displayDay(String s) throws ParseException

{

	SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM-dd");

	SimpleDateFormat sdf2=new SimpleDateFormat("EEEEE");

	Date d1=sdf1.parse(s);

	System.out.println(sdf2.format(d1));

}

}