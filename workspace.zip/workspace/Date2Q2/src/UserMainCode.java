import java.util.*;

 import java.text.*;

 public class UserMainCode 

{

	public static void displayAge(String date1, String date2)throws Exception

{

 SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");

 Calendar c= Calendar.getInstance();

 Date d1= sdf.parse(date1);

 Date d2= sdf.parse(date2);

 c.setTime(d1);

 int Year= c.get(Calendar.YEAR);

 int Month= c.get(Calendar.MONTH);

 int Day= c.get(Calendar.DATE);

 c.setTime(d2);

 int Year1= c.get(Calendar.YEAR);

 int Month1= c.get(Calendar.MONTH);

 int Day1= c.get(Calendar.DATE);

 int y= Year1-Year;

 int m= Month1-Month;

 int d= Day1-Day;

 if(d<0)

{

 d=d+30;

 m--;

}

 //m--;

 if(m<0)

{

 m=m+12;

 y--;	

}

 System.out.println("I am  "+y+" years, "+m+" months and "+d+" days old.");

}

}

