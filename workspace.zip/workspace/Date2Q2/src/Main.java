import java.text.ParseException;

import java.util.Scanner;



public class Main {

	public static void main(String[] args) throws Exception {

		Scanner sc=new Scanner(System.in);

		String date1 = sc.nextLine();

		String date2 = sc.nextLine();

		UserMainCode.displayAge(date1, date2);

		sc.close();

	}

}