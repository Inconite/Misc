import java.text.SimpleDateFormat;

import java.time.LocalDate;

import java.time.Period;

import java.util.Calendar;

import java.util.Date;

public class UserMainCode {

	public static void displayAge(String birthDay,String presentDay)throws Exception

	{

		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");

		Date bDay=sdf.parse(birthDay);

		Date pDay=sdf.parse(presentDay);

		Calendar calPresent=Calendar.getInstance();

		calPresent.setTime(pDay);

		Calendar calBirth=Calendar.getInstance();

		calBirth.setTime(bDay);

		LocalDate birDay=LocalDate.of(calBirth.get(Calendar.YEAR), calBirth.get(Calendar.MONTH), calBirth.get(Calendar.DATE));

		LocalDate preDay=LocalDate.of(calPresent.get(Calendar.YEAR), calPresent.get(Calendar.MONTH), calPresent.get(Calendar.DATE));

		Period per=Period.between(birDay, preDay);

		System.out.println("I am  "+per.getYears()+" years, "+per.getMonths()+" months and "+(per.getDays()-1)+" days old.");

	}

}