import java.util.Scanner;



public class Main {



	public static void main(String[] args) throws Exception

	{

		Scanner sc=new Scanner(System.in);

		UserMainCode.displayAge(sc.nextLine(), sc.nextLine());

		sc.close();



	}



}