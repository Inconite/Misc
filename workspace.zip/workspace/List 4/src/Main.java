import java.util.*;

public class Main {

public static void main(String arag[]){

	Scanner sc=new Scanner(System.in);

	int n1,n2,i;

	String t;

	System.out.println("Enter the team name");

	t=sc.nextLine();

	System.out.println("Enter the number of matches played in home ground");

	n1=sc.nextInt();

	ArrayList<Integer>r1=new ArrayList<Integer>();

	System.out.println("Enter the runs scored");

	for(i=0;i<n1;i++){

		r1.add(sc.nextInt());

	}

	System.out.println("Enter the number of matches played in other ground");

	n2=sc.nextInt();

	ArrayList<Integer>r2=new ArrayList<Integer>();

	System.out.println("Enter the runs scored");

	for(i=0;i<n2;i++){

		r2.add(sc.nextInt());

	}

	System.out.println("Runs scored by "+t);

	r1.addAll(r2);

	Iterator it=r1.iterator();

	for(i=0;i<n1+n2;i++){

		System.out.println(it.next());
	}

	System.out.println("Run scored by "+t+" more than 300");

  int a;

	//for(i=0;i<r1.size();i++){

  it=r1.iterator();

  while(it.hasNext())

  {
		a=(Integer)it.next();

		//System.out.println("a="+a);

		if(a>300)

			System.out.println(a);

	}
}
}







