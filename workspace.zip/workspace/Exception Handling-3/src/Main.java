import java.util.*;

import java.io.*;

public class Main {



	public static void main(String[] args)throws Exception {

		// TODO Auto-generated method stub

		Scanner a=new Scanner(System.in);

		System.out.println("Enter the number of players");

		int n=a.nextInt();

		a.nextLine();

		System.out.println("Do you know the details of the captain? Type Yes / No");

		String c[]=new String[3];

		String s=a.nextLine();

		Player cp=null;

		if(s.equals("Yes"))

		{

			System.out.println("Enter name of the captain");

			c[0]=a.nextLine();

			System.out.println("Enter country of the captain");

			c[1]=a.nextLine();

			System.out.println("Enter skillset of the captain");

			c[2]=a.nextLine();

			cp=new Player(c[0], c[1],c[2]);

		}

		Player p[]=new Player[n];

		for(int i=0; i<n; i++)

		{

			System.out.println("Enter name of player "+(i+1));

			String name=a.nextLine();

			System.out.println("Enter country of player "+(i+1));

			String cou=a.nextLine();

			System.out.println("Enter skillset of player "+(i+1));

			String skill=a.nextLine();

			p[i]=new Player(name, cou,skill);

		}

		PlayerBO pb=new PlayerBO();

		try

		{

			pb.displayPlayerDetails(cp);

		}

		catch(Exception e)

		{

			System.out.println("Exception Occured : "+e.getClass().getCanonicalName());

			System.out.println("Captain details not available");

		}

		System.out.println("Player Details");

		for(int i=0; i<n;i++)

		{

			pb.displayPlayerDetails(p[i]);

		}

	}



}

