import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	String d,t1,t2,vn;
	System.out.println("Enter the match date");
	d=sc.nextLine();
	System.out.println("Enter the team one");
	t1=sc.nextLine();
	System.out.println("Enter the team two");
	t2=sc.nextLine();
	System.out.println("Enter the Venue");
	vn=sc.nextLine();
	Match m=new Match();
	m.setDate(d);
	m.setTeamOne(t1);
	m.setTeamTwo(t2);
	m.setVenue(vn);
	System.out.println("Match Details");
	String str=m.toString();
	System.out.println(str);
}
}
