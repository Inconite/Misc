public class UserMainCode {

 public static boolean validateTeam(String s)throws Exception

 {

  int flag=0;
  int n=s.length();
  boolean check = false;
   //String a=s.substring(0,4);
   char[] arr = s.toCharArray();
  for(int i=0;i<s.length();i++)
  {
	  if(i>=0 && i<=3)
	  {
		  check = Character.isDigit(arr[i]);
	  }
	  else if(i>3 && i<=n-2)
	  {
		  check = Character.isLetter(arr[i]);
	  }
	  else if(i==n-1)
	  {
		  check = Character.isDigit(arr[i]);
	  }
	  
	  
	  if(check == false)
		  return false;
		  
  }
  return true;
//   //int b=Integer.parseInt(a);
//   if(s.length()>3 && s.length()<21)
//   {
//	   flag++;
//   }
//   if(b>0)
//   {
//	   flag++;
//   }
//   int c=Integer.parseInt(s.substring(s.length()-1));
//   if (c>0 && c<9)
//   {
//	   flag++;
//   }
   
		   
//   if(flag==3)
//   {
//	   return true;
//   }
//   else return false;
//   
 }

}

