import java.util.*;

public class Main {

 public static void main(String[] args)throws Exception {

  // TODO Auto-generated method stub

  Scanner sc=new Scanner(System.in);

  String s=sc.nextLine();

  

  

  boolean b=UserMainCode.validateTeam(s);

  if(b)

  {

   System.out.println("Valid");

  }

  else

  {

   System.out.println("Invalid");

  }

 }

}







