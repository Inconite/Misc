class PlayerBO {

 void viewDetails(Player[] playerList)

   {

 	System.out.println("Player Details");

  	System.out.println(String.format("%-15s %-15s %s","Name","Country","Skill"));

 		for(int x=0;x<playerList.length;x++)

 		{

 			System.out.println(playerList[x].toString());

 		}

 	 }



 void printPlayerDetailsWithSkill(Player[] playerList,Skill[] skillList,String skill)

	{

 	 System.out.println("Skill Details");

  	System.out.println(String.format("%-15s %-15s %s","Name","Country","Skill"));

 	for(int x=0;x<playerList.length;x++)

 		{

 			if(playerList[x].getSkill().getSkill().equals(skill))

 			{

 		System.out.println(playerList[x].toString());

 		break;

 			}

 		}

	}

}