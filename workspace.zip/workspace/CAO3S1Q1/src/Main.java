
import java.util.Scanner;

public class Main {



	public static void main(String[] args) 

	{

		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);

		Player player = new Player();

		System.out.println("Enter the player name");

		player.setName(sc.nextLine());

		System.out.println("Enter the country name");

		player.setCountry(sc.nextLine());

		System.out.println("Enter the skill");

		player.setSkill(sc.nextLine());

		

		PlayerBO playerbo = new PlayerBO();

		playerbo.displayPlayerDetails(player);

	}



}