import java.util.Scanner;

public class Main 

{

	public static void main(String[] args) 

	{

		Scanner sc = new Scanner(System.in);

		int a=2;

		String x,y,z;

			System.out.println("Enter the player 1 details");

			System.out.println("Enter the player name");

			x = sc.nextLine();

			System.out.println("Enter the country name");

			y= sc.nextLine();

			System.out.println("Enter the skill");

			z = sc.nextLine();

			Player p1 = new Player(x,y,z);

			System.out.println(p1.toString());

			System.out.println("Enter the player 2 details");

			System.out.println("Enter the player name");

			x = sc.nextLine();

			System.out.println("Enter the country name");

			y= sc.nextLine();

			System.out.println("Enter the skill");

			z = sc.nextLine();

			Player p2 = new Player(x,y,z);

			System.out.println(p2.toString());

			if(p1.equals(p2))

				System.out.println("Both the player details are same.");

			else

				System.out.println("Both the player details are not same.");



	}

}


