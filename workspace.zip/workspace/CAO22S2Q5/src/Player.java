import java.util.*;
public class Player 

{

	String name;

	String country;

	String skill;

	

	public String getName() {

		return name;

	}

	public void setName(String name) {

		this.name = name;

	}

	public String getCountry() {

		return country;

	}

	public void setCountry(String country) {

		this.country = country;

	}

	public String getSkill() {

		return skill;

	}

	public void setSkill(String skill) {

		this.skill = skill;

	}

	

	Player()

	{

	}

	

	public Player(String name, String country, String skill) 

	{

		super();

		this.name = name;

		this.country = country;

		this.skill = skill;

	}

	

	public String toString()

	{

		return name+" --- "+country+" --- "+skill;

	}

	

	public boolean equals(Player p)

	{

		if(this.name.equals(p.name) && this.country.equals(p.country) && this.skill.equals(p.skill))

			return true;

		else

			return false;

	}

}