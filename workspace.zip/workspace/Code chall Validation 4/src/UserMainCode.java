
public class UserMainCode {
public  boolean ValidateTeam(String s) {

	
	s.matches(['A'-'Z'] {1}['a'-'z']{1,}[ ] {1}['A-Z] {1}[a-z]{1,}[@]{1}[A-Z] {1}[a-z] {1,}[*]{1}[A-Z] {1}[a-z] {1,}[*]{1});
	
}
}
