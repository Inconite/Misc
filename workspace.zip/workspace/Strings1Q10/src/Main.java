import java.util.*;

public class Main {

public static void main(String ar[])

{

    Scanner lol = new Scanner(System.in);

	int x=0;

	int y=0;

	int n = lol.nextInt();

	lol.nextLine();

	String s= lol.nextLine();

	int i;

	char[] ch= s.toCharArray();

	for(i=0;i<n;i++)

	{

	

		switch(ch[i])

		{

			case 'U' : y++; break;

			case 'D' : y--; break;

			case 'L' : x--; break;

			case 'R' : x++; break;

		}

	}

	

	System.out.println(x+" "+y);

}

}



