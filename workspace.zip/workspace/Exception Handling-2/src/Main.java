import java.util.*;

import java.io.*;

public class Main {



	public static void main(String[] args)throws IOException {

		// TODO Auto-generated method stub

		Scanner a=new Scanner(System.in);

		try

		{

			System.out.println("Enter the number of overs");

			int o=a.nextInt();

			if(o<0)

			{

				throw new NegativeArraySizeException();

			}

			System.out.println("Enter the number of runs for each over");

			int l[]=new int[o];

			for(int i=0;i<o; i++)

			{

				l[i]=a.nextInt();

			}

			System.out.println("Enter the over number");

			int ov=a.nextInt();

			System.out.println(l[ov-1]);

		}

		catch (Exception e)

		{

			System.out.println(e.getClass().getCanonicalName());

		}

	}



}