import java.util.ArrayList;

import java.util.Iterator;

import java.util.Scanner;



public class Main {



	public static void main(String[] args) 

	{

		Scanner sc=new Scanner(System.in);

		System.out.println("Enter number of teams:");

		

		int a=sc.nextInt();

		ArrayList<Team> ar=new ArrayList<>();

	  for(int i=0;i<a;i++)

	  {

	  	sc.nextLine();

	  	System.out.println("Enter team "+(i+1)+" detail"); 

	  	System.out.println("Enter Name"); 

	    String name=sc.nextLine(); 

	  	System.out.println("Enter number of matches"); 

	  	long b=sc.nextInt();

	  	ar.add(new Team(name,b));

	  	

	  }

	   

	  ar.sort(new TeamComparator());

  	Iterator<Team> itr=ar.iterator();

  	System.out.println("Team list after sort by number of matches");

  	while(itr.hasNext())

  	{

  		System.out.println(itr.next());

  	}



	}



}