import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	int n,i;
	n=sc.nextInt();
	sc.nextLine();
	HashSet<String> a=new HashSet<String>();
	for(i=0;i<n;i++)
	{
		a.add(sc.nextLine());
	}
	System.out.println(a.size());
}
}
