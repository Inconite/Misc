public class UserMainCode {



	public boolean validatePlayer(String a, String b, String c)



	{



		String d=" ";



		d=d.concat(b);



		//System.out.println(b);



		int count=0;



		String e="";



		for(int i=0; i<d.length();i++)



		{



			//System.out.println(d.charAt(i));



			if(d.charAt(i)==' ')



			{



				count++;



				e=e+Character.toString(d.charAt(i+1));



				//System.out.println(Character.toString(d.charAt(i+1))+" "+e);



			}



		}



		if(count==1)



		{



			e="";



			e=e.concat(b.substring(0, 3));



		}



		//System.out.println(e);



		String str=a.concat("#");



		str=str.concat(e);



		//System.out.println(str);



		if(str.equalsIgnoreCase(c))



		{



			return true;



		}



		else



		{



			return false;



		}



	}



}

