import java.util.*;
public class Main {







	public static void main(String[] args) {



		// TODO Auto-generated method stub



		Scanner a=new Scanner(System.in);



		UserMainCode u=new UserMainCode();



		String s1=a.nextLine();



		String s2=a.nextLine();



		String s3=a.nextLine();



		boolean b=u.validatePlayer(s1, s2, s3);



		if(b==true)



		{



			System.out.println("Valid");



		}



		else



		{



			System.out.println("Invalid");



		}



	}

}