public class Delivery {

	

	Delivery()

	{

		

	}

	

	void displayDeliveryDetails(String bowler, String batsman)

	{

		//System.out.println("Player details of the delivery:");

		int i;

		for(i=0;i<bowler.length();i++)

		{

			if(bowler.charAt(i)==' ')

				break;

		}

		

		System.out.println("Bowler :"+bowler.substring(i));

		

		for(i=0;i<batsman.length();i++)

		{

			if(batsman.charAt(i)==' ')

				break;

		}

		System.out.println("Batsman :"+batsman.substring(i));



	}

	

	

	void displayDeliveryDetails(long runs)

	{

		System.out.println("Number of runs scored in the delivery : "+runs);

		if(runs==4)

		{

			System.out.println("It is a Boundary.");

		}

		if(runs==6)

		{

			System.out.println("It is a Sixer.");

		}

	}

	

}

