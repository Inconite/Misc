
import java.util.Scanner;

public class Main {



	public static void main(String[] args) 

	{

		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);

		Innings i[] = new Innings[2];

		String battingTeam = null;

		long runs = 0;

		

		i[0]=new Innings(battingTeam, runs);

		System.out.println("Enter the values for FirstInnings");

		System.out.println("Enter the BattingTeam");

		i[0].setBattingTeam(sc.nextLine());

		System.out.println("Enter the runs scored");

		i[0].setRuns(sc.nextLong());

		sc.nextLine();

		i[1]=new Innings(battingTeam, runs);

		System.out.println("Enter the values for SecondInnings");

		System.out.println("Enter the BattingTeam");

		i[1].setBattingTeam(sc.nextLine());

		System.out.println("Enter the runs scored");

		i[1].setRuns(sc.nextLong());

		

		InningsBO inningsbo = new InningsBO();

		inningsbo.displayAllInningsDetails(i);

	}

}