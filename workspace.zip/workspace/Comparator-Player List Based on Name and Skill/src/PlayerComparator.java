import java.util.Comparator;



public class PlayerComparator implements Comparator 

{



	@Override

	public int compare(Object o1, Object o2) {

		Player p=(Player)o1;

		Player p1=(Player)o2;

		if(p.getName().compareTo(p1.getName())>0)

			return 1;

		else if(p.getName().compareTo(p1.getName())==0)

			return 0;

		else return -1;

	}



}