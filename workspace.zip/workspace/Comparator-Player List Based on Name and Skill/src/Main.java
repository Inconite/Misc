import java.util.ArrayList;

import java.util.Iterator;

import java.util.Scanner;



public class Main {



	public static void main(String[] args) 

	{

		// TODO Auto-generated method stub

  Scanner sc=new Scanner(System.in);

  String name1="ajay";

  System.out.println("Please provide the number of players to be registered");

  int a=sc.nextInt();

   

  ArrayList<Player> ar=new ArrayList<>();

  for(int i=0;i<a;i++)

  {

  	sc.nextLine();

  	System.out.println("Please enter player name"); 

  	String name=sc.nextLine();

  	System.out.println("Please select the skill of the player"); 

  	System.out.println("1.All Rounder\n2.Batsman\n3.Bowler"); 

  	int b=sc.nextInt();

  	

  	if(b==1)

  	{

  		name1="All Rounder";

  	}

  	else if(b==2)

  	{

  		name1="Batsman";

  	}

  	

  	else

  		name1="Bowler";

  	ar.add(new Player(name,name1));

  }

   

     ar.sort(new PlayerComparator());



     int flag=0;

     Player p;

     int j=0;

     String z[]={"All Rounder","Batsman","Bowler"};

     System.out.println("Player Details");

    for(int i=0;i<z.length;i++)

    {

    	 Iterator<Player> itr1=ar.iterator();

    	 while(itr1.hasNext())

    	 {

    		p=itr1.next();

    		 if(z[j].equalsIgnoreCase(p.getSkill()))

    		{

    			System.out.println(p);

    		}

    	 }

    	 j++;

    }

     

	}

	

}



