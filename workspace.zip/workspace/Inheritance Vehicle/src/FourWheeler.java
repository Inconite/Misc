public class FourWheeler extends Vehicle{

private String audioSystem;

private int numberOfDoors;



public String getAudioSystem() {

	return audioSystem;

}



public void setAudioSystem(String audioSystem) {

	this.audioSystem = audioSystem;

}



public int getNumberOfDoors() {

	return numberOfDoors;

}



public void setNumberOfDoors(int numberOfDoors) {

	this.numberOfDoors = numberOfDoors;

}

Vehicle v=new Vehicle(make,vehicleNumber,fuelType,fuelCapacity,cc);

FourWheeler(String a, String b, String c, int d, int e,String s,int i)

{

	super(a,b,c,d,e);

	this.audioSystem=s;

	this.numberOfDoors=i;

}



public void displayDetailInfo()

{

	/*super.displayMake();

	super.displayBasicInfo();

	super.displayDetailInfo();*/

	System.out.println("---Detail Information---");

	System.out.println("Audio System:"+audioSystem);

	System.out.println("Number of Doors:"+numberOfDoors);

	

}



}

