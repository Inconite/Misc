
import java.util.*;

public class Main {



	public static void main(String[] args) {

		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);

System.out.println("1.Four Wheeler\n2.Two Wheeler\nEnter Vehicle Type:");

int ch=sc.nextInt();

String fuelType = null;

String fuelType1=null;

boolean kickStartAvailable;

switch(ch)

{



case 1:

	sc.nextLine();

	System.out.println("Vehicle Make:");

		String make=sc.nextLine();

		 System.out.println("Vehicle Number:");

			String vehicleNumber=sc.nextLine();

			

			System.out.println("Fuel Type:\n1.Petrol\n2.Diesel");

			int fc=sc.nextInt();

			if(fc==2)

			{

				fuelType="Diesel";

			}

			else if(fc==1)

			{

				fuelType="Petrol";

			}

				System.out.println("Fuel Capacity:");

				int fuelCapacity=sc.nextInt();

				

				System.out.println("Engine CC:");

				int cc=sc.nextInt();

				sc.nextLine();

				System.out.println("Audio System:");

				String audioSystem=sc.nextLine();

				System.out.println("Number of Doors:");

				int numberOfDoors=sc.nextInt();

				FourWheeler fw=new FourWheeler(make, vehicleNumber,fuelType,fuelCapacity,cc,audioSystem,numberOfDoors);

				fw.displayMake();

				fw.displayBasicInfo();

				fw.displayDetailInfo();

				break;

case 2: 

	sc.nextLine();

	System.out.println("Vehicle Make:");

String make1=sc.nextLine();

 System.out.println("Vehicle Number:");

	String vehicleNumber1=sc.nextLine();

	

	System.out.println("Fuel Type:\n1.Petrol\n2.Diesel");

	int fc1=sc.nextInt();

	if(fc1==2)

	{

		fuelType1="Diesel";

	}

	else if(fc1==1)

	{

		fuelType1="Petrol";

	}

		System.out.println("Fuel Capacity:");

		int fuelCapacity1=sc.nextInt();

		

		System.out.println("Engine CC:");

		int cc1=sc.nextInt();

		sc.nextLine();

		System.out.println("Kick Start Available(yes/no):");

		String kick=sc.nextLine();

		if(kick.equals("yes"))

			kickStartAvailable=true;

		else

			kickStartAvailable=false;

		TwoWheeler tw=new TwoWheeler(make1, vehicleNumber1,fuelType1,fuelCapacity1,cc1,kickStartAvailable);

		tw.displayMake();

		tw.displayBasicInfo();

		tw.displayDetailInfo();

		break;

			

		

}

}

	}