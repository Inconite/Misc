public class TwoWheeler extends Vehicle{

private Boolean kickStartAvailable;

TwoWheeler()

{

 

}

Vehicle v=new Vehicle(make,vehicleNumber,fuelType,fuelCapacity,cc);

TwoWheeler(String a, String b, String c, int d, int e,boolean f)

{

 super(a,b,c,d,e);

 this.kickStartAvailable=f;

}

public void displayDetailInfo()

{

 /*super.displayMake();

 super.displayBasicInfo();

 super.displayDetailInfo();*/

 System.out.println("---Detail Information---");

 if(kickStartAvailable==true)

 {

  System.out.println("Kick Start Available:YES");

 }

 else

  System.out.println("Kick Start Available:NO");

 

}

}