import java.io.BufferedReader;

import java.io.InputStreamReader;

import java.text.SimpleDateFormat;

import java.util.ArrayList;

import java.util.Date;

import java.util.Iterator;

import java.util.List;

public class Main {

  public static void main(String[] args)throws Exception {

		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

		List<Contact> list=new ArrayList<Contact>();

		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");

		ContactBO cb = new ContactBO();

		System.out.println("Enter the number of contact details:");

		int n = Integer.parseInt(br.readLine());

		for(int i=0;i<n;i++)

		{

			String split[]=br.readLine().split(",");

			list.add(new Contact(split[0], split[1], split[2], split[3], split[4], split[5], sdf.parse(split[6])));

		}

		System.out.println("Enter a search type:\n1.Name\n2.Date created\n3.Email domain");

		int choice=Integer.parseInt(br.readLine());

		if(choice==1){

			List<String> name=new ArrayList<String>();

			System.out.println("Enter the names:");

			String names[]=br.readLine().split(",");

			for(int i=0;i<names.length;i++)

			{

				name.add(names[i]);

			}

			List<Contact> contactList=cb.findContact(list, name);

			System.out.format("%-15s %-15s %-20s %-15s %-20s %-15s %s\n", "Name","Company","Title","Mobile","Alternate Mobile","Email","Date Created");

			Iterator<Contact> itr=contactList.iterator();

			while(itr.hasNext())

			{

				System.out.println(itr.next().toString());

			}

		}

		else if(choice==2){

			System.out.println("Enter the date to search contacts that were created on that date");

			List<Contact> contactList=cb.findContact(list, sdf.parse(br.readLine()));

			System.out.format("%-15s %-15s %-20s %-15s %-20s %-15s %s\n", "Name","Company","Title","Mobile","Alternate Mobile","Email","Date Created");

			Iterator<Contact> itr=contactList.iterator();

			while(itr.hasNext())

			{

				System.out.println(itr.next().toString());

			}

	}

		else if(choice==3){

			System.out.println("Enter the Email domain to search contacts that have same email domain");

			List<Contact> contactList=cb.findContact(list, br.readLine());

			System.out.format("%-15s %-15s %-20s %-15s %-20s %-15s %s\n", "Name","Company","Title","Mobile","Alternate Mobile","Email","Date Created");

			Iterator<Contact> itr=contactList.iterator();

			while(itr.hasNext())

			{

				System.out.println(itr.next().toString());

			}

			}

		else{

			System.out.println("Invalid choice");

		}

	}

}