import java.util.*;

public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		System.out.println("Enter the number of players");

		int n=sc.nextInt();

		sc.nextLine();

		System.out.println("Enter the player name");

		String a[]=new String[n];

		for(int i=0;i<n;i++)

		{

			a[i]=sc.nextLine();

		}

		String b[]=new String[n];

		String s="";

		int c=0;

		for(int i=0;i<n;i++)

		{

			s=a[i];

			if(s.startsWith("M") || s.endsWith("a"))

			{

				b[c]=s;

				c++;

			}

		}

		System.out.println("Player name starting with \'M\' or Ending with \'a\'");

		for(int i=0;i<c;i++)

		{

			System.out.println(b[i]);

		}

		

	}



}



