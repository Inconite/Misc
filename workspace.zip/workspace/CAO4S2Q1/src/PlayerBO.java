
public class PlayerBO {
	Player p;
Player createPlayer(String data){
	String a[]=data.split(,);
	String name=a[0];
	String country=a[1];
	String skill=a[2];
	p=new Player(name,country,skill);
	return p;
	
	
}
}
