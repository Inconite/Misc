
public class MatchBO {

}
