import java.util.*;



public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		

		System.out.println("Enter the number of players");

		int n=sc.nextInt();

		sc.nextLine();

		

		Player p[]=new Player[n];

		int i;

		String player=null;

		String country=null;

		String skill=null;

		

		for(i=0;i<n;i++)

		{

			System.out.println("Enter the player name");

			player=sc.nextLine();

			System.out.println("Enter the country name");

			country=sc.nextLine();

			System.out.println("Enter the skill");

			skill=sc.nextLine();

			p[i]=new Player(player, country, skill);		

		}

		

		PlayerBO pl=new PlayerBO();

		pl.displayAllPlayerDetails(p);

		

		System.out.println("Enter the country name for which players details to be known");

		String name=sc.nextLine();

		pl.displaySpecificPlayerDetails(p, name);

		

		sc.close();

	}



}



