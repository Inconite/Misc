import java.util.*;

public class Main {



	public static void main(String[] args) {

		// TODO Auto-generated method stub

Scanner sc=new Scanner(System.in);

int n=sc.nextInt(),i,j;

for(i=0;i<n;i++){

	for(j=0;j<n;j++){

		if(i==j)

			System.out.print(i);

		else

			System.out.print("0");

		

		

	}

	System.out.println();

	

	

}



	}



}

