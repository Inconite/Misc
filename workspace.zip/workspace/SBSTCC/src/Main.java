import java.util.*;

class Main

{

  public static void main(String[] args)

  {

    Scanner sc = new Scanner(System.in);

    String s =sc.nextLine();

    int c1=0,c2=0,f=0,f1=0;

    for(int i=0;i<s.length();i++)

    {

    if(i%2==0)

    {

      char x = s.charAt(i);

      if(x=='a'||x=='e'||x=='i'||x=='o'||x=='u'||x=='A'||x=='E'||x=='I'||x=='O'||x=='U')

      {

       

      c1++;

    }

    }

    else

    {

      char x = s.charAt(i);

      if(x=='a'||x=='e'||x=='i'||x=='o'||x=='u'||x=='A'||x=='E'||x=='I'||x=='O'||x=='U')

      {

      c2++;

      }

    }

    }

    if(c1>c2)

    System.out.println("Lucky");

    else

    System.out.println("Unlucky");

     

  }

}

