public class UserMainCode {



public static boolean validateOver(String s)



{



	char ch;



	int count=0;



	for(int i=0;i<6;i++)



	{



		ch=s.charAt(i);



		int l=s.length();



		if(l<6 || l>6)



		{



			return false;



		}



		if(ch=='W')



		{



			count++;



		}



		else if(ch=='N')



		{



			return false;



		}



		else



		{



			if(Character.isDigit(ch)==false)



			{



				return false;



			}



		}



	}



	



	if(count>=1)



	{	



		return true;



	}



	else



		return false;



}



}