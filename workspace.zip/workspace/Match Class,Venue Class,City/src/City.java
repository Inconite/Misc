public class City {

  

	private String name;



City()

{



}

 

	public City(String name) {

 

 super();

 

 this.name = name;

}



	public String toString()

{

 return name;

}

 

	public String getName() {

 

 return name;

}

 

	public void setName(String name) {

 

 this.name = name;

}

}