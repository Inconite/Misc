import java.util.Scanner;

  public class Main {

  

	public static void main(String[] args) {



 Scanner sc=new Scanner(System.in);



 int i,choice;

 

 boolean flag=true;

 

 String buffer;





 System.out.println("Enter the city count");

 

 int cc=sc.nextInt();

 

 sc.nextLine();

 

 City cityList[]=new City[cc];

 

 CityBO cbo=new CityBO();

 

 for(i=0;i<cc;i++)

{

 System.out.println("Enter city "+(i+1)+" details");

 

 cityList[i]=cbo.createCity(sc.nextLine());

}





 System.out.println("Enter the venue count");

 

 int vc=sc.nextInt();

 

 sc.nextLine();

 

 Venue venueList[]=new Venue[vc];

 

 VenueBO vbo=new VenueBO();

 

 for(i=0;i<vc;i++)

{

 System.out.println("Enter venue "+(i+1)+" details");

 

 venueList[i]=vbo.createVenue(sc.nextLine(), cityList);

}





 System.out.println("Enter the match count");

 

 int mc=sc.nextInt();

 

 sc.nextLine();

 

 Match matchList[]=new Match[mc];

 

 MatchBO mbo=new MatchBO();

 

 for(i=0;i<mc;i++)

{

 System.out.println("Enter match "+(i+1)+" details");

 

 matchList[i]=mbo.createMatch(sc.nextLine(), venueList);

}



 System.out.println("Menu :\n1)Find Venue\n2)Find All Matches In A Specific Venue\nType 1 or 2");

 

 do{

 

 System.out.println("Enter your choice");

 

 choice=sc.nextInt();



 switch(choice)

{

 case 1:

 

 sc.nextLine();

 

 System.out.println("Enter Match Date");

 

 buffer=sc.nextLine();

 

 mbo.findVenue(buffer, matchList);

 

 break;

 

 case 2:

 

 sc.nextLine();

 

 System.out.println("Enter Venue Name");

 

 buffer=sc.nextLine();

 

 mbo.findAllMatchesInGivenVenue(buffer, matchList);

 

 break;

 

 default:

System.exit(0);

}



 System.out.println("Do you want to continue? Type Yes or No");

 

 buffer=sc.nextLine();

 

 if(buffer.equals("Yes"))

{

 flag=true;

}

 else

 {

 flag=false;

}

 }while(flag);



 sc.close();

}

}