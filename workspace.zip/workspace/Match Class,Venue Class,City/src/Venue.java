public class Venue {

  

	private String name;

 

	City city;



Venue()

{



}

 

	public Venue(String name, City city) {

 

 super();

 

 this.name = name;

 

 this.city = city;

}



	public String toString()

{

 return "Match was held at "+name;

}

 

	public String getName() {

 

 return name;

}

 

	public void setName(String name) {

 

 this.name = name;

}

 

	public City getCity() {

 

 return city;

}

 

	public void setCity(City city) {

 

 this.city = city;

}

}

