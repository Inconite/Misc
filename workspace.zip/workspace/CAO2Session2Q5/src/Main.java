
import java.util.Scanner;  



public class Main



 {



 public static void main(String[] args) {



  // TODO Auto-generated method stub



  Scanner sc = new Scanner(System.in);



  Venue play = new Venue();



  System.out.println("Enter the venue name");



  play.setName(sc.nextLine());



  System.out.println("Enter the city name");



  play.setCity(sc.nextLine());



   



  System.out.println("Venue Details");



  System.out.println("Venue Name : "+play.getName());



  System.out.println("City Name : "+play.getCity());



  System.out.println("Verify and Update Venue Details");



  int n=0;



  



  do



  {



  System.out.println("Menu");



  System.out.println("1.Update Venue Name");



  System.out.println("2.Update City Name");



  System.out.println("3.All informations Correct/Exit");



  System.out.println("Type 1 or 2 or 3");



  n = sc.nextInt();



  switch(n)



  {



  case 1:



  {



   sc.nextLine();



  	System.out.println("Enter the venue name");



  	String str2 = sc.nextLine();



   play.setName(str2);	



   System.out.println("Venue Details");



   System.out.println("Venue Name : "+play.getName());



   System.out.println("City Name : "+play.getCity());



   System.out.println("Verify and Update Venue Details");



  	break;



  }



  case 2:



  {



   sc.nextLine();



  	System.out.println("Enter the city name");



   String str3 = sc.nextLine();



   play.setCity(str3);



   System.out.println("Venue Details");



   System.out.println("Venue Name : "+play.getName());



   System.out.println("City Name : "+play.getCity());



   System.out.println("Verify and Update Venue Details");



  	break;



  }



  case 3:



  	 System.out.println("Venue Details");



    System.out.println("Venue Name : "+play.getName());



    System.out.println("City Name : "+play.getCity());



  	 break;



  }	 



  	



  }while(n!=3);



   



  sc.close();



 }



 }