import java.util.Scanner;
public class Main {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int count=0;
		int g1=sc.nextInt();
		int g2=sc.nextInt();
		int g3=sc.nextInt();
		int x=sc.nextInt();
		boolean c=sc.nextBoolean();
		
		if(c==true)
			count=count+3;
		else
		{
			if(x>=(g1+g2+g3))
				count=count+3;
			else if(x>=(g1+g2))
				count=count+2;
			else if(x>=(g1+g3))
				count=count+2;
			else if(x>=(g2+g3))
				count=count+2;
			else if((x>=g1)||(x>=g2)||(x>=g3))
				count=count+1;
			else
				count=0;
		}
		System.out.println(count);
	}

}
