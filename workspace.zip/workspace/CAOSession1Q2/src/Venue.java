class Venue {

 String name;

 String city;

}

