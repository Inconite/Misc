import java.util.Scanner;



public class Main {



	public static void main(String[] args) {

		// TODO Auto-generated method stub

    Scanner sc = new Scanner(System.in);

    Venue venue = new Venue();

    System.out.println("Enter the venue name");

    venue.name =sc.nextLine();

    System.out.println("Enter the city name");

    venue.city = sc.nextLine();

    System.out.println("Venue Details :");

    System.out.println("Venue Name : "+venue.name);

    System.out.println("City Name : "+venue.city);

    sc.close();

	}



}

