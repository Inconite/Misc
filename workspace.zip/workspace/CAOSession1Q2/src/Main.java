import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner sc=new Scanner(System.in);
        String vname;
        String vcity;
        System.out.println("Enter the venue name");
        vname=sc.nextLine();
        System.out.println("Enter the city name");
        vcity=sc.nextLine();
        Venue venue=new Venue();
        venue.name=vname;
        venue.city=vcity;
        System.out.println("Venue Details :");
        System.out.println("Venue Name : "+venue.name);
        System.out.println("City Name : "+venue.city);
        
        
	}

}
