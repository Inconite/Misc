import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	int n,i,ts=0,sum=0;
	n=sc.nextInt();
	ArrayList<Integer>r1=new ArrayList<Integer>();
for(i=0;i<n;i++)
{
	r1.add(sc.nextInt());
ts=ts+r1.get(i);

if((i%2==0 && r1.get(i)%2!=0)||(i%2!=0 && r1.get(i)%2==0)){
	sum=sum+r1.get(i);
}
}
System.out.println(ts-sum);
}
}
