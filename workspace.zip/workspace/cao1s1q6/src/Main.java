import java.util.*;
public class Main {
	public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	String s;
	System.out.println("Enter the venue details");
s=sc.nextLine();
String d[]=s.split(",");
Venue v=new Venue();
v.name=d[0];
v.city=d[1];

System.out.println("Venue Details");
System.out.println("Venue Name : "+d[0]);
System.out.println("City Name : "+d[1]);
}
}
