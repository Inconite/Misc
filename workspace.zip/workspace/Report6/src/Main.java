import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.Iterator;
import java.util.List;

public class Main 
{
	public static void main(String args[]) throws NumberFormatException, IOException, ParseException 
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		List<Student> studentList=Student.prefill();
		System.out.println("Enter the number of scores:");
		int n=Integer.parseInt(br.readLine());
		for(int i=0;i<n;i++)
		{
			String split[]=br.readLine().split(",");
			Student student=null;
			Iterator<Student> itr=studentList.iterator();
			int j=0;
			while(itr.hasNext())
			{
				student=itr.next();
				if(student.getName().equals(split[7]))
				{
					break;
				}
				j++;
			}
			Score score=new Score(split[0], Integer.parseInt(split[1]), Integer.parseInt(split[2]), Integer.parseInt(split[3]), Integer.parseInt(split[4]), Integer.parseInt(split[5]), Integer.parseInt(split[6]), student);
			studentList.get(j).setScore(score);
		}
		Student topperStudent=Student.getTopper(studentList);
		System.out.println("The topper of the class is "+topperStudent.getName());
	}
}
