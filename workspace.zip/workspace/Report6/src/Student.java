import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class Student {
	
	private String rollNo;
	private String name;
	private Date dateOfBirth;
	private int standard;
	private Score score;
	
	public static List<Student> prefill() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		List<Student> list = new ArrayList<>();
		list.add(new Student("11HIGH08","Harry",sdf.parse("12-05-2002"),12, null));
		list.add(new Student("11HIGH03","Danny",sdf.parse("23-08-2001"),12, null));
		list.add(new Student("11HIGH08","Victor",sdf.parse("05-11-2003"),12, null));
		list.add(new Student("11HIGH53","Oliver",sdf.parse("01-02-2002"),12, null));
		list.add(new Student("11HIGH27","Lucas",sdf.parse("29-12-2003"),12, null));
		list.add(new Student("11HIGH88","Will",sdf.parse("30-01-2001"),12, null));
		return list;
	}
	
	public static Student getTopper(List<Student> list) {
		Student student=null;
		Iterator<Student> itr=list.iterator();
		int total[]=new int[list.size()];
		int i=0;
		while(itr.hasNext())
		{
			student=itr.next();
			total[i++]=student.getScore().getEnglish() + student.getScore().getPhysics() + student.getScore().getChemistry() + student.getScore().getBiology() + student.getScore().getComputerScience() + student.getScore().getMaths();
		}
		int max = total[0];
		for(i = 0; i < total.length;i++)
		{
			if(total[i] > max)
			{
				max = total[i];
			}
		}
		int count=0;
		for(i = 0; i < total.length;i++)
		{
			if(total[i]==max)
				count++;
		}
		if(count==1)
		{
			for(i = 0; i < total.length;i++)
			{
				if(max==total[i])
				{
					student=list.get(i);
				}
			}
		}
		else if(count==2)
		{
			Student s1=null, s2=null;
			for(i = 0; i < total.length; i++)
			{
				if(max==total[i])
				{
					s1=list.get(i);
					break;
				}
			}
			for(i = total.length-1; i >=0; i--)
			{
				if(max==total[i])
				{
					s2=list.get(i);
					break;
				}
			}
			if(s1.getScore().getMaths()>s2.getScore().getMaths())
			{
				student=s1;
			}
			else
			{
				student=s2;
			}
		}
		return student;
	}
	
	public Student() {
		super();
	}
	
	public Student(String rollNo, String name, Date dateOfBirth, int standard, Score score) {
		super();
		this.rollNo = rollNo;
		this.name = name;
		this.dateOfBirth = dateOfBirth;
		this.standard = standard;
		this.score = score;
	}

	public String getRollNo() {
		return rollNo;
	}

	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public int getStandard() {
		return standard;
	}

	public void setStandard(int standard) {
		this.standard = standard;
	}

	public Score getScore() {
		return score;
	}

	public void setScore(Score score) {
		this.score = score;
	}
	
}
