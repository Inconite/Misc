public class Score {
	
	private String examName;
	private int english;
	private int physics;
	private int chemistry;
	private int biology;
	private int computerScience;
	private int maths;
	private Student student;
	public Score() {
		super();
	}
	public Score(String examName, int english, int physics, int chemistry, int biology, int computerScience, int maths,
			Student student) {
		super();
		this.examName = examName;
		this.english = english;
		this.physics = physics;
		this.chemistry = chemistry;
		this.biology = biology;
		this.computerScience = computerScience;
		this.maths = maths;
		this.student = student;
	}
	public String getExamName() {
		return examName;
	}
	public void setExamName(String examName) {
		this.examName = examName;
	}
	public int getEnglish() {
		return english;
	}
	public void setEnglish(int english) {
		this.english = english;
	}
	public int getPhysics() {
		return physics;
	}
	public void setPhysics(int physics) {
		this.physics = physics;
	}
	public int getChemistry() {
		return chemistry;
	}
	public void setChemistry(int chemistry) {
		this.chemistry = chemistry;
	}
	public int getBiology() {
		return biology;
	}
	public void setBiology(int biology) {
		this.biology = biology;
	}
	public int getComputerScience() {
		return computerScience;
	}
	public void setComputerScience(int computerScience) {
		this.computerScience = computerScience;
	}
	public int getMaths() {
		return maths;
	}
	public void setMaths(int maths) {
		this.maths = maths;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return examName+english+" "+physics+" "+chemistry+" "+biology+" "+computerScience+" "+maths;
	}
	
}
