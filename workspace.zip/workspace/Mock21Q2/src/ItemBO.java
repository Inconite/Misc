import java.util.ArrayList;

import java.util.List;



public class ItemBO

{

	public List<Item> findItem(List<Item> itemList, String type)

	{

		List<Item> l = new ArrayList<Item>();

		

		int flag=0;

    for(int i=0;i<itemList.size();i++)

    {

    	if(itemList.get(i).getType().equals(type))

    	{

    		l.add(itemList.get(i));

    		flag = 1;

    	}

    }

    return l;

	}

	

	public List<Item> findItem(List<Item> itemList, Double price)

	{

		List<Item> l = new ArrayList<Item>();

		

		int flag=0;

    for(int i=0;i<itemList.size();i++)

    {

    	if(itemList.get(i).getPrice().equals(price))

    	{

    		l.add(itemList.get(i));

    		flag = 1;

    	}

    }

    return l;

	}

	 

}