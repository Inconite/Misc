import java.text.*;

import java.util.*;

import java.io.*;



public class Main 

{

	public static void main(String[] args) throws Exception

	{

    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

    Item ii = new Item();

    ItemBO ibo = new ItemBO();

		List<Item> list = new ArrayList<Item>();

		

		System.out.println("Enter the number of items:");

    int n=Integer.parseInt(reader.readLine());

    for(int i=0;i<n;i++)

    	{

    		String item =reader.readLine();

    		String[] a= item.split(",");

    		ii = new Item(a[0], Double.parseDouble(a[1]), a[2]);

    		list.add(ii);

    	}

     

		System.out.println("Enter a search type:\n1.By Type\n2.By Price");

    int choice=Integer.parseInt(reader.readLine());

    

    if(choice==1)

    {

      System.out.println("Enter the Type:");

      String type =reader.readLine();

      List<Item> l=ibo.findItem(list,type);

       

      if(l.isEmpty())

      {

        System.out.println("No such item is present");

      }

       

      else

      {

      	System.out.format("%-20s %-5s %s\n","Name","Price","Type");

        for(int i=0;i<l.size();i++)

        {

          System.out.print(l.get(i).toString());

        }

      }

  	}

     

    else if(choice==2)

    {

      System.out.println("Enter the price:");

      Double price =Double.parseDouble(reader.readLine());

      List<Item> l=ibo.findItem(list,price);

       

      if(l.isEmpty())

      {

        System.out.println("No such item is present");

      }

       

      else

      {

      	System.out.format("%-20s %-5s %s\n","Name","Price","Type");

        for(int i=0;i<l.size();i++)

        {

          System.out.print(l.get(i));

        }

      }

  	}

     

    else

    {

      System.out.println("Invalid choice");

    }

	}

}