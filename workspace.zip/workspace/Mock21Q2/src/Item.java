import java.util.ArrayList;

import java.util.List;



public class Item 

{

	String name;

	Double price;

	String type;

	

	public String getName() {

		return name;

	}

	public void setName(String name) {

		this.name = name;

	}

	public Double getPrice() {

		return price;

	}

	public void setPrice(Double price) {

		this.price = price;

	}

	public String getType() {

		return type;

	}

	public void setType(String type) {

		this.type = type;

	}

	

	public Item(String name, Double price, String type) {

		super();

		this.name = name;

		this.price = price;

		this.type = type;

	}

	

	Item()

	{}

	

	public String toString()

	{

		return String.format("%-20s %-5s %s\n",name,price,type);

	}

}