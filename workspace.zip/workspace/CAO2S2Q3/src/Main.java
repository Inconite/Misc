
import java.util.Scanner;



public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		Innings ii=new Innings();

		System.out.println("Enter the number of innings");

		int a=sc.nextInt();

		

		String x[]=new String[a];

		int y[]=new int[a];

		for(int i=0;i<a;i++)

		{

			sc.nextLine();

			System.out.println("Enter the values for Innings "+(i+1));

			

			System.out.println("Enter the BattingTeam"); 

			x[i]=sc.nextLine();

			System.out.println("Enter the runs scored"); 

			y[i]=sc.nextInt();

			

			

		}

		System.out.println("Innings Details"); 

		for(int i=0;i<a;i++)

		{

			System.out.println("Innings "+(i+1));

		  ii.setBattingTeam(x[i]);

		  ii.setRuns(y[i]);

		  System.out.println(ii.toString());

		}

		

		



	}



}