import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	int d,s1,s2,s3,x,c=0;
	d=sc.nextInt();
	s1=sc.nextInt();
	s2=sc.nextInt();
	s3=sc.nextInt();
	x=sc.nextInt();
	x=x-d;
	if(x-s1>=0) {
		x=x-s1;
		c++;
	}
	if(x-s2>=0) {
		x=x-s2;
		c++;
	}
	if(x-s3>=0) {
		x=x-s3;
		c++;
	}
	System.out.println(c);
}
}
