public class UserMainCode 
{
	public static void display(String s)
	{	
		String str[] = s.split("!|#");
		for(int i=0;i<str.length;i++)
		{
			System.out.print(str[i]);
		}
	}
}