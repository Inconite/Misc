import java.util.Scanner;

 

public class Main {

  

	public static void main(String[] args) {







 Scanner sc=new Scanner(System.in);

 

 System.out.println("Enter player name");

String name=sc.nextLine();

 System.out.println("Enter team name");

String tname=sc.nextLine();

 System.out.println("Enter number of matches played");

 

 int match=sc.nextInt();

 

 System.out.println("Enter total runs scored");

 

 long runs=sc.nextLong();

 

 System.out.println("Enter number of wickets taken");

 

 int wicket=sc.nextInt();

 

 Player p=new Player(name, tname, match, runs, wicket);

p.displayPlayerStatistics();









}

}

