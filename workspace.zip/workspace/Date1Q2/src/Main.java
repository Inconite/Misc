import java.util.*;

import java.text.*;

public class Main {



	public static void main(String[] args) throws Exception{

		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);

		System.out.println("Enter String in this format(yyyy-MM-DD HH:mm:ss)");

		String s=sc.nextLine();

		

		UserMainCode.displaydateTime(s);

		

	}
}

