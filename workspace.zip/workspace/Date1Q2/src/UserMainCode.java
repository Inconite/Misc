import java.text.ParseException;

import java.text.SimpleDateFormat;

import java.util.Date;



public class UserMainCode {

public static void displaydateTime(String s) throws ParseException

{

	SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	SimpleDateFormat sdf2=new SimpleDateFormat("dd/MM/yyyy, H:mm:ss");

	Date d1=sdf1.parse(s);

	System.out.println(sdf2.format(d1));

}

}