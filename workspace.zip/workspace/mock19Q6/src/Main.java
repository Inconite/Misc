import java.io.BufferedReader;

import java.io.IOException;

import java.io.InputStreamReader;

import java.text.ParseException;

import java.util.*;



public class Main {

	public static void main(String[] args)throws IOException, NumberFormatException, ParseException {

		Map<String,Integer> tpwc = new HashMap<String,Integer>();

		List<Vehicle> vh = new ArrayList<Vehicle>();

		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));		

				

		System.out.println("Enter the number of vehicles");

		int n = Integer.parseInt(br.readLine());

		for(int i =0;i<n;i++)

		{

			String nn= br.readLine();

			vh.add(Vehicle.createVehicle(nn));

		}

		tpwc = Vehicle.typeWiseCount(vh);

		System.out.format("%-15s %s\n","Type","No. of Vehicles");

		for (Map.Entry<String,Integer> entry : tpwc.entrySet())

		{  

			System.out.format("%-15s %s\n",entry.getKey(), entry.getValue()); 

           

		}

		 

		 





	}

}