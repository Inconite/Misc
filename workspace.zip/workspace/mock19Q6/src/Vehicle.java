
import java.text.ParseException;

import java.text.SimpleDateFormat;

import java.util.*;

public class Vehicle {

private String registrationNo,name,type;

private double weight;

Vehicle(){}

public Vehicle(String registrationNo, String name, String type, double weight) {

	super();

	this.registrationNo = registrationNo;

	this.name = name;

	this.type = type;

	this.weight = weight;

}

public String getRegistrationNo() {

	return registrationNo;

}

public void setRegistrationNo(String registrationNo) {

	this.registrationNo = registrationNo;

}

public String getName() {

	return name;

}

public void setName(String name) {

	this.name = name;

}

public String getType() {

	return type;

}

public void setType(String type) {

	this.type = type;

}

public double getWeight() {

	return weight;

}

public void setWeight(double weight) {

	this.weight = weight;

}

public static Map<String,Integer> typeWiseCount(List<Vehicle> vehicleList) {

	int tw=0,fw=0;

	Map<String , Integer> mp = new HashMap<String, Integer>();

	for(Vehicle v: vehicleList)

	{

		if(v.type.equals("TwoWheeler"))

			{tw++;

			}

		if(v.type.equals("FourWheeler"))

			{fw++;}

	}

	mp.put("TwoWheeler", tw);

	mp.put("FourWheeler", fw);

	return mp;

		

	

}

public static Vehicle createVehicle(String detail) throws NumberFormatException, ParseException

{

	//SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");

	String v11[] = detail.split(",");

	//Ticket t = new Ticket(v11[4],formatter.parse(v11[5]),Double.parseDouble(v11[6]));

	Vehicle v = new Vehicle(v11[0],v11[1],v11[2],Double.parseDouble(v11[3]));

	return v;

}



}