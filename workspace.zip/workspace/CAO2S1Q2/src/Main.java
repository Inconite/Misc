import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
String name;
String coach;
String location;
String players;
String captain;
System.out.println("Enter the team details");
String a=sc.nextLine();
String ar[]=a.split("#");
name=ar[0];
coach=ar[1];
location=ar[2];
players=ar[3];
captain=ar[4];
Team t=new Team(name,coach,location,players,captain);
t.display();





		
		
		
		
		
	}

}
