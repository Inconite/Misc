public class Seller extends User 

{

		private String description;

		private Double rating;

		

		public Seller(String name, String username, String password,

				String email, String phonenumber, String description,

				Double rating) {

			super(name, username, password, email, phonenumber);

			this.description = description;

			this.rating = rating;

		}

		public Seller() {

			// TODO Auto-generated constructor stub

		}

		public void displayDetails()

		{

			

			System.out.println("Name : " + name + "\nUsername : " + username + "\nPassword : "

					+ password + "\nEmail : " + email + "\nPhonenumber : "

					+ phonenumber + "\nDescription : "+description);

			System.out.printf("Rating : %.2f",rating);



		}

}