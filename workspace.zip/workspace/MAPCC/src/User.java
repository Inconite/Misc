 public class User {

   

	//fill the code

	 protected String name;

   protected String username;

   protected String password;

   protected String email;

   protected String phonenumber;

        

	

	public User(String name, String username, String password, String email,

			String phonenumber) {

		super();

		this.name = name;

		this.username = username;

		this.password = password;

		this.email = email;

		this.phonenumber = phonenumber;

	}

	public User() {

		// TODO Auto-generated constructor stub

	}



	public void displayDetails()

	{

		//fill the code

		

	}

	@Override

	public String toString() {

		return "User [name=" + name + ", username=" + username + ", password="

				+ password + ", email=" + email + ", phonenumber="

				+ phonenumber + "]";

	}



}

