import java.io.BufferedReader;

import java.io.IOException;

import java.io.InputStreamReader;

import java.util.HashMap;

import java.util.Map;

import java.util.Set;





class Main { 



public static void main(String args[]) throws IOException { 



//fill the code

	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Enter the number of players");

		int n=Integer.parseInt(br.readLine());

		Map<String,Integer> map=new HashMap<>();

		for(int i=0;i<n;i++){

		System.out.println("Enter the details of the player "+(i+1));

		String b=br.readLine();

		int l=Integer.parseInt(br.readLine());

		map.put(b, new Integer(l));

		}

		int max=0;

		String k=null;

		Set<String> keys=map.keySet();

		for(String s:keys){

			Integer value=map.get(s);

			if(value>max){

				max=value;

				k=s;

			}

		}

		System.out.println(k);

	}



 

}

