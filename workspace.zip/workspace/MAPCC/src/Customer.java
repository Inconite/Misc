public class Customer extends User {



	private String deliveryAddress;

	private Integer bonusPoints;

	private String creditDetails;

	

	Customer(){}



		public Customer(String name, String username, String password,

			String email, String phonenumber, String deliveryAddress,

			Integer bonusPoints, String creditDetails) {

		super(name, username, password, email, phonenumber);

		this.deliveryAddress = deliveryAddress;

		this.bonusPoints = bonusPoints;

		this.creditDetails = creditDetails;

	}





		public void displayDetails()

		{

			System.out.println("Name : " + name + "\nUsername : " + username + "\nPassword : "

				+ password + "\nEmail : " + email + "\nPhonenumber : "

				+ phonenumber +"\nDelivery address : " + deliveryAddress

					+ "\nBonus points : " + bonusPoints + "\nCredit details : "

					+ creditDetails);

		}

}