import java.io.BufferedReader;

import java.io.InputStreamReader;



public class Main {



    public static void main(String[] args)throws Exception{

    	BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

    	

    	System.out.println("Enter the email to be validated:");

    	String email=reader.readLine();

    	

    	if(Main.validateEmail(email)==true){

    		System.out.println("Email is valid");

    	}

    	else 

    		System.out.println("Email is invalid");

    }

    public static Boolean validateEmail(String email){

    	boolean b = false;

    	if (email.matches("[a-z]{1}[a-z0-9._]{3,}(@)[a-zA-Z]{5,}(.)(com)")){

    	return true;

    	}

    	else return false;

    	}



	

    }  