import java.util.*;

public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		

		System.out.println("Enter player name ");

		String name=sc.nextLine();

		System.out.println("Enter player country");

		String country=sc.nextLine();

		

		System.out.println("Enter the Cap number");

		String capNumber=sc.nextLine();

		

		System.out.println("Enter the number of test appearnace");

		long noOfTestAppearance=sc.nextLong();

		

		System.out.println("Enter the number of ODI appearnace");

		long noOfODIAppearance=sc.nextLong();

		

		InternationalPlayer p=new InternationalPlayer(name, country,capNumber, noOfTestAppearance,noOfODIAppearance);

		p.displayDetails();

	}



}

