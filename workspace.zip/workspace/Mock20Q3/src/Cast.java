import java.text.SimpleDateFormat;

import java.util.Date;

 

 

public class Cast

{

                                               //Your code goes here

               private String name;

               private String nationality;

               private String gender;

               private Date dob;

              

               public Cast(){}

 

               public Cast(String name, String nationality, String gender, Date dob) {

                               super();

                               this.name = name;

                               this.nationality = nationality;

                               this.gender = gender;

                               this.dob = dob;

               }

               public String getName() {

                               return name;

               }

               public void setName(String name) {

                               this.name = name;

               }

               public String getNationality() {

                               return nationality;

               }

               public void setNationality(String nationality) {

                               this.nationality = nationality;

               }

               public String getGender() {

                               return gender;

               }

               public void setGender(String gender) {

                               this.gender = gender;

               }

               public Date getDob() {

                               return dob;

               }

               public void setDob(Date dob) {

                               this.dob = dob;

               }

 

               public String toString() {

                               SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");

                               return String.format("%-22s %-12s %-8s %s\n",name,nationality,gender,sdf.format(dob));

               }

              

}