import java.util.ArrayList;

import java.util.Date;

import java.util.List;

public class CastBO

{

               public List<Cast> findCast(List<Cast> castList,String nationality){

                               //Your code goes here

                               List<Cast> l=new ArrayList<Cast>();

                               int flag=0;

                               for(int i=0;i<castList.size();i++)

                               {

                                               if(castList.get(i).getNationality().equals(nationality))

                                               {

                                                               l.add(castList.get(i));

                                                               flag=1;

                                               }

                               }

//                           if(flag==1)

//                                           return l;

//                           else

                               return l;

               }

              

               public List<Cast> findCast(List<Cast> castList,Date dob){

                               //Your code goes here

                               List<Cast> l=new ArrayList<Cast>();

                               int flag=0;

                               for(int i=0;i<castList.size();i++)

                               {

                                               if(castList.get(i).getDob().toString().equals(dob.toString()))

                                               {

                                                               l.add(castList.get(i));

                                                               flag=1;

                                               }

                               }

//                           if(flag==1)

//                                           return l;

//                           else

                               return l;

               }

}

 

 

 

 

 

 