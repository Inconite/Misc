import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner sc=new Scanner(System.in);
     int year=sc.nextInt();
     if(year%400==0)
    	 System.out.println("Yes");
     else if(year%100==0)
    	 System.out.println("No");
     else if(year%4==0)
    	 System.out.println("Yes");
     else System.out.println("No");
     
    	 
    	 
    	 
    	 
    	 
    	 
	}

}
