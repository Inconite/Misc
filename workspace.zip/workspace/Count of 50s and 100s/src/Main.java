import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	int n,i,c=0,d=0;
	n=sc.nextInt();
	ArrayList<Integer>r1=new ArrayList<Integer>();
for(i=0;i<n;i++)
{
	r1.add(sc.nextInt());
	if(r1.get(i)>=50 && r1.get(i)<100)
	{
		c++;
	}
	else if(r1.get(i)>=100) {
		d++;
	}
}
System.out.println(c);
System.out.println(d);

}
}
