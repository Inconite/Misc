import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws NumberFormatException, ParseException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		System.out.println("Enter student 1 details:");
		String s1 = sc.nextLine();
		String[] str1 = s1.split(",");
		Student stu1 = new Student(str1[0],str1[1],sdf.parse(str1[2]),Integer.parseInt(str1[3]));
		System.out.println("Enter student 2 details:");
		String s2 = sc.nextLine();
		String[] str2 = s2.split(",");
		Student stu2 = new Student(str2[0],str2[1],sdf.parse(str2[2]),Integer.parseInt(str2[3]));
		System.out.println();
		System.out.println("Student 1");
		System.out.println(stu1.toString());
		System.out.println();
		System.out.println("Student 2");
		System.out.println(stu2.toString());
		System.out.println();
		
		if(stu1.equals(stu2))
			System.out.println("Student 1 is same as Student 2");
		else
			System.out.println("Student 1 and Student 2 are different");
	}
}
