import java.text.SimpleDateFormat;
import java.util.Date;

public class Student 
{
	private String rollNo;
	private String name;
	private Date dateOfBirth;
	private int standard;
	public String getRollNo() {
		return rollNo;
	}
	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public int getStandard() {
		return standard;
	}
	public void setStandard(int standard) {
		this.standard = standard;
	}
	
	public Student(){};
	public Student(String rollNo, String name, Date dateOfBirth, int standard) {
		super();
		this.rollNo = rollNo;
		this.name = name;
		this.dateOfBirth = dateOfBirth;
		this.standard = standard;
	}
	
	public String toString()
	{
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		return ("Roll No:"+rollNo+"\nName:"+name+"\nDate of Birth:"+sdf.format(dateOfBirth)+"\nStandard:"+standard);
	}
	
	public boolean equals(Student s)
	{
		if((this.rollNo.equals(s.rollNo))&&(this.name.equalsIgnoreCase(s.name)))
			return true;
		else
			return false;
	}
}
