
import java.util.Scanner;



public class Main {

public static void main(String []args)

{

	Scanner sc=new Scanner(System.in);

	System.out.println("Enter the venue name");

	String name=sc.nextLine();

  System.out.println("Enter the city name");

  String city=sc.nextLine();

  System.out.println("Venue Details");

  Venue v=new Venue();

  v.setCity(city);

  v.setName(name);

 System.out.println(v.toString());

}

}









