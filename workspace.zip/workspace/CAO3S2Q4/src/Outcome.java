import java.util.*;
public class Outcome {

  String status ;

  String winnerTeam ;

  String playerOfMatch ;

  String date;

public Outcome(){};

 public Outcome(String date,String status,String winnerTeam,String playerOfMatch)

 {

 this.date=date;

 this.status=status;

 this.winnerTeam=winnerTeam;

 this.playerOfMatch=playerOfMatch;

 }

  public String getStatus() {

    return status;

  }

  public void setStatus(String status) {

    this.status = status;

  }

  public String getWinnerTeam() {

    return winnerTeam;

  }

  public void setWinnerTeam(String winnerTeam) {

    this.winnerTeam = winnerTeam;

  }

  public String getPlayerOfMatch() {

   return playerOfMatch;

  }

  public void setPlayerOfMatch(String playerOfMatch) {

    this.playerOfMatch = playerOfMatch;

  }

  void setDate(String date)

 {

 this.date=date;

 }

 public String getDate()

 {

 return date;

 }

public String toString()

 {

 return String.format("%-20s %-20s %-20s %s",this.status,this.winnerTeam,this.playerOfMatch,this.date);

 }

}

