import java.util.*;
public class Main {

  public static void main(String[] args)

  {

    Scanner scanner = new Scanner(System.in);

    System.out.println("Enter the number of matches");

    int n=scanner.nextInt();

    scanner.nextLine();

    Outcome[] outcome=new Outcome[n];



for(int i=0;i<n;i++)



    {

	System.out.println("Enter match "+(i+1)+" details");

	System.out.println("Enter the date");

    String date=scanner.nextLine();

    System.out.println("Enter the status");

    String status=scanner.nextLine();

    System.out.println("Enter the winner team");

    String winnerTeam=scanner.nextLine();

    System.out.println("Enter the player of match");

    String playerOfMatch=scanner.nextLine();

    outcome[i]=new Outcome(date,status,winnerTeam,playerOfMatch);

    }



	OutcomeBO oBo=new OutcomeBO();

	oBo.displayAllOutcomeDetails(outcome);

	System.out.println("Enter the date to be searhed");

	String date=scanner.nextLine();

	oBo.displaySpecificOutcomeDetails(outcome,date);

  }

}