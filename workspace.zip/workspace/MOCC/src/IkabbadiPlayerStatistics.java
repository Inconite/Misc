
public interface IkabbadiPlayerStatistics 
{
	public void displayKabbadiPlayerDetails();
}
