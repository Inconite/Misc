
public class Player implements IkabbadiPlayerStatistics
{
	private String name;
	private String teamName;
	private int noOfMatches;
	private long totalRaidPoints;
	private long totalDefencePoints;
	
	public Player(){};
	public Player(String name, String teamName, int noOfMatches, long totalRaidPoints, long totalDefencePoints) {
		super();
		this.name = name;
		this.teamName = teamName;
		this.noOfMatches = noOfMatches;
		this.totalRaidPoints = totalRaidPoints;
		this.totalDefencePoints = totalDefencePoints;
	}
	
	public void displayKabbadiPlayerDetails()
	{
		System.out.println("Player Details");
		System.out.println("Player name : "+name+"\nTeam name : "+teamName+"\nNo of matches : "+noOfMatches+"\nTotal raid points: "+totalRaidPoints+"\nTotal defence points: "+totalDefencePoints);
	}
}
