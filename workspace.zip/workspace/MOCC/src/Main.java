import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter player name");
		String name = sc.nextLine();
		System.out.println("Enter team name");
		String tn = sc.nextLine();
		System.out.println("Enter number of matches played");
		int n = sc.nextInt();
		System.out.println("Enter total raid points");
		long rp = sc.nextLong();
		System.out.println("Enter total defence points");
		long dp = sc.nextLong();
		Player p = new Player(name, tn, n, rp, dp);
		p.displayKabbadiPlayerDetails();
	}

}
