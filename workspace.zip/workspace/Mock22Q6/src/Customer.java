import java.text.SimpleDateFormat;

import java.util.ArrayList;

import java.util.List;



public class Customer {

 private String name,gender,contactNumber,email;

 List<Invoice>invoiceList;

 

 

 public Customer(String name, String gender, String contactNumber,

   String email, List<Invoice> invoiceList) {

  super();

  this.name = name;

  this.gender = gender;

  this.contactNumber = contactNumber;

  this.email = email;

  this.invoiceList = invoiceList;

 }



 public static List<Invoice> getCustomerInvoice(List<Cab> cabList,String customerName, String month)

 {

  List<Invoice>inv=new ArrayList<Invoice>();

  List<Invoice>res=new ArrayList<Invoice>();

  SimpleDateFormat sdf=new SimpleDateFormat("MMMM");

  for(Cab b:cabList)

  {

   int flag=0;

   inv=b.getInvoiceList();

   for(Invoice i:inv)

   {

    if(i.getCustomer().getName().equals(customerName))

    {

     flag=1;

     for(Invoice in:i.getCustomer().getInvoiceList())

     {

      if(sdf.format(in.getTravelledDate()).equals(month))

      {

       res.add(in);

      }

     }

     break;

    }

   }

   if(flag==1)

    break;

  }

  return res;

 }



 public String getName() {

  return name;

 }



 public void setName(String name) {

  this.name = name;

 }



 public String getGender() {

  return gender;

 }



 public void setGender(String gender) {

  this.gender = gender;

 }



 public String getContactNumber() {

  return contactNumber;

 }



 public void setContactNumber(String contactNumber) {

  this.contactNumber = contactNumber;

 }



 public String getEmail() {

  return email;

 }



 public void setEmail(String email) {

  this.email = email;

 }



 public List<Invoice> getInvoiceList() {

  return invoiceList;

 }



 public void setInvoiceList(List<Invoice> invoiceList) {

  this.invoiceList = invoiceList;

 }

 

}

