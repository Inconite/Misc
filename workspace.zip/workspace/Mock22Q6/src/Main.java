import java.io.BufferedReader;

import java.io.IOException;

import java.io.InputStreamReader;

import java.text.ParseException;

import java.text.SimpleDateFormat;

import java.util.ArrayList;

import java.util.List;



public class Main {

 public static void main(String[] args) throws IOException, NumberFormatException, ParseException{

  BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

  List<Cab> cabList=Cab.prefill();

  SimpleDateFormat sdf=new SimpleDateFormat("HH:mm");

  SimpleDateFormat df=new SimpleDateFormat("dd-MM-yyyy");

  System.out.println("Enter the number of customers");

  int n=Integer.parseInt(br.readLine());

  for(int i=0;i<n;i++)

  {

   System.out.println("Enter the customer "+(i+1)+" detail");

   String a[]=br.readLine().split(",");

   Customer c=new Customer(a[0],a[1],a[2],a[3],new ArrayList<Invoice>());

   System.out.println("Enter the number of invoices");

   int n_c=Integer.parseInt(br.readLine());

   List<Invoice>l=new ArrayList<>();

   for(int j=0;j<n_c;j++)

   {

    List<Invoice>inv=new ArrayList<Invoice>();

    String b[]=br.readLine().split(",");

    for(Cab cb:cabList)

    {

     if(cb.getDriverName().equals(b[0]))

     {

     inv=cb.getInvoiceList();

     inv.add(new Invoice(Double.parseDouble(b[1]),sdf.parse(b[2]),df.parse(b[3]),Double.parseDouble(b[4]),Double.parseDouble(b[5]),cb,c));

     cb.setInvoiceList(inv);

     l.add(new Invoice(Double.parseDouble(b[1]),sdf.parse(b[2]),df.parse(b[3]),Double.parseDouble(b[4]),Double.parseDouble(b[5]),cb,c));

     }

    }  

   } 

   c.setInvoiceList(l);

  }

  System.out.println("Enter the customer name");

  String name=br.readLine();

  System.out.println("Enter the month");

  String mon=br.readLine();

  List<Invoice>res=Customer.getCustomerInvoice(cabList,name, mon);

  if(res.isEmpty())

   System.out.println("No invoice detail is present");

  else

  {

  System.out.println("The invoice details of "+name+" pertaining to the month of "+mon);

  System.out.format("%-12s %-12s %-8s %-8s %-15s %-8s %s\n","Driver Name","Vehicle type","Rating","Duration","Travelled Date","Distance","Amount");

  for(Invoice i:res)

  {

   System.out.format("%-12s %-12s %-8s %-8s %-15s %-8s %s\n",i.getCab().getDriverName(),i.getCab().getVehicleType(),i.getRating(),sdf.format(i.getDuration()),df.format(i.getTravelledDate()),i.getDistance(),i.getAmount());

  }

  }

 }

}