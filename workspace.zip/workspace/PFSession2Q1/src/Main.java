import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		
     Scanner sc=new Scanner(System.in);
     int lwr=sc.nextInt();
     int upr=sc.nextInt();
     int x,y,n=0,a,m=0,z;
     if(upr>=lwr)
     {
     for(x=lwr;x<=upr;x++)
     {
     		 n=x;m=0;
    		 while(n>0)
    		 {
    			 a=n%10;
    			 for(z=2;z<a;z++)
    			 {
    				 if(a%z==0)
    					 break;
    			 }
    			 if(a==z)
    			 m++;
    			 
     			 n=n/10;
    		 }
    		 if(m==2)
     			 System.out.print(x+" ");
       			 
     } 
     }
	}

}

