import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter the player 1 details");
	System.out.println("Enter the player name");
	String nm1=sc.nextLine();
	System.out.println("Enter the country name");
	String cn1=sc.nextLine();
	System.out.println("Enter the skill");
	String sk1=sc.nextLine();
	Player p1=new Player(nm1,cn1,sk1);
	System.out.println(p1);
	
	System.out.println("Enter the player 2 details");
	System.out.println("Enter the player name");
	String nm2=sc.nextLine();
	System.out.println("Enter the country name");
	String cn2=sc.nextLine();
	System.out.println("Enter the skill");
	String sk2=sc.nextLine();
	Player p2=new Player(nm2,cn2,sk2);
	System.out.println(p2);
	if(p1.equals(p2))
	{
		System.out.println("Both the player details are same.");
	}
	else
	{
		System.out.println("Both the player details are not same.");
	}
}
}
