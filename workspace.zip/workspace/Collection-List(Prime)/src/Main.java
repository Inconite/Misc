import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	int n,i,j,c=0,s=0;
	System.out.println("Enter the number of matches");
	n=sc.nextInt();
	ArrayList<Integer>r1=new ArrayList<Integer>();
	System.out.println("Enter the runs scored by the team");
for(i=0;i<n;i++)
{
	r1.add(sc.nextInt());

}
int x=0;
for(i=0;i<r1.size();i++)
{
	x=r1.get(i);
	c=0;
	for(j=1;j<=x;j++)
	{
		if(x%j==0) {
			c++;
		}
	}

if(c==2) {
	s++;
}
}
System.out.println("Number of prime scores : "+s);

}
}
