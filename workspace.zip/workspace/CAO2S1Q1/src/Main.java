

import java.util.Scanner;



public class Main {



	public static void main(String[] args)

	{

    Scanner sc=new Scanner(System.in);

    	Delivery d=new Delivery();

    	System.out.println("Enter the over");

    	long over=sc.nextInt();

    	System.out.println("Enter the ball");

  	long ball=sc.nextInt();

    	System.out.println("Enter the runs");

  	long runs=sc.nextInt();

  	sc.nextLine();

    	System.out.println("Enter the batsman name");

  	String batsman=sc.nextLine();  

    System.out.println("Enter the bowler name");

  	  String bowler=sc.nextLine();

    System.out.println("Enter the nonStriker name");

  	String nonStriker=sc.nextLine();

  	

  	Delivery d1=new Delivery(over,ball,runs,batsman,bowler,nonStriker);

  	d1.display();

    

	}



}