import java.util.*;

public class Delivery 

{



	private long ball;



	private long runs;



	private String batsman;



	private String bowler;



	private String nonStriker;

	

	

	Delivery()

	{

		

	}

	

	

	

	public Long getOver() {

 private long over;



private long ball;



private long runs;



private String batsman;



private String bowler;



private String nonStriker;





Delivery()

{



}







public Long getOver() {

return over;

	}







	public void setOver(Long over) {

		this.over = over;

	}







	public Long getBall() {

		return ball;

	}







	public void setBall(Long ball) {

		this.ball = ball;

	}







	public Long getRuns() {

		return runs;

	}







	public void setRuns(Long runs) {

		this.runs = runs;

	}







	public String getBatsman() {

		return batsman;

	}







	public void setBatsman(String batsman) {

		this.batsman = batsman;

	}







	public String getBowler() {

		return bowler;

	}







	public void setBowler(String bowler) {

		this.bowler = bowler;

	}







	public String getNonStriker() {

		return nonStriker;

	}







	public void setNonStriker(String nonStriker) {

		this.nonStriker = nonStriker;

	}







	Delivery(long over,long ball,long runs,String batsman,String bowler,String nonStriker)

	{

		this.over=over;

		this.ball=ball;

		this.runs=runs;

		this.batsman=batsman;

		this.bowler=bowler;

		this.nonStriker=nonStriker;

	}

	

	public void display()

	{

		System.out.println("Over : " +getOver());

		System.out.println("Ball : "+getBall());

		System.out.println("Runs : "+getRuns());

		System.out.println("Batsman : "+getBatsman());

		System.out.println("Bowler : "+getBowler()); 

		System.out.println("NonStriker : "+getNonStriker()); 

	}

}