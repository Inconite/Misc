import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		int i,j,k;
		for(i=0;i<num;i++)
		{
			for(j=0;j<(num-i-1);j++)
			   {
				
				System.out.print("1");
				}
			for(k=(num-i-1);k<num;k++)
			{
				System.out.print(i+1);
			}
			System.out.println();
		}
		
		
		
		
		

	}

}
