
import java.util.Scanner;



public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		System.out.println("Enter the player name"); 

		String a=sc.nextLine();

		System.out.println("Enter the country name"); 

		String b=sc.nextLine();

		System.out.println("Enter the skill"); 

		String c=sc.nextLine();

		Player p=new Player(a,b,c);

		System.out.println("Player Details");

		System.out.println(p.toString());

		

	}



}

