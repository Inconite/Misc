public class Venue {

String name,city;

}

