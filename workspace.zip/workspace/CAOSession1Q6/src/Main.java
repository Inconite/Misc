import java.util.*;

public class Main {



	public static void main(String[] args) {

		// TODO Auto-generated method stub

Scanner sc=new Scanner(System.in);

Venue v=new Venue();

System.out.println("Enter the venue details");

v.name=sc.nextLine();

String s[]=v.name.split(",");

System.out.println("Venue Details");

System.out.println("Venue Name : "+s[0]);

System.out.println("City Name : "+s[1]);

	}



}




