class Outcome {

   

  Long score ;

  String winnerTeam ;

  String playerOfMatch ;

  String date;

Outcome(){}

 Outcome(String date,Long score,String winnerTeam,String playerOfMatch)

 {

 this.date=date;

 this.score=score;

 this.winnerTeam=winnerTeam;

 this.playerOfMatch=playerOfMatch;

 }

  public Long getScore() {

    return score;

  }

  public void setScore(Long score) {

    this.score = score;

  }

  public String getWinnerTeam() {

    return winnerTeam;

  }

  public void setWinnerTeam(String winnerTeam) {

    this.winnerTeam = winnerTeam;

  }

  public String getPlayerOfMatch() {

    return playerOfMatch;

  }

  public void setPlayerOfMatch(String playerOfMatch) {

    this.playerOfMatch = playerOfMatch;

  }

   

   

   

  void setDate(String date)

 {

 this.date=date;

 }



 String getDate()

 {

 return date;

 }

   



public String toString()

 {

 return String.format("%-20s %-20s %-20s %s",score,winnerTeam,playerOfMatch,date);

 }

   



}



















/*

public class Outcome {

private String winnerTeam,playerOfMatch,date;

private long score;

public Outcome(String winnerTeam, String playerOfMatch, String date, long score) {

	super();

	this.winnerTeam = winnerTeam;

	this.playerOfMatch = playerOfMatch;

	this.date = date;

	this.score = score;

}

public Outcome() {

	super();

	// TODO Auto-generated constructor stub

}

public String getWinnerTeam() {

	return winnerTeam;

}

public void setWinnerTeam(String winnerTeam) {

	this.winnerTeam = winnerTeam;

}

public String getPlayerOfMatch() {

	return playerOfMatch;

}

public void setPlayerOfMatch(String playerOfMatch) {

	this.playerOfMatch = playerOfMatch;

}

public String getDate() {

	return date;

}

public void setDate(String date) {

	this.date = date;

}

public long getScore() {

	return score;

}

public void setScore(long score) {

	this.score = score;

}

@Override

public String toString() {

	// TODO Auto-generated method stub

	return (String.format("%-20s %-20s %-20s %s",this.score,this.winnerTeam,this.playerOfMatch,this.date));

	

}









}

*/