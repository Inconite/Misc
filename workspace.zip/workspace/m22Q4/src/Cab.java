import java.util.ArrayList;

import java.util.List;



public class Cab {

	private String driverName;

	private String registrationNumber;

	private String vehicleType;

	private int capacity;

	private double costPerKm;

	private List<Invoice> invoiceList;



	

	

	

	public String getDriverName() {

		return driverName;

	}









	public void setDriverName(String driverName) {

		this.driverName = driverName;

	}









	public String getRegistrationNumber() {

		return registrationNumber;

	}









	public void setRegistrationNumber(String registrationNumber) {

		this.registrationNumber = registrationNumber;

	}









	public String getVehicleType() {

		return vehicleType;

	}









	public void setVehicleType(String vehicleType) {

		this.vehicleType = vehicleType;

	}









	public int getCapacity() {

		return capacity;

	}









	public void setCapacity(int capacity) {

		this.capacity = capacity;

	}









	public double getCostPerKm() {

		return costPerKm;

	}









	public void setCostPerKm(double costPerKm) {

		this.costPerKm = costPerKm;

	}









	public List<Invoice> getInvoiceList() {

		return invoiceList;

	}









	public void setInvoiceList(List<Invoice> invoiceList) {

		this.invoiceList = invoiceList;

	}









	public Cab(String driverName, String registrationNumber, String vehicleType, int capacity, double costPerKm,

			List<Invoice> invoiceList) {

		super();

		this.driverName = driverName;

		this.registrationNumber = registrationNumber;

		this.vehicleType = vehicleType;

		this.capacity = capacity;

		this.costPerKm = costPerKm;

		this.invoiceList = invoiceList;

	}









	public Cab() {

		super();

		// TODO Auto-generated constructor stub

	}









	public static List<Cab> prefill(){

		List<Cab> list = new ArrayList<>();

		list.add(new Cab("Matt","TN 50 A 7563","Mini",Integer.parseInt("4"),Double.parseDouble("10"),new ArrayList<Invoice>()));

		list.add(new Cab("Walter","KA 38 V 5412","Micro",Integer.parseInt("4"),Double.parseDouble("12"),new ArrayList<Invoice>()));

		list.add(new Cab("Dean","KL 56 C 8951","Sedan",Integer.parseInt("5"),Double.parseDouble("20"),new ArrayList<Invoice>()));

		list.add(new Cab("Gustavo","AP 14 F 2315","Mini",Integer.parseInt("4"),Double.parseDouble("10"),new ArrayList<Invoice>()));

		list.add(new Cab("James","MP 20 G 5748","Lux",Integer.parseInt("10"),Double.parseDouble("25"),new ArrayList<Invoice>()));

		list.add(new Cab("Rob","MA 51 R 6258","Share",Integer.parseInt("6"),Double.parseDouble("5"),new ArrayList<Invoice>()));

		list.add(new Cab("Will","PY 48 E 5894","Rental",Integer.parseInt("6"),Double.parseDouble("30"),new ArrayList<Invoice>()));

		list.add(new Cab("Jesse","KA 58 D 5689","Micro",Integer.parseInt("4"),Double.parseDouble("12"),new ArrayList<Invoice>()));

		list.add(new Cab("Rene","KL 66 J 2596","Share",Integer.parseInt("5"),Double.parseDouble("5"),new ArrayList<Invoice>()));

		return list;

	}

}