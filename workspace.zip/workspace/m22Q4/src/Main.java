import java.text.ParseException;

import java.text.SimpleDateFormat;

import java.util.ArrayList;

import java.util.List;

import java.util.Scanner;



public class Main {

	public static void main(String[] args) throws NumberFormatException, ParseException{

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the number of invoices");

		int n = sc.nextInt();

		String[] invoiceArray = new String[n];

		sc.nextLine();

		for(int i=0;i<n;i++)

		{

			invoiceArray[i] = sc.nextLine();

		}

		

		List<Cab> cabList = Cab.prefill();

			

		SimpleDateFormat sd1 = new SimpleDateFormat("HH:mm");

		SimpleDateFormat sd2 = new SimpleDateFormat("dd-MM-yyyy");

		for(Cab cab:cabList)

		{

			

			for(int i=0;i<n;i++)

			{

				String[] inputs = invoiceArray[i].split(",");

				if(cab.getDriverName().equalsIgnoreCase(inputs[0]))

				{

					Invoice inv = new Invoice(Double.parseDouble(inputs[1]),sd1.parse(inputs[2]),sd2.parse(inputs[3]),Double.parseDouble(inputs[4]),Double.parseDouble(inputs[5]),cab);

				cab.getInvoiceList().add(inv);

				

				}

			}

		}

	Invoice.computeAmount(cabList);

System.out.format("%-12s %-8s %-8s %-15s %-8s %s\n","Driver Name","Rating","Duration","Travelled Date","Distance","Amount");

		for(Cab cab:cabList)

		{

		for(Invoice inv:cab.getInvoiceList())

			{

			System.out.format("%-12s %-8s %-8s %-15s %-8s %s\n",inv.getCab().getDriverName(),inv.getRating(),sd1.format(inv.getDuration()),sd2.format(inv.getTravelledDate()),inv.getDistance(),inv.getAmount());

			}

		}

		

	}

}



