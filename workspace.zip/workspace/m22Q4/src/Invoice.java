import java.text.SimpleDateFormat;

import java.util.Date;

import java.util.List;



public class Invoice {

	private double rating;

	private Date duration;

	private Date travelledDate;

	private double distance;

	private double amount;

	private Cab cab;

	

	

	

	

	public Invoice(double rating, Date duration, Date travelledDate, double distance, double amount, Cab cab) {

		super();

		this.rating = rating;

		this.duration = duration;

		this.travelledDate = travelledDate;

		this.distance = distance;

		this.amount = amount;

		this.cab = cab;

	}







	public double getAmount() {

		return amount;

	}















	public void setAmount(double amount) {

		this.amount = amount;

	}















	public Invoice() {

		super();

		// TODO Auto-generated constructor stub

	}









	public double getRating() {

		return rating;

	}









	public void setRating(double rating) {

		this.rating = rating;

	}









	public Date getDuration() {

		return duration;

	}









	public void setDuration(Date duration) {

		this.duration = duration;

	}









	public Date getTravelledDate() {

		return travelledDate;

	}









	public void setTravelledDate(Date travelledDate) {

		this.travelledDate = travelledDate;

	}









	public double getDistance() {

		return distance;

	}









	public void setDistance(double distance) {

		this.distance = distance;

	}









	public Cab getCab() {

		return cab;

	}









	public void setCab(Cab cab) {

		this.cab = cab;

	}









	public static void computeAmount(List<Cab> cabList){

		SimpleDateFormat sd1 = new SimpleDateFormat("HH:mm");

		for(Cab cab:cabList)

		{

			List<Invoice> invoiceList = cab.getInvoiceList();

			for(Invoice inv:invoiceList)

			{

				String[] dur = sd1.format(inv.getDuration()).split(":");

				long duration = (Long.parseLong(dur[0])*60)+Long.parseLong(dur[1]);

			inv.setAmount(duration+(long) (inv.getDistance()*cab.getCostPerKm()));

			}

		}

	}

}