import java.util.*;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a,b,n,r,t,c=0,d=0;
		a=sc.nextInt();
		b=sc.nextInt();
		for(n=a;n<=b;n++)
		{
			t=n;c=0;d=0;
			while(t>0)
			{
				r=t%10;
				t=t/10;
				if(r!=0) {
				if(r%2==0)
					c++;
				else
					d++;
			}
			}
			if(c==2&&d==2)
				System.out.print(n+" ");
		}

	}

}
