
public class Bike {

	private String VIN;
	private String brand;
	private String model;
	private String engineDisplacement;
	private String BrakeSystem;
	private double cost;
	public String getVIN() {
		return VIN;
	}
	public void setVIN(String vIN) {
		VIN = vIN;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getEngineDisplacement() {
		return engineDisplacement;
	}
	public void setEngineDisplacement(String engineDisplacement) {
		this.engineDisplacement = engineDisplacement;
	}
	public String getBrakeSystem() {
		return BrakeSystem;
	}
	public void setBrakeSystem(String brakeSystem) {
		BrakeSystem = brakeSystem;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	public Bike(String vIN, String brand, String model, String engineDisplacement, String brakeSystem, double cost) {
		VIN = vIN;
		this.brand = brand;
		this.model = model;
		this.engineDisplacement = engineDisplacement;
		BrakeSystem = brakeSystem;
		this.cost = cost;
	}
	public boolean equals(Bike ob) {
		if(this.VIN.equals(ob.VIN) && this.brand.equalsIgnoreCase(ob.brand))
			return true;
		else
			return false;
	}
	@Override
	public String toString() {
		return "VIN:"+VIN+"\nBrand:"+brand+"\nModel:"+model+"\nEngine Displacement:"+engineDisplacement+"\nBrake System:"+BrakeSystem+"\nCost:"+cost;
	}
	
	
}
