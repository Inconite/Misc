import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Bike[] b=new Bike[2]; 
		for(int i=1;i<=2;i++)
		{
			System.out.println("Enter bike "+i+" details:");
			String s=sc.nextLine();
			String[] a=s.split(",");
			b[i-1]=new Bike(a[0],a[1],a[2],a[3],a[4],Double.parseDouble(a[5]));
		}
		System.out.println();
		for(int i=1;i<=2;i++)
		{
			System.out.println("Bike "+i);
			System.out.println(b[i-1]);
			System.out.println();
		}
		if(b[0].equals(b[1]))
		{
			System.out.println("Bike 1 is same as Bike 2");
		}
		else
		{
			System.out.println("Bike 1 and Bike 2 are different");	
		}
	}

}
