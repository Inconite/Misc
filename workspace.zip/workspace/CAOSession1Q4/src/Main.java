
import java.util.*;

public class Main 

{

public static void main(String[] args) 

{

	Scanner sc = new Scanner(System.in);

	Innings innings = new Innings();



	System.out.println("Enter the innings number"); 

	innings.number = sc.nextLine();

	System.out.println("Enter the BattingTeam");

	innings.battingTeam = sc.nextLine();

	System.out.println("Enter the runs scored");

	innings.runs = sc.nextLong();

	innings.displayInningsDetails();

	}

}