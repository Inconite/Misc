import java.util.*;

public class Main {



	public static void main(String[] args) {

		// TODO Auto-generated method stub

Scanner sc=new Scanner(System.in);

Innings i=new Innings();

System.out.println("Enter the innings number");

i.number=sc.nextLine();

System.out.println("Enter the BattingTeam");

i.battingTeam=sc.nextLine();

System.out.println("Enter the runs scored");

i.runs=sc.nextLong();

i.displayInningsDetails();

	}



}

