public class Innings {

String number,battingTeam;

Long runs;

public void displayInningsDetails()

{

	System.out.println("Innings Details :");

	System.out.println("Innings number : "+number);

	System.out.println("BattingTeam : "+battingTeam);

	System.out.println("Runs scored :"+runs);

}

}