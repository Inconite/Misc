import java.text.ParseException;

import java.util.*;



public class Main {

	public static void main(String[] args) throws NumberFormatException, ParseException{

  		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the name of the Parking Lot:");

		String pName = sc.nextLine();

		List<Vehicle> vehicleList = new ArrayList<Vehicle>();

		ParkingLot pLot = new ParkingLot(pName,vehicleList);

		while(true)

		{

			System.out.println("1.Add Vehicle\n2.Delete Vehicle\n3.Display Vehicles\n4.Exit\nEnter your choice:");

			int choice = sc.nextInt();

			switch(choice)

			{

			case 1:

				sc.nextLine();

				String input = sc.nextLine();

				Vehicle vh = Vehicle.createVehicle(input);

				pLot.addVehicleToParkingLot(vh);

					System.out.println("Vehicle successfully added");

				break;

			case 2:

				sc.nextLine();

				System.out.println("Enter the registration number of the vehicle to be deleted:");

				String input2 = sc.nextLine();

				if(pLot.removeVehicleFromParkingLot(input2))

					System.out.println("Vehicle successfully deleted");

				else

					System.out.println("Vehicle not found in parkinglot");

				break;

			case 3:

				pLot.displayVehicles();

				break;

			case 4:

				System.exit(0);

				

			}

		}

	}

}