
import java.text.ParseException;

import java.text.SimpleDateFormat;



public class Vehicle {

	private String registrationNo;

	private String name;

	private String type;

	private Double weight;

	private Ticket ticket;

	public Vehicle() {

		super();

		// TODO Auto-generated constructor stub

	}

	public Vehicle(String registrationNo, String name, String type, Double weight, Ticket ticket) {

		super();

		this.registrationNo = registrationNo;

		this.name = name;

		this.type = type;

		this.weight = weight;

		this.ticket = ticket;

	}

	public String getRegistrationNo() {

		return registrationNo;

	}

	public void setRegistrationNo(String registrationNo) {

		this.registrationNo = registrationNo;

	}

	public String getName() {

		return name;

	}

	public void setName(String name) {

		this.name = name;

	}

	public String getType() {

		return type;

	}

	public void setType(String type) {

		this.type = type;

	}

	public Double getWeight() {

		return weight;

	}

	public void setWeight(Double weight) {

		this.weight = weight;

	}

	public Ticket getTicket() {

		return ticket;

	}

	public void setTicket(Ticket ticket) {

		this.ticket = ticket;

	}

	

	public String toString()

	{

		String str = "Registration No:"+registrationNo;

		str += "\nName:"+name;

		str += "\nType:"+type;

		str += "\nWeight:"+weight;

		str += "\nTicket No:"+this.getTicket().getTicketNo();

		

		return str;

	}

	

	public boolean equals(Vehicle vehicle)

	{

		if(this.registrationNo.equalsIgnoreCase(vehicle.registrationNo) && (this.name.equalsIgnoreCase(vehicle.name)))

		{

			return true;

		}

		return false;

	}

	

	public static Vehicle createVehicle(String input) throws NumberFormatException, ParseException

	{

		String[] inputArray = input.split(",");

		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");

		Ticket ticket = new Ticket(inputArray[4],formatter.parse(inputArray[5]),Double.parseDouble(inputArray[6]));

		return new Vehicle(inputArray[0],inputArray[1],inputArray[2],Double.parseDouble(inputArray[3]),ticket);

	}

	

	

}