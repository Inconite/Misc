import java.util.Scanner;





public class Main 

{

	public static void main(String args[])

	{

		Scanner sc = new Scanner(System.in);

		

		System.out.println("Enter the book name");

		String name = sc.nextLine();

		

		System.out.println("Enter the author name");

		String author = sc.nextLine();

		

		System.out.println("Enter the price");

		double price = sc.nextDouble();

		sc.nextLine();

		System.out.println("Enter the publication name");

		String publication = sc.nextLine();

		

		System.out.println("Enter the type of book");

		System.out.println("1.PrintedBook");

		System.out.println("2.EBook");

		int ch=sc.nextInt();

		

		switch(ch)

		{

		case 1:

			System.out.println("Enter the number of pages of the book");

			int numOfPages = sc.nextInt();

			sc.nextLine();

			System.out.println("Enter the binding type of the book");

			String bindingType=sc.nextLine();

			System.out.println("Enter the paper type of the book");

			String paperType = sc.nextLine();

			PrintedBook pb = new PrintedBook(name, author, price, publication, numOfPages, bindingType, paperType);

			System.out.println("Printed Book Details");

			pb.displayDetails();

			break;

		case 2:

			

			System.out.println("Enter the disk type of the book");

			sc.nextLine();

			String diskType= sc.nextLine();

			System.out.println("Enter the size of the disk");

			double size= sc.nextDouble();

			Ebook eb= new Ebook(name, author, price, publication, diskType, size);

			System.out.println("EBook Details");

			eb.displayDetails();

			break;

		}

			

	}



}