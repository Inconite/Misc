
import java.util.*;

public class Team {



 public String name,coach,location,players,captain;



public String getName() {



	return name;

}



public void setName(String name) {



	this.name = name;

}



public String getCoach() {



	return coach;

}



public void setCoach(String coach) {



	this.coach = coach;

}



public String getLocation() {



	return location;

}



public void setLocation(String loaction) {



	this.location = loaction;

}



public String getPlayers() {



	return players;

}



public void setPlayers(String players) {



	this.players = players;

}



public String getCaptain() {



	return captain;

}



public void setCaptain(String captain) {



	this.captain = captain;

}



void displayTeamDetails()



{ System.out.println("Team Details");



System.out.println("Team : "+getName());



System.out.println("Coach : "+getCoach());



System.out.println("Location : "+getLocation());



System.out.println("Players : "+getPlayers());



System.out.println("Captain : "+getCaptain());



	}







}