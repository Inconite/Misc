import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	String n,bt;
	long r;
	System.out.println("Enter the innings number");
	n=sc.nextLine();
	System.out.println("Enter the BattingTeam");
	bt=sc.nextLine();
	System.out.println("Enter the runs scored");
	r=sc.nextLong();
	Innings i=new Innings();
	i.number=n;
	i.battingTeam=bt;
	i.runs=r;
	i.displayInningsDetails();
}
}
