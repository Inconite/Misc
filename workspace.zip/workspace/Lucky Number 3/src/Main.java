import java.util.*;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
int a,b,n,sum=0,i;
a=sc.nextInt();
b=sc.nextInt();
for(n=a;n<=b;n++)
{sum=0;
	for(i=1;i<n;i++) {
		
		if(n%i==0)
			sum=sum+i;
	}
	if(sum<n)
		System.out.print(n+" ");
}
	}

}
