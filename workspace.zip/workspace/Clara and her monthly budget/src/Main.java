import java.util.Scanner;

public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		int a,sum=0;

		char ch;

		int no;

		int count=0;

		String s=sc.nextLine();

		int n=s.length();

		for(int i=0;i<n-2;i++)

		{

			sum=0;

			no=i+3;

			for(int j=i;j<no;j++)

			{	

				ch=s.charAt(j);

				a=Character.getNumericValue(ch);

				sum=sum*10+a;

			}

			

			if(sum%4==0)

			{

				count++;

			}

		}

		

		System.out.println(count);

		

	}



}