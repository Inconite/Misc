
import java.util.Scanner;

public class Main {



	public static void main(String[] args) 

	{

		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);

		Venue venue = new Venue();

		System.out.println("Enter the venue name");

		venue.setName(sc.nextLine());

		System.out.println("Enter the city name");

		venue.setCity(sc.nextLine());

		

		VenueBO venuebo = new VenueBO();

		venuebo.displayVenueDetails(venue);

	}

}

