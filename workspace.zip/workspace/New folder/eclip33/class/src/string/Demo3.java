package string;
class Demo
{
	int a=5,b=7;
	void disp()
	{
		System.out.println("629652956:"+(a+b));
	}
}
class  Dem extends Demo
{
	int a=10,b=20;
	Dem()
	{
		System.out.println(a+b);
		System.out.println("using super: "+(super.a+super.b));
		disp();
	}
}
public class Demo3 {
	public static void main(String args[])
	{
		new Dem
		();
	}

}
