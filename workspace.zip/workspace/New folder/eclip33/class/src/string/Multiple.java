package string;

public class Multiple {

}
