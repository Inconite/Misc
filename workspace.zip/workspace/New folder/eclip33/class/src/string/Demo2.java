package string;
class B
{
	void disp()
	{
		System.out.println("zero para");
	}
	void disp(int a)
	{
		System.out.println("one int para");
	}
	void disp(String a)
	{
		System.out.println("one string para");
	}
	void disp(int a,String b)
		{
			System.out.println("Two para");
		}
	}

public class Demo2 {
public static void main(String args[])
{
	B obj1=new B();
	obj1.disp(10,"Abhi");
	obj1.disp(10);
	obj1.disp("Abhi");
	obj1.disp();
}
}
