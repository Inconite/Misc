package string;
class A
{
	void display(int a)
	{
		System.out.println("A square: "+(a*a));
	}
}
class B extends A
{
	void display(int a)
	{
		System.out.println("B square: "+(a*a));
	}
}
class D extends B
{
	void display(int a)
	{
		System.out.println("C square: "+(a*a));
	}
}
public class overriding {
public static void main(String args[])
{
	A obj1=new A();
	obj1.display(2);
	 
	B obj2=new B();
	obj2.display(3);
	obj2.display(3);
	
	D obj3=new D();
	obj3.display(4);
}
}
