package string;
class A
{
	void display()
	{
		System.out.println("iohugf");
	}
}

public class Interface1 {

}
