package string;
class AAA
{
	void disp()
	{
		System.out.println("disp class AAA");
	}
}
class BBB extends AAA
{
	void disp()
	{
		
		System.out.println("disp class BBB");
	}
	BBB()
	{
		disp();
		super.disp();
	}
}


public class Multilevel {
public static void main(String args[])
{
	new BBB();
}
}
