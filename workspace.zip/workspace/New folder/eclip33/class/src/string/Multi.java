package string;
class A
{
	A()
	{
		System.out.println("class A");
	}
}
class C extends A
{
	C()
	{
		System.out.println("class B");
	}
}
class D extends C
{
	D()
	{
		System.out.println("class c");
	}
}
public class Multi {
public static void main(String args[])
{
	new D();
}
}
