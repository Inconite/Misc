package string;
abstract class Demo
{
	abstract void disp();
	{
		
	}
}
class Demo3 extends Demo
{
	void disp()                                                                                                                                            
	                    
	{
		
	}
}
abstract class Demo4 extends Demo
 {
	
}
public class Abstract {
	public static void main(String args[])
	{
		
	}

}