package file;
import java.io.*;
public class File3 {
	public static void main(String args[]) throws IOException
	{
		File f=new File("d:\\abc.text");
		FileInputStream fis;
		int n;
		if(f.exists())
		{
			fis=new FileInputStream(f);
		while((n=fis.read()) !=1)
		{
			System.out.println((char)n);
		}
		fis.close();
		}
		else
			System.out.println("File not exists");
	}

}
