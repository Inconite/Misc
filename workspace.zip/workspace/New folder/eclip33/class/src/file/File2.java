package file;
import java.io.FileInputStream;
import java.io.FileNOtFoundException;
import java.io.*;
public class File2 {

}
