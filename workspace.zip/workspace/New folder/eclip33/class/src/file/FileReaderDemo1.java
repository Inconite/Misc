package file;
import java.io.File;
	import java.io.FileNotFoundException;
	import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
	public class FileReaderDemo1 {
		public static void main(String args[]) throws IOException
		{
			File f=new File("d:\\abc.txt");
			FileWriter fw;
			int n;
			if(f.exists())
			{
              fw=new FileWriter(f);
              
              fw.close();
		}
			else
				System.out.println("fiel not exists");
	}
	}
