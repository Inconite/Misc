package list;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.Collections;
public class List3 
{
Integer arr[]={10,20,30,40,50,};
ArrayList<Integer> list=new ArrayList<Integer>(Arrays.asList(arr));
System.out.println