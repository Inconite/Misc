package list;
import java.util.ArrayList;

import javax.swing.text.html.HTMLDocument.Iterator;
public class List2 {
	private static final String List = null;

	public static void main(String args[])
	{
		ArrayList<String> list=new ArrayList<String> ();
		list.add("ABC");
		list.add("DEF");
		list.add("GHI");
		System.out.println(list);
		Iterator it=list.iterator();
		System.out.println("-------using for loop----------");
		while(it.hasNext());
		{
			System.out.println(it.next());
		}
		System.out.println("using for loop");
		for(String element:List)
		{
			System.out.println(element);
		}
	}

}
