package list;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.Collections;
public class List4
{
	public static void main(String args[])
	{
Integer arr[]={10,20,30,40,50,};
ArrayList<Integer> list=new ArrayList<Integer>(Arrays.asList(arr));
System.out.println(list);
   System.out.println("ASCENDING");
   Collections.sort(list);
   System.out.println(list);
   System.out.println("DESCENDING");
   Collections.reverse(list);
   System.out.println(list);
   System.out.println(list.add(40));
}
}