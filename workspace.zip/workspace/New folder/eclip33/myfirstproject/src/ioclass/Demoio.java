package ioclass;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;


public class Demoio 
{
	public static void main(String[] args) throws IOException
	{
		int a;
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		System.out.println("enter the numbers");
		a=Integer.parseInt(br.readLine());
	
		if(a%2==0)
		System.out.println(a+" is an even number");
		else
			System.out.println(a+" is an odd number");
		
	
	System.out.println("enter the string name");
	String th=br.readLine();
	System.out.println(th.toLowerCase());
	System.out.println(th.charAt(3));
	System.out.println(th.length());
	
	
	//-------------------------------------------------
int num;
int sum=0;
int i=1;
int n=0;

System.out.println("enter the number");
num=Integer.parseInt(br.readLine());

sum=0;
i=num;
while(num>0)
{
	n=num%10;
	num=num/10;
	sum=sum+(n*n*n);
}

if(sum==i)
{
	System.out.println("number is amstrong");
}
else
{
	System.out.println("number is not an amstrong");
}

//-----------------------------------------------------------



System.out.println("enter the number");
int k=Integer.parseInt(br.readLine());

while(k!=0)
{
	int y=0;
	int digit=k%10;
	y=y+digit;
	k=k/10;
}
System.out.println("sum="+ y);
	}
}

//------------------------------------------------------------





