package file;



import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Student implements Serializable
{
	int roll;
	String name;
	Student(int roll,String name)
	{
		this.roll=roll;
		this.name=name;		
	}
	 public String toString()
	{
		return roll+"\t"+name;
	}
}
public class Serialization {
	public static void main(String[] args) throws Exception {	
	FileOutputStream fos=new FileOutputStream("d:\\abhi.txt");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		Student ob=new Student(312,"ABHI");
		oos.writeObject(ob);
		ob=null;
		oos.close();
		fos.close();
		
		
		FileInputStream fis=new FileInputStream("d:\\abhi.txt");
		ObjectInputStream ois=new ObjectInputStream(fis);
		ob =(Student)ois.readObject();
		
		
		System.out.println(ob);
	}

}


