package methods;
class Demo1
{
	int a=10;
	void disp1(Demo1 obj)
	{
		System.out.println("a "+a);
	}
}
public class Method3 {

	public static void main(String[] args)
	{
	Demo1 obj1=new Demo1();	
	Demo1 obj2=new Demo1();	
	obj2.a=20;
	obj1.disp1(obj2);
	obj2.disp1(obj1);
	}

}
