package methods;
//how to pass object as a parameter to the method
public class Method2  
{
class Demo
{
	void disp()
	{
		System.out.println("hello");
	}
	void disp1(Demo obj)
	{
		System.out.println("hello");
	}
}
	public static void main(String[] args)
	{
		new Demo().disp();
		Demo ob1=new Demo();
		Demo ob2=new Demo();
		obj2.disp1(obj2);//obj2 ----invoking
		

	}

}
