package methods;
//shadowing problem by overcoming by using this keyword
class Demo3
{
	int a,b;
	Demo3(int a,int b)
	{
		this.a=a;
		this.b=b;
	}
	
	Demo3 disp(Demo3 obj)
	{
		obj.a=obj.a+a;
		obj.b=obj.b+b;
		return obj;
	}
	void display()
	{
		System.out.println(a+" "+b);
	}
}

public class Method4 {

	public static void main(String[] args)
	{
	Demo3 obj1=new Demo3(10,20);
	Demo3 obj2=new Demo3(30,40);
	Demo3 obj=obj1.disp(obj2);
	obj.display();
	System.out.println("===========");
	obj=obj2.disp(obj1);
	obj.display();
	}

}

