package methods;

public class Method1
{
private static final char[] display1 = null;
int a=10;
static int b=20;
static void display()
{
	System.out.println("non static method");
}
static void display1()
{
	System.out.println("static method");
}
public static void main(String[] args) 
{
Method1 obj=new Method1();
System.out.println(obj.a);
System.out.println(obj.b);
System.out.println(b);

display1();
Method1.display();
Method1.display1();
}

}
