package arrays;
import java.util.*;

public class Arrays2d
{
int i,j;
Scanner scan=new Scanner(System.in);
int arr[][]=new int[3][3];
System.out.println("enter the values");
for(i=1;i<=arr.length-1;i++)
{
	for(j=1;j<=arr.length-1;j++)
	{
		arr[i][j]=scan.nextInt();
	}
}
	if(arr[i][j]%2==0)
	{
		System.out.println("no of even terms are"+arr[i][j]);
	}
	else
	{
		System.out.println("no of odd terms are"+arr[i][j]);
	}
}
}
