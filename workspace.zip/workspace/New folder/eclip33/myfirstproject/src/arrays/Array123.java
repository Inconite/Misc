
package arrays;
import java.util.*;
public class Array123 
{

	public static void main(String[] args)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the no of total values");
		int n=scan.nextInt();
		int arr[]=new int[n];
		System.out.println("enter the array values");
		int i;
		int count1=0,count2=0;
		for(i=0;i<=arr.length-1;i++)
		{
		arr[i]=scan.nextInt();
		}
		for (i = 0; i < arr.length-1; i++)
		{
		
		if(arr[i]%2==0)
		{
			System.out.println("even numbers are"+count1++);
		}
		else
		{
			System.out.println("odd numbers are"+count2++);
		}
	}
}
}
