package arrays;

import java.util.Scanner;

public class Series {

	private static Scanner scan;

	public static void main(String[] args) 
	{
		
		scan = new Scanner(System.in);
		int n=scan.nextInt();
		int i;
		int a=5;
			for(i=0;i<n;i++)
		{
			
				System.out.print(a+" ");
				a=(a+5)+2*i;
			
		}
	}

}
