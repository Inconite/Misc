package arrays;

public class Add {

	public static void main(String[] args) {
		int a=8,b=3,c=5;
		

	}

}
