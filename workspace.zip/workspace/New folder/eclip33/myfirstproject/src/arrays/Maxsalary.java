package arrays;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Employe
{
	int id;
	String name;
	double salary;
	
	Employe(int id,String name,double salary)
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
	}
	void display()
	{
		System.out.println(id+"\t"+name+"\t"+salary);
	}
}

public class Maxsalary {

	public static void main(String[] args) throws IOException
	{
		
		
		/*Employee ob1=new Employee(101,"AAA",1000.00);
		ob1.display();*/
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		Employee arr[]=new Employee[3];
		int id;
		String name;
		double salary;
		
		for(int i=0;i<arr.length;i++)
		{
			System.out.println("enter the id");
			id=Integer.parseInt(br.readLine());
			System.out.println("enter the name");
			name=br.readLine();
			System.out.println("enter the salary");
			salary=Double.parseDouble(br.readLine());
			arr[i]=new Employee(id,name,salary);		
		}
		double j=arr[0].salary;
		for(int i=0;i<arr.length;i++)
		{
			if(j<arr[i].salary)
			{
				
				j=arr[i].salary;
			}
		}
		System.out.println("max salary is "+j);
		
		double k=arr[0].salary;
		for(int i=0;i<arr.length;i++)
		{
			if(k>arr[i].salary)
			{
				
				k=arr[i].salary;
			}
		}
		System.out.println("min salary is "+k);
	}
}
