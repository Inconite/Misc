package arrays;

public class Reversearray {

	public static void main(String[] args) 
	{
		int arr[]={10,5,7,8,9};
		for(int a:arr)
		{
			System.out.println(a);
		}
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(i+" "+arr[i]);
		}
		System.out.println("reversing");
		for(int i=arr.length-1;i>=0;i--)
		{
			System.out.println(i+" "+arr[i]);
		}
		System.out.println("----------------");
		int tmp;
		for(int i=0,j=arr.length-1;i<j;i++,j--)
		{
			tmp=arr[i];
			arr[i]=arr[j];
			arr[j]=tmp;
		}
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(i+" "+arr[i]);
		}
		
	}

}
