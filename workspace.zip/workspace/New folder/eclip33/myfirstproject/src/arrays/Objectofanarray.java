package arrays;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Employee
{
	int id;
	String name;
	double salary;
	
	Employee(int id,String name,double salary)
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
	}
	void display()
	{
		System.out.println(id+"\t"+name+"\t"+salary);
	}
}

public class Objectofanarray {

	public static void main(String[] args) throws IOException
	{
		
		
		/*Employee ob1=new Employee(101,"AAA",1000.00);
		ob1.display();*/
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		Employee arr[]=new Employee[3];
		int id;
		String name;
		double salary;
		for(int i=0;i<arr.length;i++)
		{
			id=Integer.parseInt(br.readLine());
			name=br.readLine();
			salary=Double.parseDouble(br.readLine());
			arr[i]=new Employee(id,name,salary);
		}
		
		System.out.println("elements are");
		for(int i=0;i<arr.length;i++)
		{
		System.out.println(arr[0].id+" "+arr[0].name+" "+arr[0].salary);
		arr[i].display();
	}
	}
}
