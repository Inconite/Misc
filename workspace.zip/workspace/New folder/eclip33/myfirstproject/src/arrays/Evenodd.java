package arrays;
import java.util.*;

public class Evenodd {



	private static Scanner scan;

	public static void main(String[] args)
	{
		
		scan = new Scanner(System.in);

	int n=scan.nextInt();
	int arr[]=new int[n];
	int a=0;
	int i;
	for(i=0;i<=arr.length-1;i++)
	{
	arr[i]=scan.nextInt();
	}
	for (i = 0; i < arr.length-1; i++)
	{
	a=a+arr[i];
	}
	if(a%2==0)
	{
		System.out.println("even");
	}
	else
	{
		System.out.println("odd");
	}
	}
}
	


