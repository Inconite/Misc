package arrays;
import java.util.*;

public class Sum 
{

	private static Scanner scan;

	public static void main(String[] args)
	{
	scan = new Scanner(System.in);
	int n=scan.nextInt();
	int arr[]=new int[n];
	int sum=0;
	for(int i=0;i<arr.length;i++)
	{
		sum=arr[i]+arr[i+1];
	}

	
	System.out.println(sum);
	}

}
