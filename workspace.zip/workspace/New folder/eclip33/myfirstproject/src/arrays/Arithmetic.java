package arrays;
import java.util.*;
public class Arithmetic {

	private static Scanner scan;

	public static void main(String[] args)
	{
	scan = new Scanner(System.in);
	
	
	int n=scan.nextInt();
	int a=2;
	int d=2;
	int sum=0;
	for(int i=1;i<=n;i++)
	{
	n=a+(n-1)*d;
	}
	System.out.println(a+" "+n);
	}
	
}
