package program;

public class Project3 
{
public static void main(String args[])
{
	int i,j,k;
	for(i=1;i<=5;i++)
	{
		for(j=1;j<=i;j++)
		{
			System.out.print(j);
		}
		System.out.println();
		for(k=1;k<=5-i+1;k++)
		{
			System.out.print(" ");
		}
			for(j=1;j<=i;j++)
			{
				System.out.print(j);
			}
			System.out.println(" ");
	}
	
		
	}
}

