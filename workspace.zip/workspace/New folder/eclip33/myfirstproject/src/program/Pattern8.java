package program;

public class Pattern8
{
public static void main(String args[])
{
	int sp=8;
	for(int i=1;i<=5;i++)
	{
		for(int j=1;j<=i;j++)
			System.out.print(j);
		for(int j=i;j<=sp;j++)
			System.out.print(" ");
		sp=sp-2;
		for(int j=i;j>=1;j++)
				{
			System.out.println(j);
		System.out.println();
	}
}
}

}
