
import java.util.*;
package program;

public class Array1 
{

	public static void main(String[] args)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the no of total values");
		int n=scan.nextInt();
		int arr[]=new int[n];
		System.out.println("enter the array values");
		int i;
		arr[i]=scan.nextInt();
		int count=0;
		if(arr[i]%2==0)
		{
			System.out.println("even numbers are"+count++);
		}
		else
		{
			System.out.println("odd numbers are"+count++);
		}
	}

}
