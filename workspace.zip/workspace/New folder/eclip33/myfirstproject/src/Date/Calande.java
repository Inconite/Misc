package Date;


import java.io.*;
import java.text.*;
import java.util.*;

/*import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;*/

public class Calande {

	public static void main(String[] args) throws Exception
	{
		SimpleDateFormat sdf=new SimpleDateFormat("DD/MM/yyyy");
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		System.out.println("enter the date");
		String sDate=br.readLine();
	    Date d=sdf.parse(sDate);
	    
		Calendar cal=Calendar.getInstance();
		cal.setTime(d);
		
		
		SimpleDateFormat sdf2=new SimpleDateFormat("MMM");
		String s2=sdf2.format(cal.getTime());
		System.out.println(s2);
		
		
		System.out.println(cal.get(Calendar.YEAR));
		System.out.println(cal.get(Calendar.MONTH));
		System.out.println(cal.get(Calendar.DATE));

		
	}

}
