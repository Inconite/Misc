package Date;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Demo1
{

	

	public static void main(String[] args) throws ParseException, IOException 
	{
		
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		System.out.println("enter the date");
		String s1=br.readLine();
		
		
	Date d=new Date();
	System.out.println(d);
	
	String strDate=s1;
	SimpleDateFormat sdf=new SimpleDateFormat ("dd/mm/yyyy");
	Date d1=sdf.parse(strDate);
	String str=sdf.format(d1);
	System.out.println(str);
	}

}
