package thread;
class Demo1 implements Runnable
{
	Thread t;
   Demo1(String name)
   {
	   t=new Thread(this,name);
	   t.start();
   }
	@Override
	public void run() 
	{
	try
	{
		for(int i=1;i<26;i++)
		{
			System.out.println(i);
			
			
			Thread.sleep(500);
		}
	}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		
	
}

public class Thread2 
{
public static void main(String args[])
{
	Demo1 obj1=new Demo1("Abhi");
	Demo1 obj2=new Demo1("Akhil");
	System.out.println("Main");
	
	
}
}

