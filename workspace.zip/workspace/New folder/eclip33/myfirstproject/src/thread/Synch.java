package thread;

public class Synch {

}
