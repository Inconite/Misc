package thread;

public class Thread1 {
public static void main(String args[])
{
	Thread t=Thread.currentThread();
	System.out.println(t);
	t.setName("Abhi");
	System.out.println(t);
	System.out.println(t.getName());
	System.out.println(t.getPriority());
	t.setPriority(Thread.MAX_PRIORITY);
	System.out.println(t.getPriority());
	t.setPriority(Thread.MIN_PRIORITY);
	System.out.println(t.getPriority());
	t.setPriority(Thread.NORM_PRIORITY);
	System.out.println(t.getPriority());
	
}
}
