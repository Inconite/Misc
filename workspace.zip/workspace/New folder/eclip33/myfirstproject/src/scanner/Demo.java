package scanner;

import java.util.Scanner;

public class Demo 
{
  public static void main(String args[])
  {
	  Scanner scan=new Scanner(System.in);
	  System.out.println("enter the inputs");
	  int a=scan.nextInt();
	 
	  if(a%2==0)
	  {
	  System.out.println("given input is even");
      }
	  else
	  {
		  System.out.println("given input is odd");  
	  }
}
}
