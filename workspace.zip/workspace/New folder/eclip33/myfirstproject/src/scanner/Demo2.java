package scanner;

import java.util.Scanner;

public class Demo2
{
	public static void main(String args[])
	{
		int max;
		 Scanner scan=new Scanner(System.in);
		 int a=scan.nextInt();
		 int b=scan.nextInt();
		 int c=scan.nextInt();
		 if(a>b)
		 {
			 if(a>c)
				 System.out.println(max=a);
		 }
		 else
			 System.out.println(max=c);
		 
		 
		 if(b>a)
		 {
			 if(b>c)
				 System.out.println(max=b);
		 }
		 else
			 System.out.println(max=a);
		 
		 
		 
		 if(c>a)
		 {
			 if(c>b)
				 System.out.println(max=c);
		 }
		 else
			 System.out.println(max=a);
	}
}
