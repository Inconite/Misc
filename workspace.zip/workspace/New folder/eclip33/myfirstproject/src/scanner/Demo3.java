package scanner;

public class Demo3 {

}
