package string;

import java.lang.reflect.Array;
import java.util.Arrays;

public class Stringreverse
{

	public static void main(String[] args)
	{
		String s1="SWAThIK";
		System.out.println(s1);
		 String s2=s1.toUpperCase();
		int m=s2.length();
		char ch[]=s2.toCharArray();
		Arrays.sort(ch);
		
		
		//===========REVERSING ORDER WITH SORTING
		
		for(int i=m-1;i>=0;i--)
		{
			System.out.print(ch[i]);
		}
		System.out.println();
		System.out.println();
		
		//===========ORDER WITH OUTSORTING
		
		for(int i=0;i<=m-1;i++)
		{
			System.out.print(ch[i]);
		}
		
	}
}
	