package string;

public class Stringbuffer1
{

	public static void main(String[] args)
	{
		StringBuffer sb=new StringBuffer();
		System.out.println(sb.capacity());
		System.out.println(sb.length());
		
		StringBuffer sb2=new StringBuffer("swathik");
		System.out.println(sb2.capacity());
		System.out.println(sb2.length());

		StringBuffer sb3=new StringBuffer();
		sb3.append("hello java");
		System.out.println(sb3);
		
		
		sb3.charAt(4);
		System.out.println(sb3);
		
		sb3.reverse();
		System.out.println(sb3);
		
		
		
		String s1="hello from cts";
		String arr[]=s1.split(" ");
		StringBuffer cs=new StringBuffer();
		for(String s:arr)
		
		{
			sb=new StringBuffer(s);
			cs.length();
			System.out.println(cs);
		}
		
}
}
