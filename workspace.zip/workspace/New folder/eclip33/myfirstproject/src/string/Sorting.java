package string;

import java.util.StringTokenizer;

public class Sorting {

	public static void main(String[] args)
	{
	String strarr[]={"BBR-1000","AAA-500","CCC-800"};
	StringTokenizer st;
	String arr[]=new String[3];
	int arr1[]=new int[3]; 
	int j=0;
	
	
	for(int i=0;i<strarr.length;i++)
	{
		System.out.println();
		st=new StringTokenizer(strarr[i],"-");
	while(st.hasMoreTokens())
	{
		st.nextToken();
		arr1[j++]=Integer.parseInt(st.nextToken());
	}

	}
	for(String element:arr1)
		System.out.println(element);
	}
}
