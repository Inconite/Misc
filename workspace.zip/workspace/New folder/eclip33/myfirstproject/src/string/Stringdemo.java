package string;

public class Stringdemo {

	public static void main(String[] args)
	{
		String s1="swathik";
		String s2="SWATHIK";
		System.out.println(s1.toUpperCase());
		System.out.println(s1.charAt(6));
		System.out.println(s1.length());
		System.out.println(s1.replace('w','k'));
		
		System.out.println(s1.equals(s2));
		System.out.println(s1==s2);
		
		System.out.println("========");
		
		
		String s5=new String ("radha");
		System.out.println(s1==s5);
		System.out.println(s1.equals(s5));
		System.out.println(s5.concat(s2));
		
		StringBuffer ss=new  StringBuffer("radha");
			ss.delete(0,2);
			System.out.println(ss);
			
			
		
	}

}
