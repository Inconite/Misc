package string;

import java.util.StringTokenizer;

public class Tokens
{

	public static void main(String[] args)
	{
	
	StringTokenizer str=new StringTokenizer("hello from cts"," ");
	System.out.println(str.countTokens());
	System.out.println(str.hasMoreTokens());
	while (str.hasMoreTokens())
	{
	
	
	System.out.println(str.nextToken());
	}
	}
}
