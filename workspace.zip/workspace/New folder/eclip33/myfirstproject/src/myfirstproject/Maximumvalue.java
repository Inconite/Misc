package myfirstproject;

public class Maximumvalue
{
   public static void main(String args[])
   int a,b,c,
   {
	   
   }

}
