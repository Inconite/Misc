package myfirstproject;

public class evenandodd
{

	public static void main(String[] args)
	{
		int a=Integer.parseInt(args[0]);
				if(a%2==0)
				{
					System.out.println("given number is even");
				}
				else
				{
				System.out.println("given number is odd");	
				}
        
	}

}
