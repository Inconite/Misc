package myfirstproject;

public class Casesensitive 
{
public static void main(String args[])
{
	char ch='b';
	if(ch>=65 && ch<=90)
	System.out.println("upper");
	else if(ch>=97 && ch<=122)
		System.out.println("lower");
	else if(ch>=48 && ch<=57)
		ch='8';
	else
		ch='#';
	System.out.println("character: "+ ch);
}
}
