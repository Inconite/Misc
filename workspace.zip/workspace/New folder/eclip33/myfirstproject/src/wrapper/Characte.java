package wrapper;

public class Characte
{

	public static void main(String[] args) 
	{
	char ch='u';
	String s="swaTHik";
	System.out.println(Character.isLetter(ch));
	System.out.println(Character.isDigit(7));
	//System.out.println(Character.isWhitespace(" "));
	System.out.println(s.toCharArray());
	System.out.println(s.toUpperCase());
	}
}

	