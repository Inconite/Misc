package wrapper;

public class Demo {

	public static void main(String[] args) {
	int a=5;
	Integer b =new Integer(10);
	System.out.println(a+"  "+b);
	
	int k=7;
	Integer d=k;
	System.out.println(d);
	
	Integer i=50;
	int j=i;
	System.out.println(j);
	
	
	float f1=10.88f;
	Float f2=new Float(13.87);
	System.out.println(f1+"   "+f2);
	
	}

}
