
package vowels;
import java.util.*;

public class Vowelsand 
{

	public static void main(String[] args)
	{
		Scanner scan=new Scanner(System.in);
		int a=scan.nextInt();
		
		if(a<=100 && a>=90 )
		{
			System.out.println("==========");
		}
	}

}
