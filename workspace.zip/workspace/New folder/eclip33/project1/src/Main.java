import java.io.*;
import java.util.Scanner;
public class Main 
{
public static void getSpecialChar(String s)
{
	for(int i=0;i<s.length();i++)
	{
		if(s.indexOf(i)<'A'||s.indexOf(i)>'Z'&&s.indexOf(i)<'a'||s.indexOf(i)>'z')
		{
			String str=s.replaceAll("","");
			i--;
		}
	}
	System.out.println("Output String is="+s);
}

	public static void main(String[] args) {
		
		String s;
		Scanner in = new Scanner(System.in);
        System.out.println("Enter your string =");
		s=in.nextLine();
		getSpecialChar(s);
	}

}
