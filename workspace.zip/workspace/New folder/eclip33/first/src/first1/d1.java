package first1;

import java.util.Scanner;

public class d1 {

	public static void main(String[] args) {
		Scanner s =new Scanner(System.in);
		System.out.println("Enter the innings");
		Long innings=s.nextLong();
		System.out.println("Enter the event");
		Long eventNumber=s.nextLong();
		System.out.println("Enter the raider");
		String raider=s.nextLine();
		System.out.println("Enter the Defenders");
		String defenders=s.next();
		System.out.println("Enter the raiderPoints");
		Long raiderPoints=s.nextLong();
		System.out.println("Enter the defenderPoints");
		Long defenderPoints=s.nextLong();
		
		System.out.println("Enter Details");
	  System.out.println("Innings: "+innings);
	  System.out.println("Event: +eventNumber");
	System.out.println("Raider: "+raider);
	System.out.println("Defender: "+defenders);
	System.out.println("RaiderPoints: "+raiderPoints);
	System.out.println("Defender Points: "+defenderPoints);
	
	
	}

}
