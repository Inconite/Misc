package first1;

 class Event {
	private Long	innings;
	 Long	eventNumber;
	 String	raider;
	 String	defenders;
	 Long	raiderPoints;
	 Long	defenderPoints;
	public Long getInnings() {
		return innings;
	}
	public void setInnings(Long innings) {
		this.innings = innings;
	}
	public Long getEventNumber() {
		return eventNumber;
	}
	public void setEventNumber(Long eventNumber) {
		this.eventNumber = eventNumber;
	}
	public String getRaider() {
		return raider;
	}
	public void setRaider(String raider) {
		this.raider = raider;
	}
	public String getDefenders() {
		return defenders;
	}
	public void setDefenders(String defenders) {
		this.defenders = defenders;
	}
	public Long getRaiderPoints() {
		return raiderPoints;
	}
	public void setRaiderPoints(Long raiderPoints) {
		this.raiderPoints = raiderPoints;
	}
	public Long getDefenderPoints() {
		return defenderPoints;
	}
	public void setDefenderPoints(Long defenderPoints) {
		this.defenderPoints = defenderPoints;
	}
	
	public Event(Long innings, Long eventNumber, String raider, String defenders, Long raiderPoints,
			Long defenderPoints) {
		super();
		this.innings = innings;
		this.eventNumber = eventNumber;
		this.raider = raider;
		this.defenders = defenders;
		this.raiderPoints = raiderPoints;
		this.defenderPoints = defenderPoints;
	}
	@Override
	public String toString() {
		return "Event [getInnings()=" + getInnings() + ", getEventNumber()=" + getEventNumber() + ", getRaider()="
				+ getRaider() + ", getDefenders()=" + getDefenders() + ", getRaiderPoints()=" + getRaiderPoints()
				+ ", getDefenderPoints()=" + getDefenderPoints() + "]";
	}
	public Event()
	{
		
	}
}
