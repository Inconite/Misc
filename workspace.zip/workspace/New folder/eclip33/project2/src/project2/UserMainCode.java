package project2;
import java.io.*;
import java.util.Scanner;

public class UserMainCode {
	public static void validateNumber(String s)
	{
		for(int i=0;i<s.length();i++)
		{
			if(s.indexOf(i)<0)
			{
			System.out.println("Negative number");
			}
			else
			{
			System.out.println("It will return -1");
			}		
		}
	}
	public static void main(String[] args) {
		String s;
		Scanner in = new Scanner(System.in);
        System.out.println("Enter your string =");
		s=in.nextLine();
		validateNumber(s);

	}

}
