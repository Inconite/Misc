//https://www.codingame.com/ide/puzzle/temperatures

import java.util.*;

class Solution {

   public static void main(String args[]) {

     Scanner in = new Scanner(System.in);

     int n = in.nextInt();

     int a[]=new int[n];

     int b[]=new int[n];

  if(n>0)

  {

     for (int i = 0; i < n; i++) {

       a[i] = in.nextInt(); // a temperature expressed as an integer ranging from -273 to 5526

       b[i]=a[i];

       if(a[i]<0){

       a[i]=a[i]*-1;

              }

       }

        Arrays.sort(a);

   for (int i = 0; i < n; i++)

   {

    if(a[0]==b[i])

    System.out.println(a[0]);

    else if(a[0]*-1==b[i] && a[0]!=a[1])

    { System.out.println(a[0]*-1);

     System.exit(0);}

  }



  }

  else

 { System.out.println("0");}

 }

}