package Statement;

import java.util.*;
public class Temperatures {

	public static void main(String[] args) {
		
		int n, i, p = 0, m = 0;
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		int a[] = new int[n];
		int b[] = new int[n];
		if(n > 0){
			
			for(i = 0; i < n; i++){
				a[i] = sc.nextInt();
				if(a[i] > 0){
					a[p] = a[i];
					p++;
				}else{
					b[m] = a[i];
					m++;
				}
			}
			
			/*for(int res: a){
				System.out.println(res);
			}*/
			
			for(int res1: b){
				System.out.println(res1);
			}
			
		}else{
			System.out.println("0");
		}
	}
}
