package Statement;



import java.util.*;
import java.io.*;
import java.math.*;

class Main {

    public static void main(String args[]) {
    
        int result, i, p = 0, m = 0, pl = 0, ml = 0, r1 = 0, r2 = 0;
    
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt(); 
        int[] arr = new int[n];
        
        for (i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }
        
        for(i = 0; i < n; i++){
        	if(arr[i] > 0){
        		pl++;
        	}
        	else{
        		ml++;
        	}
        }
        
        int pos[] = new int[pl];
        int neg[] = new int[ml];
        
        for(i = 0; i < n; i++){
        	if(arr[i] > 0){
        		pos[p] = arr[i];
        		p++;
        	}
        	else{
        		neg[m] = arr[i];
        		m++;
        	}
        }
        
        Arrays.sort(pos);
        Arrays.sort(neg);
        
        if(pl == 0){
        	System.out.println(neg[neg.length-1]);
        	System.exit(0);
        }
        
        if(pl == 0 && ml == 0){
        	System.out.println("0");
        	System.exit(0);
        }
        
        int resp = 0, resn = 0;
        r1 = pos[0];
        r2 = neg[neg.length-1];
        
        for(i = r1; r1 > 0; r1--){
        	resp++;
        }
        for(i = r2; r2 < 0; r2++){
        	resn++;
        }
        
        if(resp <= resn){
        	System.out.println(pos[0]);
        }else{
        	System.out.println(neg[neg.length-1]);
        }


    }
}