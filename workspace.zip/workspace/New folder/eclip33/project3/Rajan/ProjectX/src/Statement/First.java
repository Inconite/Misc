package Statement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class First {
public static void main(String args[])

{
Connection c;
Statement s;
ResultSet r;

try
{
 Class.forName("com.mysql.jdbc.Driver");
 c=DriverManager.getConnection("jdbc:mysql://localhost:3306/dbx","root","root");
 s= c.createStatement();
 r=s.executeQuery("select * from tablex");
 
while(r.next())
{
 System.out.println( r.getInt(1)+"\t"+r.getString(2)+"\t"+r.getString(3));
 }
}

catch
 (ClassNotFoundException e){
 e.printStackTrace();
}

catch

(SQLException q){
q.printStackTrace();

}
}
}



