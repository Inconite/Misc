package Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class Second {
public static void main(String args[])
{

Connection c;
Statement s;
ResultSet r;

try
{
 Class.forName("com.mysql.jdbc.Driver");
 c = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbx","root","root");
 s = c.createStatement();
//	r=s.executeQuery("select * from account");

 int n = s.executeUpdate("CREATE TABLE Animal5s1 ( idno VAoklRCHAR(10));");
 if(n==0)
 System.out.println("Done");
 else
 System.out.println("Sorry");
 
}

catch
 (ClassNotFoundException e){
 e.printStackTrace();
}

catch
(SQLException q){
q.printStackTrace();
}
}
}

