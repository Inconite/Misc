import java.util.Scanner;



public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		System.out.println("Enter the number of venues");

		int a=sc.nextInt();

		sc.nextLine();

		String s[]=new String[a];

		Venue v=new Venue();

		for(int i=0;i<a;i++)

		{

			System.out.println("Enter the details of venue "+(i+1));

			s[i]=sc.nextLine();

		}

		

		System.out.println("Venue Details");

    for(int i=0;i<a;i++)

    {

    	String s1[]=s[i].split(",");

    	v.setName(s1[0]);

    	v.setCity(s1[1]);

      System.out.println("Venue Name : "+v.getName());

		System.out.println("City Name : "+v.getCity());

    }

		

		

	}



}



