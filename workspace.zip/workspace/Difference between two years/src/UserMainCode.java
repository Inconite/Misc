import java.text.SimpleDateFormat;

import java.util.Calendar;

import java.text.*;

import java.util.*;



public class UserMainCode {

public static void displayDateDetails(String s, String t) throws Exception

{

	

	int y=0;

	SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM-dd");

	Calendar c=Calendar.getInstance();

	Date d1=sdf1.parse(s);

	Date d2=sdf1.parse(t);

	

	c.setTime(d1);

	int year1=c.get(Calendar.YEAR);

	int month1=c.get(Calendar.MONTH);

	int date1=c.get(Calendar.DATE);

	

	c.setTime(d2);

	int year2=c.get(Calendar.YEAR);

	int month2=c.get(Calendar.MONTH);

	int date2=c.get(Calendar.DATE);

	if(year2>year1)

	{

		 y=year2-year1;

	}

	int d=date2-date1;

	int m=month2-month1;

	if(d<0)

	{

		d=Math.abs(d);

		m=m-1;

	}

	

	if(m<0)

	{

		y=y-1;

		m=Math.abs(m);

	}

	System.out.print("Difference between "+sdf1.format(d1)+" and " +sdf1.format(d2)+": ");

	if(y>0)

	{

		System.out.print(y+" Years "+"and ");

	}

	if(m>0)

	{

		System.out.print(m+" Months ");

	}

//	if(d>0)

//	{

//		System.out.print(d+" Days");

//	}

}

}