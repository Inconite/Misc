public class UmpireTypeBO {



	public UmpireType createUmpireType(String data)

{

 UmpireType ut=new UmpireType(data);

 

 return ut;

}

}