public class UmpireType {



	private String type;



UmpireType()

{



}

 

	public UmpireType(String type) {

 

 super();

 

 this.type = type;

}

 

	public String getType() {

 

 return type;

}

 

	public void setType(String type) {

 

 this.type = type;

}





}