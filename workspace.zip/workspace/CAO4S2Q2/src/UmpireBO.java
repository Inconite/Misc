public class UmpireBO {



	public Umpire createUmpire(String data,UmpireType[] umpireTypeList)

{

 Umpire ump=new Umpire();

 

 String s[]=data.split(",");

 

 for(int i=0;i<umpireTypeList.length;i++)

{

 if(umpireTypeList[i].getType().equals(s[1]))

{

 ump=new Umpire(s[0], umpireTypeList[i]);

}

}

 return ump;

}

}



