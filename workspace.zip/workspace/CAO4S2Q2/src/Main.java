import java.util.*;

  public class Main {

  

	public static void main(String[] args) {



 Scanner sc=new Scanner(System.in);



 boolean flag=true;

 

 int choice;

 

 String buffer=null;

 

 String con=null;

 

 System.out.println("Enter the umpire type count");

 

 int umtc=sc.nextInt();

 

 sc.nextLine();

 

 int i;

 

 UmpireType ut[]=new UmpireType[umtc];

 

 UmpireTypeBO utbo=new UmpireTypeBO();

 

 for(i=0;i<umtc;i++)

{

 System.out.println("Enter umpire type "+(i+1)+" details");

 

 ut[i]=utbo.createUmpireType(sc.nextLine());

}



 System.out.println("Enter the umpire count");

 

 int uc=sc.nextInt();

 

 sc.nextLine();

 

 Umpire um[]=new Umpire[uc];

 

 UmpireBO ubo=new UmpireBO();

 

 for(i=0;i<uc;i++)

{

 System.out.println("Enter umpire "+(i+1)+" details");

 

 um[i]=ubo.createUmpire(sc.nextLine(), ut);

}



 System.out.println("Enter the match count");

 

 int mc=sc.nextInt();

 

 sc.nextLine();

 

 Match mat[]=new Match[mc];

 

 MatchBO mbo=new MatchBO();



 for(i=0;i<mc;i++)

{

 System.out.println("Enter match "+(i+1)+" details");

 

 mat[i]=mbo.createMatch(sc.nextLine(), um);

}



 do{

 

 System.out.println("Menu :\n1)Find Umpire\n2)Find All Matches In A Specific Venue\nType 1 or 2 \nEnter your choice");

 

 choice=sc.nextInt();



 switch(choice)

{

 case 1:

 

 sc.nextLine();

 

 System.out.println("Enter Match date");

 

 buffer=sc.nextLine();

 

 Umpire u=mbo.findUmpire(buffer, mat);

 

 System.out.println(u.toString());

 

 break;

 

 case 2:

 

 sc.nextLine();

 

 System.out.println("Enter Umpire Name");

 

 buffer=sc.nextLine();

 

 mbo.findAllMatchesOfGivenUmpire(buffer, mat);

 

 break;

 

 default:

System.exit(0);

}



 System.out.println("Do you want to continue? Type Yes or No");

 

 con=sc.nextLine();

 

 if(con.equals("Yes"))

{

 flag=true;

}

 else

 {

 flag=false;

}

 }while(flag);



 sc.close();

 }

}