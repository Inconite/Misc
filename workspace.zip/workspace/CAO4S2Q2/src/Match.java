 

public class Match {



	private String date;

 

	private String teamone;

 

	private String teamtwo;

 

	Umpire umpire;



Match()

{



}

 

	public Match(String date, String teamone, String teamtwo, Umpire umpire) {

 

 super();

 

 this.date = date;

 

 this.teamone = teamone;

 

 this.teamtwo = teamtwo;

 

 this.umpire = umpire;

}



	public String toString()

{

 return "Match Details:\n"+(String.format("%-15s %-15s %-15s", "Date","TeamOne","TeamTwo"))+"\n"+(String.format("%-15s %-15s %-15s", date,teamone,teamtwo));

}

 

	public String getDate() {

 

 return date;

}

 

	public void setDate(String date) {

 

 this.date = date;

}

 

	public String getTeamone() {

 

 return teamone;

}

 

	public void setTeamone(String teamone) {

 

 this.teamone = teamone;

}

 

	public String getTeamtwo() {

 

 return teamtwo;

}

 

	public void setTeamtwo(String teamtwo) {

 

 this.teamtwo = teamtwo;

}

 

	public Umpire getUmpire() {

 

 return umpire;

}

 

	public void setUmpire(Umpire umpire) {

 

 this.umpire = umpire;

}

}