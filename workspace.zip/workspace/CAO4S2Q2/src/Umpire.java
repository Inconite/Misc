public class Umpire {



	private String name;

 

	UmpireType umpireType;



Umpire()

{



}

 

	public Umpire(String name, UmpireType umpireType) {

super();

 this.name = name;

 

 this.umpireType = umpireType;

}



	public String toString()

{

 return "Umpire\n"+name;

}

 

	public String getName() {

 

 return name;

}

 

	public void setName(String name) {

 

 this.name = name;

}

 

	public UmpireType getUmpireType() {

 

 return umpireType;

}

 

	public void setUmpireType(UmpireType umpireType) {

 

 this.umpireType = umpireType;

}





}