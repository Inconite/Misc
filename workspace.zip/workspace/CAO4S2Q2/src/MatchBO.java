public class MatchBO {

  

	public Match createMatch(String data, Umpire[] umpireList)

{

 String s[]=data.split(",");

 

 Match m=new Match();

 

 for(int i=0;i<umpireList.length;i++)

{

 if(umpireList[i].getName().equals(s[3]))

{

 m=new Match(s[0], s[1], s[2], umpireList[i]);

}

}

 return m;

}



	public Umpire findUmpire(String matchDate, Match[] matchList)

{

 Umpire u=new Umpire();

 

 for(int i=0;i<matchList.length;i++)

{

 if(matchList[i].getDate().equals(matchDate))

{

 u=matchList[i].getUmpire();

}

}

 return u;

}



	public void findAllMatchesOfGivenUmpire(String umpireName, Match[] matchList)

{

 for(int i=0;i<matchList.length;i++)

{

 if(matchList[i].umpire.getName().equals(umpireName))

{

 System.out.println(matchList[i].toString());

}

}

}

}