import java.util.*;
import java.text.*;
public class Main {
public static void main(String args[]) throws Exception{
	Scanner sc=new Scanner(System.in);
	UserMainCode u=new UserMainCode();
	String s;
	System.out.println("Enter String in this format(yyyy-MM-DD HH:mm:ss)");
	s=sc.nextLine();
	u.displayDateTime(s);
}
}
