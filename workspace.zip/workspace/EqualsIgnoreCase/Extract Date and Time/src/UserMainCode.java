
import java.text.*;
import java.util.Date;
public class UserMainCode {
	public void displayDateTime(String s) throws Exception{
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date d=sdf.parse(s);
		SimpleDateFormat sdf2=new SimpleDateFormat("dd/MM/yyyy, H:mm:ss");
		String fd2=sdf2.format(d);
		System.out.println(fd2);

	}
}
