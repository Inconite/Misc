class OutcomeBO



{



OutcomeBO(){ }



void displayAllOutcomeDetails(Outcome[] outcomeList) 



{



 System.out.println("Outcome Details");



 String s="Score";



 String w="Winning Team";



 String p="Player Of The Match";  



 String d="Date";



 System.out.printf("%-20s %-20s %-20s %s",s,w,p,d);



 System.out.println();



 int count=outcomeList.length;



 for(int i=0;i<count;i++)



 {



  System.out.println(outcomeList[i]);



 }



} 



void displaySpecificOutcomeDetails(Outcome[] outcomList, String date)



{



 System.out.println("Outcome Details");



 String s="Score";



 String w="Winning Team";



 String p="Player Of The Match";  



 String d="Date";



 System.out.printf("%-20s %-20s %-20s %s",s,w,p,d);



 System.out.println();



 int count=outcomList.length;



 for(int i=0;i<count;i++)



 {



  if(outcomList[i].getDate().equals(date))



  {



   System.out.println(outcomList[i]);



  }



 }



}



} 