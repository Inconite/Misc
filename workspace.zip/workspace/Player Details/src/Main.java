import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	String nm,cn,sk;
	System.out.println("Enter the player name");
	nm=sc.nextLine();
	System.out.println("Enter the country name");
	cn=sc.nextLine();
	System.out.println("Enter the skill");
	sk=sc.nextLine();
	Player p=new Player();
	p.setName(nm);
	p.setCountry(cn);
	p.setSkill(sk);
	System.out.println("Player Details");
	String str=p.toString();
	System.out.println(str);
}
}
