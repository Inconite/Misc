import java.util.*;
public class Main {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of the scores:");
		int n = Integer.parseInt(sc.nextLine());
		String[] details = new String[n];
		List<Score> list = new ArrayList<Score>();
		for(int i=0;i<n;i++)
		{
			details[i] = sc.nextLine();
			list.add(Score.createScore(details[i]));
		}
		
		
		System.out.println("Enter a type to sort:\n1.Sort by Student Name\n2.Sort by Maths Score");
		int ch = Integer.parseInt(sc.nextLine());
		if(ch==1)
		{
			Collections.sort(list);
		}
		else if(ch==2)
		{
			Collections.sort(list,new MarkComparator());
			Collections.reverse(list);
		}
		
		System.out.format("%-12s %-8s %-8s %-10s %-8s %-16s %-6s %s\n","Exam Name","English","Physics","Chemistry","Biology","Computer Science","Maths","Student Name");
		for(Score score:list)
		{
			System.out.print(score.toString());
		}
	}
}
