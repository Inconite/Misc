import java.util.Comparator;

public class MarkComparator implements Comparator<Score> {

	@Override
	public int compare(Score o1, Score o2) {
		return o1.getMaths().compareTo(o2.getMaths());
	}

	
}
