public class Score implements Comparable<Score> {
	private String examName;
	private int english;
	private int physics;
	private int chemistry;
	private int biology;
	private int computerScience;
	private Integer maths;
	private String studentName;
	
	
	
	public Score(String examName, int english, int physics, int chemistry, int biology, int computerScience, int maths,
			String studentName) {
		super();
		this.examName = examName;
		this.english = english;
		this.physics = physics;
		this.chemistry = chemistry;
		this.biology = biology;
		this.computerScience = computerScience;
		this.maths = maths;
		this.studentName = studentName;
	}



	public Score() {
		super();
		// TODO Auto-generated constructor stub
	}



	public static Score createScore(String detail){
		String[] details = detail.split(",");
		return new Score(details[0],Integer.parseInt(details[1]),Integer.parseInt(details[2]),Integer.parseInt(details[3]),Integer.parseInt(details[4]),Integer.parseInt(details[5]),Integer.parseInt(details[6]),details[7]);
	}



	public String getExamName() {
		return examName;
	}



	public void setExamName(String examName) {
		this.examName = examName;
	}



	public int getEnglish() {
		return english;
	}



	public void setEnglish(int english) {
		this.english = english;
	}



	public int getPhysics() {
		return physics;
	}



	public void setPhysics(int physics) {
		this.physics = physics;
	}



	public int getChemistry() {
		return chemistry;
	}



	public void setChemistry(int chemistry) {
		this.chemistry = chemistry;
	}



	public int getBiology() {
		return biology;
	}



	public void setBiology(int biology) {
		this.biology = biology;
	}



	public int getComputerScience() {
		return computerScience;
	}



	public void setComputerScience(int computerScience) {
		this.computerScience = computerScience;
	}



	public Integer getMaths() {
		return maths;
	}



	public void setMaths(int maths) {
		this.maths = maths;
	}



	public String getStudentName() {
		return studentName;
	}



	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}



	@Override
	public int compareTo(Score sc) {
		return this.studentName.compareToIgnoreCase(sc.studentName);
	}
	
	public String toString()
	{
		return String.format("%-12s %-8s %-8s %-10s %-8s %-16s %-6s %s\n",this.examName,this.english,this.physics,this.chemistry,this.biology,this.computerScience,this.maths,this.studentName);
	}
}
