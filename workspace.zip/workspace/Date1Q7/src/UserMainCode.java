import java.text.SimpleDateFormat;

import java.time.YearMonth;

import java.util.Calendar;

import java.util.Date;



public class UserMainCode {

public static void displayDay(int y) 

{

	SimpleDateFormat sdf=new SimpleDateFormat("EEE");

	Calendar c=Calendar.getInstance();

	c.set(Calendar.YEAR, y);

	c.set(Calendar.MONTH, 0);

	c.set(Calendar.DATE, 1);

	Date d1=c.getTime();

	System.out.println("Start Day of the given year is "+sdf.format(d1));

	c.set(Calendar.YEAR, y);

	c.set(Calendar.MONTH, 11);

	c.set(Calendar.DATE, 31);

	Date d2=c.getTime();

	System.out.println("End Day of the given year is "+sdf.format(d2));

	

}

}