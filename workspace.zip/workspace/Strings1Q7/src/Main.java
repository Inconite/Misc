
import java.util.*;

public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		

		System.out.println("Enter player names");

		String a=sc.nextLine();

		String b=sc.nextLine();

		

		if((a.regionMatches(0,"Michael",0,6)) && (b.regionMatches(0,"Michael",0,6)))

		{

			System.out.println("Both the players names starts with Michael");

		}

		else

			System.out.println("Both the players names does not starts with Michael");

	}



}

