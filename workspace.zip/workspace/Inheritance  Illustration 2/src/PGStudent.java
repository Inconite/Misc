	public class PGStudent extends Student{

			private String specialization;

			private int noOfPapersPublished;

			public String getSpecialization() {

				return specialization;

			}

			public void setSpecialization(String specialization) {

				this.specialization = specialization;

			}

			public int getNoOfPapersPublished() {

				return noOfPapersPublished;

			}

			public void setNoOfPapersPublished(int noOfPapersPublished) {

				this.noOfPapersPublished = noOfPapersPublished;

			}

			PGStudent()

			{

				

			}

			PGStudent(String n,String i, int a, double g, String add, String s, int p)

			{

				this.name=n;

				this.id=i;

				this.age=a;

				this.grade=g;

				this.address=add;

				this.specialization=s;

				this.noOfPapersPublished=p;

			}

			Student st=new Student(name,id,age,grade,address);

			public void display()

			{

				super.display();

//					System.out.println("PG Student Details");

//				System.out.println("Name : "+name);

//				System.out.println("Id : "+ id);

//				System.out.println("Age : "+ age);

//				System.out.println("Grade : "+ grade);

//				System.out.println("Address : "+ address);

				System.out.println("Specialization : "+specialization );

				System.out.println("No. of papers published : "+ noOfPapersPublished);

//				if(isPassed()==true)

//					System.out.println("Result : Pass");

//					else

//						System.out.println("Result : Fail");

			}

			public boolean isPassed()

			{

				if(grade>70 && noOfPapersPublished>=2)

					return true;

				else

					return false;

			}

			



	}



