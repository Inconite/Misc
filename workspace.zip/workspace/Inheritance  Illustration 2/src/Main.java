import java.util.*;

public class Main {



	public static void main(String[] args) {

		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);

System.out.println("Menu\n1) Create a Student\n2) Create a UG Student\n3) Create a PG Student\nEnter your choice");

int ch=sc.nextInt();

switch(ch)

{

case 1: 

	sc.nextLine();

	System.out.println("Enter name");

String name=sc.nextLine();

System.out.println("Enter id");

String id=sc.nextLine();



System.out.println("Enter age");

int age=sc.nextInt();



System.out.println("Enter grade");

double grade=sc.nextDouble();

sc.nextLine();

System.out.println("Enter address");

String address=sc.nextLine();

Student st=new Student(name,id,age,grade,address);

System.out.println("Student Details");

st.display();

if(st.isPassed()==true)

System.out.println("Result : Pass");

	else

		System.out.println("Result : Fail");



break;

case 2:

	sc.nextLine();

	System.out.println("Enter name");

	String name1=sc.nextLine();

	System.out.println("Enter id");

	String id1=sc.nextLine();



	System.out.println("Enter age");

	int age1=sc.nextInt();



	System.out.println("Enter grade");

	double grade1=sc.nextDouble();

	sc.nextLine();

	System.out.println("Enter address");

	String address1=sc.nextLine();

	System.out.println("Enter degree");

	String degree=sc.nextLine();

	System.out.println("Enter stream");

	String stream=sc.nextLine();

	UGStudent st1=new UGStudent(name1,id1,age1,grade1,address1,degree,stream);

	System.out.println("UG Student Details");

	st1.display();

	if(st1.isPassed()==true)

		System.out.println("Result : Pass");

			else

				System.out.println("Result : Fail");

	break;

case 3:

	sc.nextLine();

	System.out.println("Enter name");

	String name2=sc.nextLine();

	System.out.println("Enter id");

	String id2=sc.nextLine();



	System.out.println("Enter age");

	int age2=sc.nextInt();



	System.out.println("Enter grade");

	double grade2=sc.nextDouble();

	sc.nextLine();

	System.out.println("Enter address");

	String address2=sc.nextLine();

	System.out.println("Enter specialization");

	String spec=sc.nextLine();

	System.out.println("Enter number of papers published");

	int pap=sc.nextInt();

	PGStudent st2=new PGStudent(name2,id2,age2,grade2,address2,spec,pap);

	System.out.println("PG Student Details");

	st2.display();

	if(st2.isPassed()==true)

		System.out.println("Result : Pass");

			else

				System.out.println("Result : Fail");

	break;

}

	

	}



}