/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

import java.util.*;
public class Main {
	public static void main(String args[])
	{
			Scanner sc=new Scanner(System.in);
			int a=sc.nextInt();
			int b=sc.nextInt();
			int cnt=0;
			if((a==1)||(a==2))
			System.out.print(2 +" ");
			for(int i=a;i<=b;i++)
			{
			
				for(int j=2;j<i;j++)
				{
					if(i%j==0)
					{
						cnt=0;
						break;
					}
					else
					{
					    cnt=1;
					}
				}
				if (cnt==1)
				System.out.print(i+" ");
				cnt=0;
			}
	}
}

