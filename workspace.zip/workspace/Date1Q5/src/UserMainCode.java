  import java.text.SimpleDateFormat;

import java.util.Calendar;

import java.util.Date;

import java.text.*;

public class UserMainCode {

public static void displayDateDetails(String s) throws Exception

{

	SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM-dd");

Date d=sdf1.parse(s);

	Calendar c=Calendar.getInstance();

	c.setTime(d);

	int year=c.get(Calendar.YEAR);

	c.add(Calendar.YEAR,1);

	Date d1=c.getTime();

	c.add(Calendar.YEAR,-2);

	Date d2=c.getTime();

	

	String s1=sdf1.format(d1);

	String s2=sdf1.format(d2);

System.out.println(s1);

	System.out.println(s2);                                                

}

}