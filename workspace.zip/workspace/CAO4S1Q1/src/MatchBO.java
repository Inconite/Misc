public class MatchBO {



	public void printAllMatchDetails(Match[] matchList)

{

 System.out.println("Match Details");

 

 System.out.println((String.format("%-15s %-15s %-15s %-15s %-15s %s", "Date","Team1","Team2","Venue","Status","Winner")));

 

 for(int i=0;i<matchList.length;i++)

{

 System.out.println(matchList[i].toString());

}

}



	public void printMatchDetailsWithOutcomeStatus(Match[] matchList, String outcomeStatus)

{

 System.out.println("Match Details");

 

 System.out.println((String.format("%-15s %-15s %-15s %-15s %-15s %s", "Date","Team1","Team2","Venue","Status","Winner")));

 

 for(int i=0;i<matchList.length;i++)

{

 if(matchList[i].outcome.getStatus().equals(outcomeStatus))

{

 System.out.println(matchList[i].toString());

}

}

}



	public void printMatchDetailsWithOutcomeWinnerTeam(Match[] matchList, String outcomeWinnerTeam)

{

 System.out.println("Match Details");

 

 System.out.println((String.format("%-15s %-15s %-15s %-15s %-15s %s", "Date","Team1","Team2","Venue","Status","Winner")));

 

 for(int i=0;i<matchList.length;i++)

{

 if(matchList[i].outcome.getWinnerTeam().equals(outcomeWinnerTeam))

{

 System.out.println(matchList[i].toString());

}

}

}

}

