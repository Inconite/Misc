
import java.util.*;

  public class Main {

  

	public static void main(String[] args) {

 

 Scanner sc=new Scanner(System.in);

 

 System.out.println("Enter number of matches");

 

 int n=sc.nextInt();

 

 sc.nextLine();

 

 int i;

 

 String date;

 

 String teamOne;

 

 String teamTwo;

 

 String venue;

 

 String status;

 

 String winnerTeam;

 

 Match m[]=new Match[n];

 

 Outcome o[]=new Outcome[n];

 

 boolean flag=true;

 

 int choice;

 

 for(i=0;i<n;i++)

{

 System.out.println("Enter match "+(i+1)+" details:");

 

 System.out.println("Enter match date");

 

 date=sc.nextLine();

 

 System.out.println("Enter team one");

 

 teamOne=sc.nextLine();

 

 System.out.println("Enter team two");

 

 teamTwo=sc.nextLine();

 

 System.out.println("Enter venue");

 

 venue=sc.nextLine();

 

 System.out.println("Enter status");

 

 status=sc.nextLine();

 

 System.out.println("Enter winner Team");

 

 winnerTeam=sc.nextLine();

 

 o[i]=new Outcome(status, winnerTeam);

 

 m[i]=new Match(date, teamOne, teamTwo, venue, o[i]);

}

 MatchBO mbo=new MatchBO();



 do{

 

 System.out.println("Menu");

 

 System.out.println("1.View match details\n2.Filter match details with outcome status");

 

 System.out.println("3.Filter match details with outcome winner team\n4.Exit\nEnter your choice");

 

 choice=sc.nextInt();

 

 switch(choice)

{

 case 1:

 

 mbo.printAllMatchDetails(m);

 

 break;

 

 case 2:

 

 sc.nextLine();

 

 System.out.println("Enter outcome status");

 

 status=sc.nextLine();

 

 mbo.printMatchDetailsWithOutcomeStatus(m, status);

 

 break;

 

 case 3:

 

 sc.nextLine();

 

 System.out.println("Enter outcome winner team");

 

 winnerTeam=sc.nextLine();

 

 mbo.printMatchDetailsWithOutcomeWinnerTeam(m, winnerTeam);

 

 break;

 

 case 4:

 

 flag=false;

 

 break;

 

 default:

System.exit(1);

}

 }while(flag);

 

 sc.close();

 }

}





