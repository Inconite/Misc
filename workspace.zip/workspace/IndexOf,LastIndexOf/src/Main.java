import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	int n,i,j;
	System.out.println("Enter the number of players");
	n=sc.nextInt();
	sc.nextLine();
	String a[]=new String[n];
	for(i=0;i<n;i++)
	{
		a[i]=sc.nextLine();
	}
	String s="",str="";
	for(i=0;i<n;i++)
	{
		s=a[i];
	
	for(j=0;j<s.length();j++)
	{
		if(s.charAt(j)=='a')
		{
			if(s.indexOf('a')==s.lastIndexOf('a')) {
				System.out.println("Player of the Match:\n"+s);
				
			}
		}
	}
}
}
}
