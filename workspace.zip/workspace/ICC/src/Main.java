import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the name of the user :");
		String name = sc.nextLine();
		System.out.println("Enter the username :");
		String username = sc.nextLine();
		System.out.println("Enter the password :");
		String password = sc.nextLine();
		System.out.println("Enter the email :");
		String email = sc.nextLine();
		System.out.println("Enter the phonenumber :");
		String ph = sc.nextLine();
		System.out.println("Enter the type of user");
		System.out.println("1.Customer");
		System.out.println("2.Seller");
		int n = sc.nextInt();
		sc.nextLine();
		
		if(n==1)
		{
			System.out.println("Enter the delivery address :");
			String address = sc.nextLine();
			System.out.println("Enter the bonus points :");
			int bp = sc.nextInt();
			sc.nextLine();
			System.out.println("Enter the credit details :");
			String cd = sc.nextLine();
			User u = new Customer(name, username, password, email, ph, address, bp, cd);
			System.out.println("Customer Details :");
			u.displayDetails();
		}
		else
		{
			System.out.println("Enter the description :");
			String desc = sc.nextLine();
			System.out.println("Enter the rating :");
			double rating = sc.nextDouble();
			User u = new Seller(name, username, password, email, ph, desc, rating);
			System.out.println("Seller Details :");
			u.displayDetails();
		}
	}

}
