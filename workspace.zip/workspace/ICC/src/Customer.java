
public class Customer extends User 
{
	private String deliveryAddress;
	private int bonusPoints;
	private String creditDetails;
	
	public Customer(){};
	public Customer(String name, String username, String password, String email, String phonenumber,
			String deliveryAddress, int bonusPoints, String creditDetails) {
		super(name, username, password, email, phonenumber);
		this.deliveryAddress = deliveryAddress;
		this.bonusPoints = bonusPoints;
		this.creditDetails = creditDetails;
	}
	
	
	
	public Customer(String name, String username, String password, String email, String phonenumber) {
		super(name, username, password, email, phonenumber);
		// TODO Auto-generated constructor stub
	}
	public Customer(String deliveryAddress, int bonusPoints, String creditDetails) {
		super();
		this.deliveryAddress = deliveryAddress;
		this.bonusPoints = bonusPoints;
		this.creditDetails = creditDetails;
	}
	public void displayDetails()
	{
		System.out.println("Name : "+name+"\nUsername : "+username+"\nPassword : "+password+"\nEmail : "+email+"\nPhonenumber : "+phonenumber+"\nDelivery address : "+deliveryAddress+"\nBonus points : "+bonusPoints+"\nCredit details : "+creditDetails);
	}
}
