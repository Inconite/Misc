
public class User
{
	protected String name;
	protected String username;
	protected String password;
	protected String email;
	protected String phonenumber;
	
	public User(){};
	public User(String name, String username, String password, String email, String phonenumber) {
		super();
		this.name = name;
		this.username = username;
		this.password = password;
		this.email = email;
		this.phonenumber = phonenumber;
	}
	
	public void displayDetails()
	{
		
	}
}
