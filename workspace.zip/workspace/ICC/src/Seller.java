import java.text.DecimalFormat;

public class Seller extends User
{
	private String description;
	private double rating;
	
	public Seller(){};
	public Seller(String name, String username, String password, String email, String phonenumber, String description,
			double rating) {
		super(name, username, password, email, phonenumber);
		this.description = description;
		this.rating = rating;
	}
	
	public Seller(String name, String username, String password, String email, String phonenumber) {
		super(name, username, password, email, phonenumber);
		// TODO Auto-generated constructor stub
	}
	public Seller(String description, double rating) {
		super();
		this.description = description;
		this.rating = rating;
	}
	public void displayDetails()
	{
		DecimalFormat df = new DecimalFormat("#0.00");
		System.out.println("Name : "+name+"\nUsername : "+username+"\nPassword : "+password+"\nEmail : "+email+"\nPhonenumber : "+phonenumber+"\nDescription : "+description+"\nRating : "+df.format(rating));
	}
}
