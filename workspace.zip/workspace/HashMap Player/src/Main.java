import java.util.HashMap;

import java.util.Map;

import java.util.Scanner;



public class Main {



	public static void main(String[] args) 

	{

		Scanner sc=new Scanner(System.in);

		boolean b=true;

		HashMap<String,Player> h=new HashMap<>();

		while(b==true)

		{

		System.out.println("Enter the player name");

		String name=sc.nextLine();

		System.out.println("Enter wickets - seperated by \"|\" symbol.");

		String s=sc.nextLine();

		String j[]=s.split("\\|");

		h.put(name,new Player(name,j.length));

		System.out.println("Do you want to add another player (yes/no)");

		String ch=sc.nextLine();

		if(ch.equalsIgnoreCase("yes"))

		{

			b=true;

		}

		

		else

			b=false;

		

	}

		int flag=0;

		boolean c=true;

		while(c)

		{

			flag=0;

		System.out.println("Enter the player name to search");

		String ans=sc.nextLine();

		for(Map.Entry m:h.entrySet())

		{

			if(((String)m.getKey()).equalsIgnoreCase(ans))

			{

		    flag=1;

				System.out.println("Player name : "+m.getKey());

				Player p=(Player) m.getValue();

				System.out.println("Wicket Count : "+p.getWicketCount());

			}

		}

		if(flag==0)

		{

			System.out.println("No player found with the name "+ans);

		}

			System.out.println("Do you want to search another player (yes/no)");

		String y=sc.nextLine();

		

		if(y.equalsIgnoreCase("yes"))

		{

			c=true;

		}

		else c=false;

		}



	}



}