import java.util.Scanner;



public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		System.out.println("Enter the match date");

		String date=sc.nextLine();

		System.out.println("Enter the team one");

		String teamone=sc.nextLine();

		System.out.println("Enter the team two");

		String teamtwo=sc.nextLine();

		System.out.println("Enter the Venue");

		String venue=sc.nextLine();

		

		Match m=new Match();

		m.setDate(date);

		m.setTeamOne(teamone);

	m.setTeamTwo(teamtwo);

	m.setVenue(venue);

	System.out.println("Match Details");

	System.out.println(m.toString());

			



	}



}



