import java.util.*;

public class Main {



	public static void main(String[] args) {

		// TODO Auto-generated method stub

Scanner sc=new Scanner(System.in);

int y=sc.nextInt();

int m=sc.nextInt();

UserMainCode.displayDay(y,m);

	}



}