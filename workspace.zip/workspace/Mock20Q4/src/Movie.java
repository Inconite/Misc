import java.text.DecimalFormat;



 



 



public class Movie {



         //Your code goes here



   private String name;



   private Double boxoffice;



   private Double budget;



   private Double rating;



   



   public Movie(){}



 



   



   public Movie(String name, Double boxoffice, Double budget, Double rating) {



      super();



      this.name = name;



      this.boxoffice = boxoffice;



      this.budget = budget;



      this.rating = rating;



   }



   public String getName() {



      return name;



   }



   public void setName(String name) {



      this.name = name;



   }



   public Double getBoxoffice() {



      return boxoffice;



   }



   public void setBoxoffice(Double boxoffice) {



      this.boxoffice = boxoffice;



   }



   public Double getBudget() {



      return budget;



   }



   public void setBudget(Double budget) {



      this.budget = budget;



   }



   public Double getRating() {



      return rating;



   }



   public void setRating(Double rating) {



      this.rating = rating;



   }



   



   public String toString() {



      DecimalFormat df=new DecimalFormat("#.0");



      return String.format("%-22s %-10s %-8s %s\n",name,boxoffice,budget,rating);



   }



   



 



}


 

 