import java.util.*;



public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		

		System.out.println("Enter the number of matches");

		int n=sc.nextInt();

		sc.nextLine();

		Match m[]=new Match[n];

		int i; 

		String date=null;

		String teamOne=null;

		String teamTwo=null;

		String venue=null;

		

		for(i=0;i<n;i++)

		{

			System.out.println("Enter match "+(i+1)+" details");

			System.out.println("Enter the match date");

			date=sc.nextLine();

			System.out.println("Enter the team one");

			teamOne=sc.nextLine();

			System.out.println("Enter the team two");

			teamTwo=sc.nextLine();

			System.out.println("Enter the Venue");

			venue=sc.nextLine();

			m[i]=new Match(date, teamOne, teamTwo, venue);

		}

		MatchBO mat=new MatchBO();

		mat.displayAllMatchDetails(m);

		

		System.out.println("Enter the date to be searched");

		String dt=sc.nextLine();

		mat.displaySpecificMatchDetails(m, dt);

		sc.close();



	}



}

