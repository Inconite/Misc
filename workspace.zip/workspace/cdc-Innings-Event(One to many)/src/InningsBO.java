class InningsBO

{

	public Innings createInnings (long inningsNumber)

	{

		

		//fill your code;

		Innings in=new Innings(inningsNumber);

		return in;

		

	}

}



