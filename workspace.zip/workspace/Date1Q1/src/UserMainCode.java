import java.text.*;
import java.util.*;
public class UserMainCode {

	public static void displayDate(String a)throws ParseException
	{
		
		SimpleDateFormat sdf1=new SimpleDateFormat("MMMMM dd, yy");

		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");

		Date d1 = sdf1.parse(a);



		System.out.println(sdf.format(d1));  
		
		
		
		
	}
	
	
	
	
	
	
	
	
}
