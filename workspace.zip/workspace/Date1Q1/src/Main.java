import java.util.*;
import java.text.*;
public class Main {

	public static void main(String[] args) throws ParseException
	{
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		String a=sc.nextLine();
		UserMainCode.displayDate(a);
		
		
}

}
