import java.util.Scanner;

import java.util.jar.Attributes.Name;



public class Main {

 public static void main(String[] args) {

  

  

  Scanner sc=new Scanner(System.in);

  

  System.out.println("Menu");

  System.out.println("1.Crciket Player Details\n2.Hockey Player Details");

  

  System.out.println("Enter choice");

  int n=sc.nextInt();

 

  switch(n)

  {

          

  

  case 1:sc.nextLine(); 

   System.out.println("Enter player name");

          String pname=sc.nextLine();

          

          System.out.println("Enter team name");

          String tname=sc.nextLine();

          

          System.out.println("Enter number of matches played");

          long matches=sc.nextLong();

          

          System.out.println("Enter total runs scored");

          long runs=sc.nextLong();

          

          System.out.println("Enter total number of wickets taken");

          long wickets=sc.nextLong();

          

          System.out.println("Player Details");

          CricketPlayer cp=new CricketPlayer(pname, tname, matches, runs, wickets);

          cp.displayPlayerStatistics();

          break;

          

  case 2:sc.nextLine(); 

   System.out.println("Enter player name");

         pname=sc.nextLine();

         

         System.out.println("Enter team name");

         tname=sc.nextLine();

         

         System.out.println("Enter number of matches played");

         matches=sc.nextLong();

         sc.nextLine();

         System.out.println("Enter the position");

         String position=sc.nextLine();

         

         System.out.println("Enter total number of goals taken");

         long goals=sc.nextLong();

         System.out.println("Player Details");

         HockeyPlayer hp=new HockeyPlayer(pname, tname, matches, position, goals);

         hp.displayPlayerStatistics();

         break;

  default:System.out.println("Invalid Input");

    break;

  }

 }

}