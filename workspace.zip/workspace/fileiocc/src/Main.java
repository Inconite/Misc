import java.io.*;



import java.util.*;



public class Main



{



 public static void main(String args[])throws IOException



 {



  String n="",t="",sk="";



  BufferedReader br=new BufferedReader(new InputStreamReader(System.in));



  List<Player> pl=new ArrayList<>();



  System.out.println("Enter the number of the players");



  int n1=Integer.parseInt(br.readLine());



  for(int i=1;i<=n1;i++)



  {



   System.out.println("Enter details of player "+i);



   System.out.println("Enter the player name:");



   n=br.readLine();



   System.out.println("Enter the team name:");



    t=br.readLine();



    System.out.println("Enter the skill:");



    sk=br.readLine();



    Player p=new Player(n,t,sk);



    pl.add(p);



  }



  FileUtility f=new FileUtility();



  f.writeData(pl);



 }



}