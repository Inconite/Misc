create database shipping;
use shipping;
CREATE TABLE bab_customer
(customer_ID int PRIMARY KEY,customer_name VARCHAR(30)NOT NULL,
billing_address VARCHAR(30)NOT NULL,city varchar(20) NOT NULL,
state varchar(20) NOT NULL,country varchar(20) NOT NULL,
postal_code int(10) NOT NULL,phone_number int(12) NOT NULL);

select * from bab_customer;

insert into bab_customer values(11,'Amol','ganpati Nagar','Beed','MH','India',431122,1234567890);
insert into bab_customer values(12,'Aziz','nashik Nagar','Nashik','MH','India',431112,1111567890); 
insert into bab_customer values(13,'Gunratan','ballarsha Nagar','chandrapur','MH','India',431132,1122567890);
insert into bab_customer values(14,'Swapnil','aurangpura','Aurangabad','MH','India',431142,1112567890);

CREATE TABLE bab_orders
(order_ID int PRIMARY KEY,employee_id int NOT NULL,
order_date VARCHAR(10) NOT NULL,purchase_order_no int NOT NULL,
ship_name varchar(20) NOT NULL,ship_address varchar(20) NOT NULL,
ship_city varchar(20) NOT NULL,ship_state varchar(20) NOT NULL,
ship_postal_code int(10) NOT NULL,ship_country varchar(20) NOT NULL,
ship_phone_number int(12) NOT NULL,ship_date varchar(20) NOT NULL,
frieght_charge int NOT NULL,sales_tax int NOT NULL);

select * from bab_orders;
insert into bab_orders values(21,31,'2013-08-25',101,'asdf','abc, pune','pune','mh',123456,'india',43211212,'2013-08-25',500,5);
insert into bab_orders values(22,31,'2013-08-24',101,'asdf','abc, pune','beed','mh',1234,'india',43211212,'2013-08-25',400,4);
insert into bab_orders values(23,32,'2013-08-23',101,'asdf','abc, pune','aurangabad','mh',123,'india',43211212,'2013-08-24',300,5);
insert into bab_orders values(24,33,'2013-08-24',101,'asdf','abc, pune','nashik','mh',123444,'india',43211212,'2013-08-24',200,4);
insert into bab_orders values(25,33,'2013-08-23',101,'asdf','abc, pune','pune','mh',123456,'india',43211212,'2013-08-23',100,6);


CREATE TABLE bab_employee
(employee_ID int PRIMARY KEY,first_name VARCHAR(30)NOT NULL,
last_name VARCHAR(30)NOT NULL,email varchar(20) NOT NULL,
mobile_number int(12) NOT NULL);

select * from bab_employee;
insert into bab_employee values(31,'xyz','pqr','a@a.com',12345);
insert into bab_employee values(32,'abc','stu','b@a.com',123456);
insert into bab_employee values(33,'def','vwx','c@a.com',123457);
insert into bab_employee values(34,'ghi','yz','d@a.com',123458);

CREATE TABLE bab_payments
(payment_ID int PRIMARY KEY,order_id int NOT NULL,
payment_amount int NOT NULL,payment_date varchar(10) NOT NULL,
payment_type varchar(20) NOT NULL);

select * from bab_payments;
insert into bab_payments values(1001,21,1000,'2013-08-25','cash');
insert into bab_payments values(1002,22,5000,'2013-08-26','cash');
insert into bab_payments values(1003,23,4000,'2013-08-25','cash');
insert into bab_payments values(1004,24,3000,'2013-08-25','cash');
insert into bab_payments values(1005,25,2500,'2013-08-25','cash');


CREATE TABLE bab_order_details
(orderdetail_id int PRIMARY KEY,order_ID int,product_id int NOT NULL,
quantity int NOT NULL,unit_price int NOT NULL,
discount int NOT NULL,customer_id int);
select * from bab_order_details;
insert into bab_order_details values(2001,21,501,10,500,2,11);
insert into bab_order_details values(2002,22,502,100,100,3,12);
insert into bab_order_details values(2003,23,503,110,200,4,11);
insert into bab_order_details values(2004,24,504,310,10,5,14);
insert into bab_order_details values(2005,25,505,410,50,2,13);
insert into bab_order_details values(2006,23,501,50,50,2,13);
insert into bab_order_details values(2007,21,503,30,60,4,11);
insert into bab_order_details values(2008,23,504,10,40,5,11);


CREATE TABLE bab_order_products
(product_id int PRIMARY KEY,product_name varchar(20),
category varchar(20) NOT NULL,unit_price int NOT NULL,
discount int NOT NULL );

select * from bab_order_products;
insert into bab_order_products values(501,'PEN','stationary',500,2);
insert into bab_order_products values(502,'PENcil','stationary',100,3);
insert into bab_order_products values(503,'Lipstick','cosmetic',200,4);
insert into bab_order_products values(504,'Pd','electronics',10,5);
insert into bab_order_products values(505,'Laptop','electronics',50,2);

show tables;
select * from bab_customer;
select * from bab_orders;
select * from bab_employee;
select * from bab_payments;
select * from bab_order_details;
select * from bab_order_products;

#drop table bab_order_details;

display customer id,name,billing address ,product name,quantity,price,order date and employee who deliver order
2.  display customer id, name who ordered maximum no of  item/minimum
3.  display customer who booked same item more than 2 times
4.  display customer who spent max amount on items
5.  display customer with his order date,shipdate and payment date,paymewnt amount,payment type


6.  display customer id and name, product name and price who take more than 50 (quantity)items
8.  display customer who take product of type stationary and 
    whose order in the month of aug 2013 and payment is more then 5000
9.  display order id, product name ,category ,unit price who take 1 day whole for order shipping
    (diff between order date and ship date)
10  display customer name,id whose city and ship city is same
11  display all order id, order date and payment which is deliver by employee whose first and last
    name start with 'X'
12  display all product id,name along with total income(sum of payment)
13  display customer id, order id, product name which having payment on 25-08-2013




select c.customer_id,c.customer_name,c.billing_address,p.product_name,p1.quantity,p1.unit_price,b1.order_date,e1.first_name from bab_customer c inner join bab_order_details p1 on c.customer_id=p1.customer_id inner join bab_order_products p on p.product_id=p1.product_id inner join bab_orders b1 on b1.order_id=p1.order_id inner join bab_employee e1 on b1.employee_id=e1.employee_id; 

select c.customer_id,c.customer_name from bab_customer c inner join bab_order_details p1 
on c.customer_id=p1.customer_id group by p1.customer_id having count(p1.order_id)
in(select max(a) from (select count(order_id) a from bab_order_details group by customer_id)b) union 

select c.customer_id,c.customer_name from bab_customer c inner join bab_order_details p1 
on c.customer_id=p1.customer_id group by p1.customer_id having count(p1.order_id)
in(select min(a) from (select count(order_id) a from bab_order_details group by customer_id )b); 

wrong------
//select c.customer_name from bab_customer c inner join bab_order_details p1 on p1.customer_id=c.customer_id 
group by c.customer_id,p1.order_id having count(p1.order_id) >2;

correct-------
select customer_id,count(product_id)-count(distinct product_id) from bab_order_details group by customer_id having count(product_id)-count(distinct product_id)>=1;




select c.customer_id,c.customer_name from bab_customer c inner join bab_order_details p1 on c.customer_id=p1.customer_id 
where quantity*unit_price in(select max(a) from(select (quantity*unit_price) a from bab_order_details group by customer_id)b)group by p1.customer_id;

select b1.order_date,b1.ship_date,p2.payment_date,p2.payment_amount,p2.payment_type from bab_orders b1 inner join bab_payments p2 on b1.order_id=p2.order_id;

select c.customer_id,c.customer_name,p.product_name,p.unit_price 
from bab_customer c 
inner join bab_order_details p1 
on c.customer_id=p1.customer_id 
inner join bab_order_products p 
on p.product_id=p1.product_id 
where p1.quantity>50;


select c.customer_name from bab_customer c 
inner join bab_order_details p1 on p1.customer_id=c.customer_id 
inner join bab_order_products p on p.product_id=p1.product_id 
inner join bab_orders b1 on b1.order_id=p1.order_id 
where p.category='stationary' and date_format(b1.order_date,'%Y %m')='2013 08'
and p1.quantity*p1.unit_price>5000; 


select b1.order_id,p.product_name,p.category,p.unit_price 
from bab_orders b1 inner join bab_order_details p1 
on b1.order_id=p1.order_id inner join bab_order_products p 
on p.product_id=p1.product_id where datediff(b1.ship_date,b1.order_date)=1;

select c.customer_name,c.customer_id,c.city,b1.ship_city from bab_customer c 
inner join bab_order_details p1 on c.customer_id=p1.customer_id
inner join bab_orders b1 on b1.order_id=p1.order_id
where c.city =b1.ship_city;


select b1.order_id,b1.order_date,p2.payment_amount,e1.first_name 
from bab_orders b1 inner join bab_payments p2 
on b1.order_id=p2.order_id inner join
bab_employee e1 on e1.employee_id=b1.employee_id 
where e1.first_name like 'X%' and e1.last_name='X%';


select p.product_id,p.product_name,sum(p1.quantity*p1.unit_price) from bab_order_products p 
inner join bab_order_details p1 on p1.product_id=p.product_id 
inner join bab_payments p2 on p2.order_id=p1.order_id group by p1.product_id; 


select p1.customer_id,p1.order_id,p.product_name from bab_order_details p1 
inner join bab_order_products p on p.product_id=p1.product_id 
inner join bab_payments p2 on p2.order_id=p1.order_id 
where p2.payment_date="2013-08-25";






