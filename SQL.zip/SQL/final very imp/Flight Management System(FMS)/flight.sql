create database fms; 
use fms; 
create  table  Passenger 
( 
        passid int primary key, 
        passname varchar(20), 
        passemail varchar(20), 
        passdob date 
); 
create table Flight 
( 
        flightid int primary key, 
        flightsource varchar(20), 
        flightdest varchar(20), 
        flightdate datetime, 
        flightseat int(4), 
        ticketcost float 
); 
create table Booking 
( 
        bookingid int primary key, 
        flightid int, 
        bookdate date, 
        foreign key(flightid) references Flight(flightid) 
); 
create table Booking_details 
( 
        bookingid int, 
        passid int, 
        primary key(bookingid,passid), 
        foreign key(bookingid) references Booking(bookingid), 
        foreign key(passid) references Passenger(passid) 
); 

Insert into Passenger values(1,'Rajesh','raj@y.com','1980-12-01'); 
Insert into Passenger values(2,'hira','hira@y.com','1939-11-11'); 
Insert into Passenger values(3,'sita','sita@y.com','1988-02-06'); 
Insert into Passenger values(4,'mica','mica@y.com','1973-09-18'); 
Insert into Passenger values(5,'elizabeth','eliza@y.com','1976-05-09'); 
Insert into Passenger values(6,'kaushik','kaushik@y.com','1955-08-08'); 
Insert into Flight values(1,'kol','hyd','2012-12-01 22:09:01.340',100,2000.00); 
Insert into Flight values(2,'chen','hyd','2012-12-02 22:09:01.340',100,3000.00); 
Insert into Flight values(3,'pune','kol','2012-12-02 22:09:01.340',100,2500.00); 
Insert into Flight values(4,'bangalore','pune','2012-12-03 22:09:01.340',100,2300.00); 
Insert into Flight values(5,'hyd','bangalore','2012-12-05 22:09:01.340',100,2600.00); 
Insert into Flight values(6,'pune','hyd','2012-12-03 22:09:01.340',100,2000.00); 
Insert into Flight values(7,'pune','kol','2012-12-04 22:09:01.340',100,2900.00); 
Insert into Flight values(8,'kol','hyd','2012-12-06 22:09:01.340',100,3500.00); 
Insert into Booking values(1,1,'2012-12-01'); 
Insert into Booking values(2,3,'2012-12-02'); 
Insert into Booking values(3,4,'2012-12-03'); 
Insert into Booking values(4,5,'2012-12-04'); 
Insert into Booking values(5,4,'2012-12-02'); 
Insert into Booking values(6,1,'2012-12-02'); 
Insert into Booking values(7,3,'2012-12-02'); 
Insert into Booking_Details values(1,1); 
Insert into Booking_Details values(1,2); 
Insert into Booking_Details values(1,3); 
Insert into Booking_Details values(2,4); 
Insert into Booking_Details values(3,5); 
Insert into Booking_Details values(3,6); 
Insert into Booking_Details values(4,1); 
Insert into Booking_Details values(5,2); 
Insert into Booking_Details values(5,3); 
Insert into Booking_Details values(5,4);

1.
Display passenger name who has a 'e' as second letter in their name 

select passname from passenger where passname like '_e%'

2.
Display the name of the youngest passenger
select passname from passenger where passdob=(select max(passdob) from passenger)

3.
select passname,passdob,round(datediff(current_date,passdob)/365)"age"
from passenger

select passname,passdob, year(curdate())-year(passdob) from passenger;
4.
select count(flightid) from flight where flightsource='kol'

5.select flightsource from 
(select count(flightsource) source,flightsource from flight group by flightsource) a join
(select count(flightdest) dest,flightdest from flight group by flightdest) b where source=dest and 
flightsource=flightdest

select flightsource from (select flightdest,count(flightid) a from flight group by flightdest) d  join
(select flightsource,count(flightid) b from flight group by flightsource) s
on(d.flightdest=s.flightsource) where d.a=s.b

6.
select flightsource from (select distinct flightsource from flight)a left join
(select distinct flightdest from flight)b on(b.flightdest=a.flightsource) where b.flightdest is null;

select flightsource from (select flightdest from flight) d right join
(select flightsource from flight)s on(d.flightdest=s.flightsource) where d.flightdest is null

7.
Display the dates on which flight 1 and 4 is flying

select flightdate from flight where flightid=1 or flightid=4

8.
Display the number of passenger in each flight. Use column
 alias “PassCount”. 
select flightid, count(passid) from booking join booking_details using(bookingid) group by flightid

select flightid,count(bookingid)"PassCount" from booking group by flightid

9.
Display the name and date of birth of passengers who are senior 
citizen (age>=60). 
select passid,passname,passdob from passenger where year(curdate())-year(passdob)>60

select passname,passdob from passenger join (select passid,
round(datediff(current_date,passdob)/365) age from passenger) s 
using(passid) where age>=60

10.
Display the booking id having the highest number of passengers
select bookingid,count(passid) from booking_details group by bookingid having count(passid)=
(select max(count) from (select count(passid) count from booking_details group by bookingid) a);

select bookingid from booking_details group by bookingid having count(passid)=( select max(a) from(select count(passid) a from booking_details group by bookingid)b)

11.
Display the booking id (ticket) and the total cost for the booking. 
Use column alias “Total Fare”.

select bookingid,count*ticketcost from booking left join
(select bookingid ,count(passid) count from booking_details group by bookingid)a 
using(bookingid) join flight using(flightid)



select bookingid,p*ticketcost as "Total Fare"from booking b left  join
(select bookingid,count(passid) p from booking_details group by bookingid) bi 
using(bookingid) join flight f using(flightid)

12.
Display the booking id (ticket) and the total cost for the booking. 
Use column alias “Total Fare”. 
Consider giving a rebate of 50% to senior citizen (age>=60). 

select bi bookingid,sum(fare) from
(select d.bookingid bi ,if(age>=60,ticketcost*.5,ticketcost) fare,passid,age from 
booking b join booking_details d using(bookingid)
 join flight f using(flightid) join (select passid,year(curdate())-year(passdob) age 
from passenger) p using(passid)) g group by bi

select bookingid,sum(fare)from 
(select d.bookingid bookingid,if(age>=60,ticketcost*0.5,ticketcost) fare,d.passid,age from 
booking b join booking_details d using(bookingid)
join flight f using(flightid) join (select p.passid,year(curdate())-year(passdob) age 
from passenger p) aa using(passid)) bb group by bookingid

select bookingid,count(passid), from booking b left join booking_details d using(bookingid) join flight f using(flightid) join (select passid,round(datediff(current_date,passdob)/365) age from passenger) p
using(passid) group by bookingid

13.
Display the city receiving the maximum number of flights

select flightdest from flight group by flightdest having count(flightid)=
(select max(a) from (select count(flightid) a from flight group by flightdest)b)


select flightdest from flight group by flightdest having count(flightid)=(select max(count)
 from (select count(flightid) count,flightdest from flight
 group by flightdest)a)
14.
Display the passenger’s name having more than 1 booking

select passname from passenger join (select passid ,count(bookingid) from booking_details 
group by passid having count(bookingid)>1)a using(passid)

select passname from passenger join (select passid,count(bookingid) a from booking_details group by passid) s using(passid) where a>1

15.
Display flightid with no of booking

select flightid,count(bookingid) from booking group by flightid

16.
Display the passenger (name only) who booked ticket on the day of flight for flight no 1

select passname from passenger where passid in(select passid from booking left join
 booking_details using(bookingid) join flight f using(flightid) 
where bookdate=flightdate and flightid=1)


17.
Display flights having the same source and destination

select f.flightid from flight f cross join flight f1 where f.flightid!=f1.flightid
 and f.flightsource=f1.flightsource and f.flightdest=f1.flightdest

select f.flightid from flight f cross join flight f1 where f.flightid!=f1.flightid and f.flightdest=f1.flightdest
and f.flightsource=f1.flightsource;

18.
Display the record in the following format. Column alias 
“Booking Summary” 
Hints: 
“ Ticket No:1 Flight id: 1 Total Passengers :3 Total Fare:6000” 
“Ticket No:2 Flight id: 3 Total Passengers :1 Total Fare :2500” 

select concat('Ticket No:',bookingid,' Flight id:',flightid,
' Total Passengers:',pass,' Total Fare',pass*ticketcost)"Booking Summary" 
from booking b join (select bookingid,count(passid) pass 
from booking_details group by bookingid) bi using(bookingid) join flight f using(flightid)



19.
Flight No: 2 have been delayed for 4 hrs due to fog. Display flight id , flight date and a new column “flight new date”, which displays the new timing
select flightid,flightdate,adddate(flightdate,interval 4 hour)"flight_new_date" from flight where flightid='2'

20.
Display passenger name , date of birth sorted by the month of birth (Jan ? Dec).

select passname,passdob from passenger order by month(passdob)