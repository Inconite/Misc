use efs_db;
select * from batches;
select * from courseandmodules;
select * from courses;
select * from modules;
select * from students;
select * from trainers;

#1)Write a query which displays the module code and the duration for modules whose duration is less than 6.
select modulecode,duration from modules where duration<6;

#2)Write a query which will display the BATCHCODE, TRAINERID, COURSECODE, STARTDATE, CAPACITY and BATCHSTRENGTH of the batches handled by the trainer KRISHNAN.
select batchcode,trainerid,coursecode,startdate,capacity,batchstrength from batches where trainerid=(select trainerid from trainers where trainername='KRISHNAN');

#3)Write a query which displays all the module names of the course code 100.
select modulename from modules where modulecode in(select modulecode from courseandmodules where coursecode=100);

#4)Write a query which displays the module names and course code for the course code 100.
select a.modulename,b.coursecode from modules a,courseandmodules b where a.modulecode=b.modulecode and b.coursecode=100;

#5)Write a query which will display the number of modules present in the course code 100.
#Hint: display module name count with alias""NumberofModules"""
select count(modulecode) as NumberofModules from courseandmodules where coursecode=100;

#6)Write a query which will display all the course code and the number of modules present in that particular course.
#Hint: display module name count with alias""NumberofModules"""
select coursecode,count(modulecode) as NumberofModules from courseandmodules group by coursecode;

#7)Write a query which will display the course title and fees which has the maximum fees.
select title,fees from courses where fees=(select max(fees) from courses);

#8)Write a query which will display the student id, student name, batch code, place and phone number of the students who belongs to Batch '3001'.
select studentid,studentname,batchcode,place,phone from students where batchcode=3001;

#9)Write a Query which will display the student ID, Student name, Batch code, place and phone number who are from CHENNAI.
select studentid,studentname,batchcode,place,phone from students where place='CHENNAI';

#10)Write a query which displays the total number of modules which has less than 6 days duration.Hint: display total number of modules with'LESSTHANSIXDAYS' as alias.
select count(modulecode) as LESSTHANSIXDAYS from modules where duration<6;

#11)Write a query to display the batch code, course title, start date of the batches for the month of May and year 2012.
select a.batchcode,b.title,a.startdate from batches a,courses b where a.coursecode=b.coursecode and extract(month from startdate)=5 and extract(year from startdate)=2012;

#12)Write a query to display courses code, course title, course fees of the courses for which no batches/training has been planned in the month of January and year 2012.
select coursecode,title,fees from courses where coursecode not in(select coursecode from batches where extract(year from startdate)=2012 and extract(month from startdate)=1);

#13)Write a query which displays the names of all the modules of the course titled 'Oracle DBA'
select modulename from modules where modulecode in(select modulecode from courseandmodules where coursecode in(select coursecode from courses where title='Oracle DBA'));

#14)Write a Query which displays the student ID, Student name, Batch code, place and phone number of the student's who took training from CHENNAI in the year 2012.
select studentid,studentname,batchcode,place,phone from students where place='CHENNAI' and batchcode in( select batchcode from batches where extract(year from startdate)=2012);

#15)Write a query which will display the student id, student names who are enrolled for the course code 200
select studentid,studentname from students where batchcode in(select batchcode from batches where coursecode=200);

#16)Write a query which will display  studentid, studentname, batchcode, place and phone number of the students who is getting training from the trainer"SAI RAM"
select studentid,studentname,batchcode,place,phone from students where batchcode in(select batchcode from batches where trainerid in(select trainerid from trainers where trainername='SAI RAM'));

#17)Write a query which displays the course code and its total duration.
#Hint: display total duration with alias'DURATION'"
select a.coursecode,sum(b.duration) as DURATION from courseandmodules a,modules b where a.modulecode=b.modulecode group by a.coursecode;

#18)Write a query which will display the total duration of the course code 203
#Hint: display total duration with alias'DURATION'"
select a.coursecode,sum(b.duration) as DURATION from courseandmodules a,modules b where a.modulecode=b.modulecode group by a.coursecode having a.coursecode=203;

#19)Write a query which will display the total BATCHSTRENGTH of the batches handled by the trainer SAI RAM.
#Hint: display total Batch strength with alias 'TOTAL_STRENGTH'"
select sum(batchstrength) as TOTAL from batches where trainerid=(select trainerid from trainers where trainername='SAI RAM');

#20)Write a query to display batch code, batches utilization with alias'UTILIZATION' for all batches. Round the utilization to a 2 digit decimal number.Hint: Formula for calculating utilization 'utilization = (BATCHSTRENGTH/CAPACITY)*100'.
#Say for example if the utilization values is 33.3467  display this as 33.35% (Percentage should be displayed along with the values) Use alias 'UTILIZATION' for the calculated value"
select batchcode,round((batchstrength/capacity)*100,2) as UTILIZATION from batches;

#21)Write a query which displays the code, name and duration of the modules of the course title 'Oracle Developer'
select modulecode,modulename,duration from modules where modulecode in(select modulecode from courseandmodules where coursecode in(select coursecode from courses where title='Oracle Developer'));

#22)Write a query to display the id, name, batch code and place of the students who has taken training in the module 'CORE JAVA'.
select studentid,studentname,batchcode,place from students where batchcode in(select batchcode from batches where coursecode in(select coursecode from courseandmodules where modulecode in(select modulecode from modules where modulename='CORE JAVA')));

#23)Write a query which displays the trainer id, course code and number of times the trainer SAI RAM handled the Batches which has batch capacity greater than 5 and Batch strength greater than 5 and batch started in the year 2012 from the Batch details.
#Hint: display number of times trainer handled the course with alias as 'nooftimes'
select trainerid,coursecode,count(*) as nooftimes from batches where trainerid=(select trainerid from trainers where trainername='SAI RAM') and capacity>5 and batchstrength>5 and extract(year from startdate)=2012;

#24)Write a query which displays the trainer ID and number of batches of the trainer who has taken minimum number of batches.
#For example, assume trainer 'B' has taken only 1 batch which is the minimum number of batches taken compared to other trainers then displays his/her id, name and number of batches he has taken.
#Hint: display total number of batches with 'NumberofBatches' as alias.
select a.trainerid,a.trainername,count(b.batchcode) as NumberofBatches from trainers a,batches b where a.trainerid=b.trainerid group by a.trainerid having count(b.batchcode)=(select count(batchcode) from batches group by trainerid order by count(batchcode) limit 1);

#25)Write a query which displays the trainer ID and number of batches of the trainer who has taken more batches. <BR>For example, assume trainer'A' has taken 8 batches which is highest number of batches taken by the trainer compared to all other trainers then display his id and number of batches he has taken. <BR>Hint: display total number of modules with 'NumberofBatches' as alias.
select trainerid,count(batchcode) as NumberofBatches from batches group by trainerid having count(batchcode)=(select count(batchcode) from batches group by trainerid order by count(batchcode) desc limit 1);

