create database db_boats;
use db_boats;
create table sailors
(
 sid int, constraint pk_sid primary key(sid),
 sname varchar(20),
 rating int,
 age int
);
 
create table boats
(
 bid int,constraint pk_bid primary key(bid),
 bname varchar(20),
 color varchar(20)
);
 
create table reserves
(
sid int ,constraint fk_sid foreign key(sid) references sailors(sid),
bid int, constraint fk_bid foreign key(bid) references boats(bid),
day date
);
 
insert into sailors values(22,'dustin',7,45);
insert into sailors values(29,'brutus',1,39);
insert into sailors values(31,'lubber',9,55);
insert into sailors values(32,'andy',8,25);
insert into sailors values(58,'Rusty',10,35);
 
insert into boats values(101,'interlake','blue');
insert into boats values(102,'interlake','red');
insert into boats values(103,'clipper','green');
insert into boats values(104,'marine','red');
 
insert into reserves values(22,101,'2004-01-01');
insert into reserves values(22,102,'2004-01-01');
insert into reserves values(22,103,'2004-02-01');
insert into reserves values(31,103,'2005-05-01');
insert into reserves values(32,104,'2005-04-07');

select sname from sailors inner join reserves using(sid) join boats using(bid) where color='red';

select sname from sailors join reserves using(sid) join boats using(bid) where color='red';

select sname from sailors join reserves using(sid) join boats using(bid) where color='red' and sid in
(select sid from sailors join reserves using(sid) join boats using(bid) where color='green');

select sname from sailors join reserves using(sid) group by sid having count(bid)=1;

select sname from sailors join reserves using(sid) join boats using(bid) where color='red' and sid not in
(select sid from sailors join reserves using(sid) join boats using(bid) where color='green');

select sid,sname from sailors where rating in(select max(rating) a from sailors);

select sid,sname from sailors where age>=18;

select  sname ,count(sid) from sailors group by sname ;

select sname from sailors where age =(select max(age) from sailors);

select sname SAILORSNAME ,rating,age ,bname BOATSNAME, color,day  from
sailors join reserves r using(sid) join boats using(bid);

select sname from sailors where sname like 'a%' or sname in (select sname from sailors where 
sname like 'b%');

select sname from sailors where sid in (select sid from reserves group by sid);

select sid,rating,day from reserves join sailors using(sid) group by day having count(sid)=2;

select sname from sailors where sname like 'b%_%b';