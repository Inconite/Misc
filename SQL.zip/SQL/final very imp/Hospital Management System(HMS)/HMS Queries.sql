/*1) Display the patient_id, patient_name , phone number, ( if phone number is not there 
display address) for the people who are staying more then 10 days.*/
select r.pid,p.name,coalesce(convert(p.phoneno,char(10)),p.address)
from room_allocation r
inner join
patient_master p
on r.pid=p.pid
where extract(day from r.release_date)-extract(day from r.adm_date)>10;

/*
2)  Display the patient_id, patient_name, phone number( +91-999-999-9999 format) , type_of_ailment .
    type of ailement is decided with the number of days stay in hospital.
    if stay <=5   ---- Minor
    if stay >5 and <=15 days ----Medium
    if stay >15 days ---- Major*/
select r.pid,p.name,concat('+91','-',substring(phoneno,1,3),'-',substring(phoneno,4,3),'-',
substring(phoneno,7,4)),
(case when extract(day from r.release_date)-extract(day from r.adm_date)<=5 then 'Minor'
when extract(day from r.release_date)-extract(day from r.adm_date)-5 between 6 and 15 then 'Medium'
else 'Major'
end)
from room_allocation r
inner join
patient_master p
on r.pid=p.pid
where extract(day from r.release_date)-extract(day from r.adm_date)>10;
    
    
/*
3) Display the doctor_id and doctor name who is treating maximum patients.*/

select p.doctorid,d.doctorname from
patient_master p
inner join
doctor_master d
on p.doctorid=d.doctorid
group by doctorid
having count(p.doctorid)=
(
select max(did) from 
    (
    select count(doctorid) did from patient_master
    group by doctorid
    ) t1
);
/*4) Display the patients who were admitted in the month of january.*/

select pid from room_allocation
where date_format(adm_date,'%M')='January';

/*
5) Display the patient_id and patient_name who paid more then once.*/
select b.pid,p.name from bill_payment b
inner join
patient_master p
on b.pid=p.pid
group by b.pid
having count(b.pid)>1;

/*
6) Display the doctor_id, doctor_name and count of patients. Display the data in descending 
order of the cont_of_patients.*/
SELECT d.doctorid,d.doctorname,COUNT(P.PID) FROM PATIENT_MASTER P
INNER JOIN
DOCTOR_MASTER D
ON P.DOCTORID=D.DOCTORID
GROUP BY P.DOCTORID
ORDER BY COUNT(P.PID) DESC;

/*
7) Display the room_no, room_type which are allocated more then once.*/
select r.room_no,rm.room_type
from room_allocation r
inner join
room_master rm
on r.room_no=rm.room_no
group by room_no
having count(r.room_no)>1;

/*8) Display the room_no, room_type which are allocated more then once to the same patient.*/
select r.room_no,rm.room_type from room_allocation r
inner join
room_master rm
on r.room_no=rm.room_no
group by r.pid,r.room_no
having count(r.pid)>1;


select * from room_master;

insert into room_allocation
values('R0001','P0001','2013-01-01','2013-01-10');

/*
9) display the patient_id,patient_name, doctor_id, doctor_name, room_id, room_type, 
adm_date, bill_id, amount . Amount should be rounded of.*/

select p.pid,p.name,d.doctorid,d.doctorname,r.room_no,rm.room_type,r.adm_date,
b.billid,round(b.amount,0)
from 
patient_master p
inner join
doctor_master d
on p.doctorid=d.doctorid
inner join
room_allocation r
on r.pid=p.pid
inner join room_master rm
on r.room_no=rm.room_no
inner join
bill_payment b
on p.pid=b.pid
group by p.pid,r.room_no,b.billid;

/*
10) Display the patient_id, patient_name, billid, amount. Amount should be rounded of to single 
place of decimal.*/

select p.pid,p.name,b.billid,round(b.amount,1) from patient_master p
inner join
bill_payment b
on p.pid=b.pid;

/*
11) Display the room_no which was never allocated to any patient.*/
select room_no from room_master
where room_no not in (select distinct room_no from room_allocation);

/*
12) Display the the doctors_id who never treated any patients.*/

select doctorid from doctor_master
where doctorid not in (select distinct doctorid from patient_master);

/*
13) The depatment which are having the maximum number of doctors.*/
select * from doctor_master
group by dept
having count(dept)=
    (
        select max(dept) from
        (
            select  count(dept) dept from doctor_master
            group by dept
        ) t1
    );

/*
14) Count the number of male and female patients.*/
select 
    count(case gender when 'm' then gender end) no_of_males,
    count(case gender when 'f' then gender end) no_of_females
from patient_master;

select count(gender) from patient_master
group by gender;
/*
15) Count the %age of male and female
MALE 20% FEMALE 80%*/

select 
concat(
    converT(
        round(
            count(case gender when 'f' then gender end)
            /count(gender)*100
        ,0),
    char(10)),'%'),
concat(
    converT(
        round(
            count(case gender when 'm' then gender end)
            /count(gender)*100
        ,0),
    char(10)),'%')
from patient_master;