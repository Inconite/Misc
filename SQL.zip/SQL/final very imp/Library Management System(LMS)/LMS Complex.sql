/*Complex Questions:
Problem # 1:
Write a query to display the book code, book title and supplier name of the supplier 
who has supplied maximum number of books. For example, if “ABC Store” supplied 3 books, 
“LM Store” has supplied 2 books and “XYZ Store” has supplied 1 book. So “ABC Store” has 
supplied maximum number of books, hence display the details as mentioned below. 
Example:
BOOK_CODE	BOOK_TITLE	SUPPLIER_NAME
BL000008	Easy Reference for Java   	ABC STORE
BL000001	Easy Reference for C     	               ABC STORE
BL000003	Easy Reference for VB    	ABC STORE
*/
select 
lbd.book_code BOOK_CODE,lbd.book_title BOOK_TITLE,lsd.supplier_name SUPPLIER_NAME
from
lms_book_details lbd
inner join
lms_suppliers_details lsd
on
lbd.supplier_id=lsd.supplier_id
where lbd.supplier_id=
(
    select sid from
    (
        SELECT supplier_id sid, COUNT(supplier_id)   
        FROM lms_book_details 
        GROUP BY supplier_id   
        HAVING COUNT(supplier_id)=
        (   
            SELECT max(mycount) FROM 
            (   
                SELECT COUNT(supplier_id) mycount   
                FROM lms_book_details    
                GROUP BY supplier_id 
            ) c
        )
    ) c1
);

/*Problem # 2:
Write a query to display the member id, member name and number of remaining books he/she 
can take with “REMAININGBOOKS” as alias name. Hint:  Assuming a member can take maximum 3 books.  
For example, Ramesh has already taken 2 books; he can take only one book now. Hence display 
the remaining books as 1 in below format. 
Example: 
MEMBER_ID             MEMBER_NAME           REMAININGBOOKS
LM001                        RAMESH	                    1
LM002                        MOHAN	                    3
*/

select lbs.member_id MEMBER_ID,
lm.member_name MEMBER_NAME, 3-count(lbs.member_id) REMAININGBOOKS 
from
lms_book_details lbd 
inner join
lms_book_issue lbs
on lbd.book_code=lbs.book_code
inner join
lms_members lm
on lbs.member_id=lm.member_id
group by lbs.member_id;
/*Problem # 3 
Write a query to display the supplier id and supplier name of the supplier 
who has supplied minimum number of books. For example, if “ABC Store” supplied 3 books, 
“LM Store” has supplied 2 books and “XYZ Store” has supplied 1 book. So “XYZ Store” has 
supplied minimum number of books, hence display the details as mentioned below. 
Example:
SUPPLIER_ID	SUPPLIER_NAME
S04	               XYZ STORE
*/
select lsd.supplier_id SUPPLIER_ID,lsd.supplier_name SUPPLIER_NAME
from lms_book_details lbd
inner join
lms_suppliers_details lsd
on lbd.supplier_id=lsd.supplier_id
where lsd.supplier_id=
(
    select sid from
    (
        SELECT supplier_id sid, COUNT(supplier_id)   
        FROM lms_book_details 
        GROUP BY supplier_id   
        HAVING COUNT(supplier_id)=
        (   
            SELECT min(mycount) FROM 
            (   
                SELECT COUNT(supplier_id) mycount   
                FROM lms_book_details    
                GROUP BY supplier_id 
            ) c
        )
    ) c1
);

