create database db_pms;
use db_pms;

CREATE TABLE PMS_DEPARTMENT_DETAILS
(DEPARTMENT_ID int(2)PRIMARY KEY,
DEPARTMENT_NAME VARCHAR(30)NOT NULL,
 DEPARTMENT_LOCATION VARCHAR(30)NOT NULL,
DEPARTMENT_EXTENSION int(3) NOT NULL);

CREATE TABLE PMS_MANAGER_DETAILS
(Manager_ID int(5) PRIMARY KEY,
Manager_Name VARCHAR(30) NOT NULL,
 Job VARCHAR(30) NOT NULL,
Boss_Code int(5),
Salary float(7,2) NOT NULL,
 Commission int(5),
DEPARTMENT_ID int(2)); 

CREATE TABLE PMS_UNIT_DETAILS
(UNIT_ID VARCHAR(2) PRIMARY KEY,
UNIT_NAME VARCHAR(30) NOT NULL,
 PIECE_WEIGHT VARCHAR(15) NOT NULL,
TOTAL_PIECES int(3) NOT NULL,
 UNIT_WEIGHT float(5,2) NOT NULL);

CREATE TABLE PMS_PRODUCT
(PRODUCT_ID VARCHAR(5) PRIMARY KEY,
PRODUCT_NAME VARCHAR(30) NOT NULL,
 DEPARTMENT_ID int(2));

CREATE TABLE PMS_PRODUCT_UNIT
(PRODUCT_ID VARCHAR(5),
UNIT_ID VARCHAR(2));

CREATE TABLE PMS_MANUFACTURING
(MANFATURE_ID VARCHAR(5) PRIMARY KEY,
PRODUCT_ID VARCHAR(5) NOT NULL,
 UNIT_ID VARCHAR(5) NOT NULL,
QUANTITY int(7) NOT NULL,
AVAILABILITY VARCHAR(3) NOT NULL,
PRODUCT_MANFACTURE_DATE DATE NOT NULL,
PRODUCT_EXPIRY_DATE DATE NOT NULL);


-- Tables created successfully

-- Delete constrains

ALTER TABLE PMS_MANAGER_DETAILS DROP CONSTRAINT FK_DEPARTMENT_ID1;

ALTER TABLE PMS_PRODUCT DROP CONSTRAINT FK_DEPARTMENT_ID2;

ALTER TABLE PMS_PRODUCT_UNIT DROP CONSTRAINT PK_Composite21;

ALTER TABLE PMS_PRODUCT_UNIT DROP CONSTRAINT FK_PRODUCT_ID1;

ALTER TABLE PMS_PRODUCT_UNIT DROP CONSTRAINT FK_UNIT_ID1;

ALTER TABLE PMS_MANUFACTURING DROP CONSTRAINT FK_PRODUCT_ID2;

ALTER TABLE PMS_MANUFACTURING DROP CONSTRAINT FK_UNIT_ID2;


-- Add Constraints

ALTER TABLE PMS_MANAGER_DETAILS ADD constraint FK_DEPARTMENT_ID1 foreign key(DEPARTMENT_ID) references PMS_DEPARTMENT_DETAILS(DEPARTMENT_ID);

ALTER TABLE PMS_PRODUCT ADD constraint FK_DEPARTMENT_ID2 foreign key(DEPARTMENT_ID) references PMS_DEPARTMENT_DETAILS(DEPARTMENT_ID);

ALTER TABLE PMS_PRODUCT_UNIT ADD constraint PK_Composite21 primary key(PRODUCT_ID,UNIT_ID);

ALTER TABLE PMS_PRODUCT_UNIT ADD constraint FK_PRODUCT_ID1 foreign key(PRODUCT_ID) references PMS_PRODUCT(PRODUCT_ID);


ALTER TABLE PMS_PRODUCT_UNIT ADD constraint FK_UNIT_ID1 foreign key(UNIT_ID) references PMS_UNIT_DETAILS(UNIT_ID);

ALTER TABLE PMS_MANUFACTURING ADD constraint FK_PRODUCT_ID2 foreign key(PRODUCT_ID) references PMS_PRODUCT(PRODUCT_ID);

ALTER TABLE PMS_MANUFACTURING ADD constraint FK_UNIT_ID2 foreign key(UNIT_ID) references PMS_UNIT_DETAILS(UNIT_ID);

-- PMS DML STATEMENTS

-- INSERT INTO PMS_DEPARTMENT_DETAILS TABLE
INSERT INTO PMS_DEPARTMENT_DETAILS VALUES(10,'MIS','HYDERABAD_ZONE_1',121);
INSERT INTO PMS_DEPARTMENT_DETAILS VALUES(20,'GHEE SECTION','ONGOLE',122);
INSERT INTO PMS_DEPARTMENT_DETAILS VALUES(30,'PROCESSING SECTION','RAJAMUNDRY',123);
INSERT INTO PMS_DEPARTMENT_DETAILS VALUES(40,'BI_PRODUCTS SECTION','SECUNDERABAD',124);
INSERT INTO PMS_DEPARTMENT_DETAILS VALUES(50,'DISPATCH SECTION','HYDERABAD_ZONE_2',125);
INSERT INTO PMS_DEPARTMENT_DETAILS VALUES(60,'CUSTOMER CARE SECTION','HYDERABAD_ZONE_2',126);


-- INSERT INTO  PMS_MANAGER_DETAILS TABLE
INSERT INTO PMS_MANAGER_DETAILS VALUES(7711,'BLAKE','GENERAL MANAGER',NULL,25000,2500,10);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7722,'LARANCE','DEPUTY GENERAL MANAGER',7711,28000,1500,10);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7733,'GATES','MANAGER',7722,26750,500,20);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7744,'CALRK','MANAGER',7722,22000,1000,30);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7755,'VINCY','MANAGER',7722,17500,0,40);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7766,'GALE','MANAGER',7722,16500,0,50);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7770,'NANCY','ASSISTANT MANAGER',7733,30000,500,20);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7771,'GOUD','ASSISTANT MANAGER',7744,23000,750,30);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7772,'NAIDU','ASSISTANT MANAGER',7755,18500,0,40);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7773,'RAO','ASSISTANT MANAGER',7766,15000,3000,50);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7774,'RAJU','ASSISTANT MANAGER',7722,21050,2000,10);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7775,'REDDY','ASSISTANT MANAGER',7722,28500,0,10);

-- INSERT INTO PMS_UNIT_DETAILS TABLE
INSERT INTO PMS_UNIT_DETAILS VALUES('C1','CARTON','235 ML/GMS',20,5);
INSERT INTO PMS_UNIT_DETAILS VALUES('M1','MIN_BOX','25 GMS',20,.5);
INSERT INTO PMS_UNIT_DETAILS VALUES('M2','MAX_BOX','25 GMS',40,1);
INSERT INTO PMS_UNIT_DETAILS VALUES('C2','CAN','19.7 KGS',1,20);
INSERT INTO PMS_UNIT_DETAILS VALUES('T1','TIN','30 GMS',50,1.5);
INSERT INTO PMS_UNIT_DETAILS VALUES('P1','PACK','980 ML',1,1);
INSERT INTO PMS_UNIT_DETAILS VALUES('P2','HALF_PACK','480 ML/GMS',1,0.5);
INSERT INTO PMS_UNIT_DETAILS VALUES('P3','CHOTA_PACK','235 ML/GMS',1,0.25);

-- INSERT INTO PMS_PRODUCT TABLE

INSERT INTO PMS_PRODUCT VALUES('P001','MIXED GHEE',20);
INSERT INTO PMS_PRODUCT VALUES('P002','PANNER',20);
INSERT INTO PMS_PRODUCT VALUES('P003','COOKING BUTTER',20);
INSERT INTO PMS_PRODUCT VALUES('P004','RASAGULLA',40);
INSERT INTO PMS_PRODUCT VALUES('P005','CURD',40);
INSERT INTO PMS_PRODUCT VALUES('P006','DIET MILK',30);
INSERT INTO PMS_PRODUCT VALUES('P007','TONNED MILK',30);
INSERT INTO PMS_PRODUCT VALUES('P008','FAMILY MILK',30);
INSERT INTO PMS_PRODUCT VALUES('P009','STANDERED MILK',30);
INSERT INTO PMS_PRODUCT VALUES('P010','WHOLE MILK',30);
INSERT INTO PMS_PRODUCT VALUES('P011','BUTTER MILK',40);
INSERT INTO PMS_PRODUCT VALUES('P012','DOODH PEDA',40);
INSERT INTO PMS_PRODUCT VALUES('P013','MILK SHAKE',40);

-- INSERT INTO PMS_PRODUCT_UNIT TABLE

INSERT INTO PMS_PRODUCT_UNIT  VALUES('P001','C2');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P001','P2');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P001','P3');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P001','P1');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P002','C1');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P002','P1');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P002','P2');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P002','P3');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P006','P1');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P006','P2');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P006','P3');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P007','P1');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P007','P2');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P007','P3');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P008','P1');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P008','P2');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P008','P3');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P009','P1');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P009','P2');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P009','P3');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P010','P1');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P010','P2');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P010','P3');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P003','P2');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P003','P3');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P004','T1');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P005','P3');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P011','P3');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P012','M1');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P012','M2');
INSERT INTO PMS_PRODUCT_UNIT  VALUES('P013','C1');


-- INSERT INTO PMS_MANUFACTURING TABLE

INSERT INTO PMS_MANUFACTURING VALUES('M001','P001','C2',100,'YES','12-08-15','12-12-15');
INSERT INTO PMS_MANUFACTURING VALUES('M002','P001','P2',500,'YES','12-08-10','12-12-15');
INSERT INTO PMS_MANUFACTURING VALUES('M003','P001','P3',250,'YES','12-08-10','12-12-15');
INSERT INTO PMS_MANUFACTURING VALUES('M004','P001','P1',300,'NO','12-08-15','12-12-15');
INSERT INTO PMS_MANUFACTURING VALUES('M005','P002','C1',190,'YES','12-08-05','12-08-31');
INSERT INTO PMS_MANUFACTURING VALUES('M006','P002','P1',500,'YES','12-08-05','12-08-31');
INSERT INTO PMS_MANUFACTURING VALUES('M007','P002','P2',250,'YES','12-08-05','12-08-31');
INSERT INTO PMS_MANUFACTURING VALUES('M008','P002','P3',500,'YES','12-08-05','12-08-31');
INSERT INTO PMS_MANUFACTURING VALUES('M009','P006','P1',4500,'YES','12-08-15','12-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M010','P006','P2',7500,'YES','12-08-15','12-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M011','P006','P3',10000,'YES','12-08-15','12-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M012','P007','P1',4000,'YES','12-08-15','12-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M013','P007','P2',3000,'YES','12-08-15','12-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M014','P007','P3',2500,'YES','12-08-15','12-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M015','P008','P1',7000,'NO','12-08-15','12-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M016','P008','P2',3500,'YES','12-08-15','12-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M017','P008','P3',4500,'YES','12-08-15','12-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M018','P009','P1',1500,'NO','12-08-15','12-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M019','P009','P2',2500,'YES','12-08-15','12-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M020','P009','P3',1000,'YES','12-08-15','12-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M021','P010','P1',10000,'YES','12-08-15','12-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M022','P010','P2',25000,'YES','12-08-15','12-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M023','P010','P3',12500,'YES','12-08-15','12-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M024','P003','P2',2400,'YES','12-08-10','12-08-10');
INSERT INTO PMS_MANUFACTURING VALUES('M025','P003','P3',3210,'NO','12-08-10','12-10-10');
INSERT INTO PMS_MANUFACTURING VALUES('M026','P004','T1',750,'YES','12-08-10','12-12-10');
INSERT INTO PMS_MANUFACTURING VALUES('M027','P005','P3',10000,'YES','12-08-15','12-08-17');
INSERT INTO PMS_MANUFACTURING VALUES('M028','P011','P3',27500,'YES','12-08-15','12-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M029','P012','M1',2750,'YES','12-08-15','12-08-31');
INSERT INTO PMS_MANUFACTURING VALUES('M030','P012','M2',1850,'NO','12-08-15','12-08-31');
INSERT INTO PMS_MANUFACTURING VALUES('M031','P013','C1',1300,'YES','12-08-10','12-08-11');

select e.manager_id,e.manager_name,job,c.manager_name from pms_manager_details e join 
(select s.manager_name, a.manager_id from pms_manager_details s join pms_manager_details a 
where s.manager_id=a.boss_code) c using(manager_id);
 /*(or) this one fr 1st*/
select s.manager_id,s.manager_name ,s.job,m.manager_name from pms_manager_details s 
left join 
pms_manager_details m on m.manager_id=s.boss_code;

select manager_id,manager_name,job,salary,commission,department_id from pms_manager_details where salary=(
select max(salary) from pms_manager_details where salary<(select max(salary) from pms_manager_details));

select manager_id,manager_name ,job,salary from pms_manager_details where salary>
(select max(salary) from (select salary from pms_manager_details where manager_name
 like 'v%') s) and manager_name like '_A%';

select manager_id,manager_name ,job,salary*(7.5/100)*12 YEARLY_SALARY from pms_manager_details ;

select MANFATURE_ID, PRODUCT_NAME, UNIT_ID, QUANTITY, PRODUCT_MANFACTURE_DATE, PRODUCT_EXPIRY_DATE 
from pms_manufacturing join pms_product using(product_id) where product_name='mixed ghee';

select sum(quantity),product_id from pms_manufacturing group by product_id;

select count(product_id) COUNT_PRODUCT,product_id from pms_manufacturing where availability='yes' and 
PRODUCT_EXPIRY_DATE<'12-12-05' group by product_id;

select count(product_id)  COUNT_PRODUCT,product_id from pms_manufacturing where availability='no' and 
PRODUCT_EXPIRY_DATE<'12-12-05' group by product_id;

select manager_id,manager_name,job from pms_manager_details where salary>(select avg(salary)
from pms_manager_details) and job not in('manager');

select manager_id,concat(substr(upper(manager_name),1,1),substr(lower(manager_name),2)) manager_name,salary, department_id from pms_manager_details join pms_department_details
using(department_id) where salary >20000 order by department_name;

/*----AVERAGE---*/

select department_name,department_location from pms_department_details where department_id in
(select department_id from pms_manager_details group by department_id having count(manager_id)>=4);

select manager_id,manager_name from pms_manager_details where job =(select job from
 pms_manager_details group by job having avg(salary) =
(select max(avg) from (select avg(salary) avg from pms_manager_details group by job)a));

select manager_id,manager_name,job,salary,department_id ,avgsal from pms_manager_details join
(select department_id, avg(salary) avgsal from pms_manager_details group by department_id) a 
using(department_id) where salary>avgsal;

select product_id,product_name ,unit_id,unit_weight from pms_product join pms_product_unit 
using(product_id) join pms_unit_details using(unit_id) where product_name like'%milk';

select product_name,unit_name,total_pieces,unit_weight from pms_product join pms_product_unit
using(product_id) join pms_unit_details using(unit_id) group by product_id order by unit_weight;

select product_id ,sum(quantity) TOTAL_QUANTITY from pms_manufacturing where availability='yes'
 group by product_id having sum(quantity)>1500 ;

select m.product_id,product_name,department_id, count(unit_id) NUMBER_VARITIES from pms_manufacturing m 
join pms_product p using(product_id) where product_expiry_date='12-12-15' group by m.product_id;

select manager_id,manager_name from pms_manager_details where salary >(select avg(salary) from pms_manager_details join pms_department_details using(department_id)
where department_location='ONGOLE');

/*select manager_id,manager_name,job,salary from pms_manager_details;

select max(count) from (select count(manager_id) count,department_id from 
pms_manager_details group by department_id)a ;
*/
select department_id ,department_name from pms_department_details  where department_id not in 
(select distinct department_id from pms_manager_details);

/** complex**/

select manager_id,manager_name from pms_manager_details where salary =(select salary
 from pms_manager_details order by  salary desc limit 6,1);

select e.manager_id,e.manager_name,job,e.salary,c.manager_name from pms_manager_details e join 
(select s.manager_name, a.manager_id from pms_manager_details s join pms_manager_details a 
where s.manager_id=a.boss_code and s.salary<a.salary) c using(manager_id);

select monthname(product_manfacture_date) MONTH_NAME,count(unit_id) NUMBER_BATCHES from pms_manufacturing
group by month(PRODUCT_MANFACTURE_DATE );

/**select monthname(product_expiry_date),count(unit_id) from pms_manufacturing
group by month(PRODUCT_EXPIRY_DATE );

select year(PRODUCT_MANFACTURE_DATE)from pms_manufacturing;**/

select product_id,product_name,department_id from pms_product where product_id in
(select product_id from pms_manufacturing  group by product_id having sum(quantity) =
(select max(sum) from (select product_id ,sum(quantity) sum from pms_manufacturing 
group by product_id) a));

select product_id,product_name,count(manfature_id) from pms_manufacturing 
join pms_product using(product_id) group by product_id;

