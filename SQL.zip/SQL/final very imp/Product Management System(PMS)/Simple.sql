select m.manfature_id,p.product_name,m.unit_id,m.quantity,m.product_manfacture_date,m.product_expiry_date 
from pms_manufacturing m join pms_product p 
on m.product_id=p.product_id
where p.department_id=20;

select product_id,sum(quantity) from pms_manufacturing group by product_id;

select  pms_product.product_id,pms_product.product_name 
from pms_product join pms_manufacturing 
on pms_product.product_id=pms_manufacturing.product_id 
where pms_manufacturing.availability='yes' and 
(pms_manufacturing.product_manfacture_date<='2012-12-15' and pms_manufacturing.product_expiry_date>='2012-12-15');

select product_id,count(product_id) COUNT_PRODUCT 
from pms_manufacturing where (availability='no' AND product_expiry_date<='2012-12-15') group by product_id;

select manager_id,manager_name,job from pms_manager_details where job NOT IN ('manager') and
salary > (select avg(salary) from pms_manager_details where job='manager');

select manager_id,manager_name,department_id from pms_manager_details 
where salary > 20000 group by manager_name order by department_id;
