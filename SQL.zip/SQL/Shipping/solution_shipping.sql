create database shipping;
use shipping;
drop database shipping;
CREATE TABLE bab_customer 
(customer_ID int PRIMARY KEY, 
customer_name VARCHAR(30)NOT NULL, 
billing_address VARCHAR(30)NOT NULL, 
city varchar(20) NOT NULL, 
state varchar(20) NOT NULL, 
country varchar(20) NOT NULL, 
postal_code int(10) NOT NULL, 
phone_number int(12) NOT NULL); 

#select * from bab_customer; 

insert into bab_customer values(11,'Amol','ganpati Nagar','Beed','MH','India',431122,1234567890); 
insert into bab_customer values(12,'Aziz','nashik Nagar','Nashik','MH','India',431112,1111567890); 
insert into bab_customer values(13,'Gunratan','ballarsha Nagar','chandrapur','MH','India',431132,1122567890); 
insert into bab_customer values(14,'Swapnil','aurangpura','Aurangabad','MH','India',431142,1112567890); 


CREATE TABLE bab_employee 
(employee_ID int PRIMARY KEY, 
first_name VARCHAR(30)NOT NULL, 
last_name VARCHAR(30)NOT NULL, 
email varchar(20) NOT NULL, 
mobile_number int(12) NOT NULL); 

#select * from bab_employee; 
insert into bab_employee values(31,'xyz','xqr','a@a.com',12345); 
insert into bab_employee values(32,'abc','stu','b@a.com',123456); 
insert into bab_employee values(33,'xef','vwx','c@a.com',123457); 
insert into bab_employee values(34,'ghi','yz','d@a.com',123458); 


CREATE TABLE bab_orders 
(order_ID int PRIMARY KEY,
customer_ID int, 
employee_id int NOT NULL, 
order_date VARCHAR(10) NOT NULL, 
purchase_order_no int NOT NULL, 
ship_name varchar(20) NOT NULL, 
ship_address varchar(20) NOT NULL, 
ship_city varchar(20) NOT NULL, 
ship_state varchar(20) NOT NULL, 
ship_postal_code int(10) NOT NULL, 
ship_country varchar(20) NOT NULL, 
ship_phone_number int(12) NOT NULL, 
ship_date varchar(20) NOT NULL, 
frieght_charge int NOT NULL, 
sales_tax int NOT NULL, 
foreign key (customer_id) references bab_customer(customer_id),
foreign key (employee_id) references bab_employee(employee_id)
); 

#select * from bab_orders; 

insert into bab_orders values(21,11,31,'2013-08-25',101,'asdf','abc, pune','pune','mh',123456,
'india',43211212,'2013-08-25',500,5);

insert into bab_orders values(22,12,31,'2013-08-24',101,'asdf','abc, pune','beed','mh',1234,
'india',43211212,'2013-08-25',400,4);

insert into bab_orders values(23,11,32,'2013-08-23',101,'asdf','abc, pune','aurangabad','mh',123,
'india',43211212,'2013-08-24',300,5);

insert into bab_orders values(24,13,33,'2013-08-24',101,'asdf','abc, pune','nashik','mh',123444,
'india',43211212,'2013-08-24',200,4);

insert into bab_orders values(25,12,33,'2013-08-23',101,'asdf','abc, pune','pune','mh',123456,
'india',43211212,'2013-08-23',100,6);



CREATE TABLE bab_payments 
(payment_ID int PRIMARY KEY, 
order_id int NOT NULL, 
payment_amount int NOT NULL, 
payment_date varchar(10) NOT NULL, 
payment_type varchar(20) NOT NULL,
foreign key(order_id) references bab_orders(order_id)
); 

#select * from bab_payments; 
insert into bab_payments values(1001,21,1000,'2013-08-25','cash'); 
insert into bab_payments values(1002,22,5000,'2013-08-26','cash'); 
insert into bab_payments values(1003,23,4000,'2013-08-25','cash'); 
insert into bab_payments values(1004,24,3000,'2013-08-25','cash'); 
insert into bab_payments values(1005,25,2500,'2013-08-25','cash'); 

CREATE TABLE bab_order_products 
(product_id int PRIMARY KEY, 
product_name varchar(20), 
category varchar(20) NOT NULL, 
unit_price int NOT NULL, 
discount int NOT NULL); 

#select * from bab_order_products; 

insert into bab_order_products values(501,'PEN','stationary',500,2); 
insert into bab_order_products values(502,'PENcil','stationary',100,3); 
insert into bab_order_products values(503,'Lipstick','cosmetic',200,4); 
insert into bab_order_products values(504,'Pd','electronics',10,5); 
insert into bab_order_products values(505,'Laptop','electronics',50,2); 



CREATE TABLE bab_order_details 
(orderdetail_id int PRIMARY KEY, 
order_ID int, 
product_id int NOT NULL, 
quantity int NOT NULL, 
unit_price int NOT NULL, 
discount int NOT NULL, 
customer_id int,
foreign key(order_id) references bab_orders(order_id),
foreign key(product_id) references bab_order_products(product_id) ); 



#select * from bab_order_details; 
insert into bab_order_details values(2001,21,501,10,500,2,11); 
insert into bab_order_details values(2002,22,502,100,100,3,12); 
insert into bab_order_details values(2003,23,503,110,200,4,11); 
insert into bab_order_details values(2004,24,504,310,10,5,14); 
insert into bab_order_details values(2005,25,505,410,50,2,13); 
insert into bab_order_details values(2006,23,501,50,50,2,13); 
insert into bab_order_details values(2007,21,503,30,60,4,11); 
insert into bab_order_details values(2008,23,504,10,40,5,11); 
set session sql_mode='only_full_group_by';

/*
/* Query */ 
select * from bab_order_details;
select * from bab_order_products;
select * from bab_payments;
select * from bab_orders;
select * from bab_customer; 
select * from bab_employee;

/*1.  display customer id,name,billing address ,product name,quantity,price, 
order date and employee who deliver order */


select c.customer_id,c.customer_name,c.billing_address,op.product_name,od.quantity,od.unit_price,
o.order_date,e.first_name
from bab_customer c,bab_order_details od,bab_order_products op,bab_employee e,bab_orders o
where c.customer_id=o.customer_id and o.order_id=od.order_id and op.product_id=od.Product_id
and o.employee_id=e.employee_id;


/*2.  display customer id, name who ordered maximum no of  item/minimum */



select customer_id,customer_name from bab_customer where customer_id in
(select customer_id from bab_order_details  group by customer_id having count(customer_id)in
(select max(cnt) from (select count(customer_id) cnt from bab_order_details group by customer_id)count))
union
select customer_id,customer_name from bab_customer where customer_id in
(select customer_id from bab_order_details  group by customer_id having count(customer_id)in
(select min(cnt) from (select count(customer_id) cnt from bab_order_details group by customer_id)count));



/*3.  display customer who booked same item more than 2 times */

select * from bab_customer where customer_id in 
(select customer_id from 
bab_order_details group by customer_id, product_id 
having count(product_id) >=2);




/*4.  display customer who spent max amount on items */

select * from bab_customer c, bab_order_details od, bab_payments p
where c.customer_id=od.customer_id and od.order_id=p.order_id and p.payment_id in 
(select payment_id from bab_payments where payment_amount = 
(select max(payment_amount)from bab_payments));




/*5.  display customer with his order date,ship date and payment date,paymewnt amount,payment type */


select c.customer_id,c.customer_name,o.order_date,o.ship_date,p.payment_date,p.payment_amount,
p.payment_type 
from bab_customer c,bab_orders o,bab_payments p
where
c.customer_id=o.customer_id and o.order_id=p.order_id;



/*6.  display customer id and name, product name and price who take more than 50 (quantity)items*/


select * from bab_order_details;

select * from bab_order_products;

select x.customer_id,c.customer_name,p.product_name,p.unit_price from bab_order_products p inner join
(
select o.product_id,o.customer_id,sum(o.quantity) from bab_order_details o
group by o.product_id,o.customer_id
having sum(o.quantity)>50) x on x.product_id=p.product_id inner join
bab_customer c on c.customer_id=x.customer_id;

select o.product_id,o.customer_id,sum(o.quantity) from bab_order_details o
group by o.product_id,o.customer_id
having sum(o.quantity)>50;




 
/*8.  display customer who take product of type stationary and 
    whose order in the month of aug 2013 and payment is more then 5000 */

select c.customer_name from bab_customer c, bab_order_details od,
bab_payments p, bab_orders o, bab_order_products op
where c.customer_id=od.customer_id and od.order_id=o.order_id and o.order_id=p.order_id
and od.product_id=op.product_id and op.category='stationary' and p.payment_amount>=5000
and extract(month from (o.order_date))=8 and
extract(year from (o.order_date))=2013;


/* 9.  display order id, product name ,category ,unit price who take 1 day whole for order shipping 
    (diff between order date and ship date)*/

select o.order_id,op.product_name,op.category,op.unit_price
from bab_orders o, bab_order_products op, bab_order_details od
where op.product_id=od.product_id and od.order_id=o.order_id 
and datediff(o.ship_date,o.order_date)=1;


 
/*10  display customer name,id whose city and ship city is same */

select distinct c.customer_id , c.customer_name from bab_customer c, bab_orders o
where c.customer_id=o.customer_id and c.city=o.ship_city;




/*11  display all order id, order date and payment which is deliver by employee whose first and last 
    name start with 'X' */

select o.order_id, o.order_date,p.payment_amount,e.employee_id from
bab_employee e, bab_orders o, bab_payments p
where e.employee_id=o.employee_id and o.order_id=p.order_id
and e.first_name like 'x%' and e.last_name like 'X%';


/*
12  display all product id,name along with total income(sum of payment) 
*/

select  sum(x.payment) final,o.product_id from bab_order_details o inner join
(select sum(bp.payment_amount)payment, bp.order_id from bab_payments bp group by bp.order_id) x on
x.order_id=o.order_id group by o.product_id;

/*13  display customer id, order id, product name which having payment on 25-08-2013*/

select o.customer_id,o.order_id,op.product_name from 
bab_orders o join bab_payments p join bab_order_details od 
join bab_order_products op where o.order_id=p.order_id and 
o.order_id=od.order_id and od.product_id=op.product_id and p.payment_date 
like'2013-08-25';

/*
1
*/
#select * from bab_order_details;
select * from bab_order_products
having unit_price>(select avg(unit_price) from bab_order_products);

/*2 display the customer details who has no ship charges(frieght charges)*/

select * from
 bab_customer c join bab_ORDERS O ON O.CUSTOMER_ID=C.CUSTOMER_ID
 WHERE O.FRIEGHT_CHARGE=0; 




#SELECT * FROM BAB_ORDERS;
 
/* 3. */ 

SELECT * FROM 
BAB_CUSTOMER C jOIN BAB_ORDERS O JOIN BAB_PAYMENTS P 
ON O.ORDDER_ID=P.ORDER_ID AND C.CUSTOMER_ID=O.CUSTOMER_ID
WHERE P.ORDER_ID 
IN(
    SELECT ORDER_ID FROM 
		(SELECT ORDER_ID,SUM(PAYMENT_AMOUNT) TAMT FROM BAB_PAYMENTS GROUP BY ORDER_ID) TOT
	WHERE TAMT>2000
);
#USING(CUSTOMER_ID)
/*4  */
SELECT P.PRODUCT_ID,OD.QUANTITY 
FROM BAB_ORDER_PRODUCTS P JOIN BAB_ORDER_DETAILS OD ON P.PRODUCT_ID=OD.PRODUCT_ID;  

/*5 CUSTOMER DETAILS FROM CHENNAI*/

/*6 dISPLAY THE CATEGORY CONtAINING THE MAXIMUM NUMBER OF ELEMENTS*/
SELECT * FROM bab_order_DETAILS;
SELECT * FROM bab_order_products
WHERE PRODUCT_ID 
IN (
	SELECT PRODUCT_ID
		FROM bab_order_details where quantity =
			(SELECT MAX(QUANTITY)  FROM bab_order_details));

/**/
*/
