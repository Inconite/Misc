/* Query 

/*1.  display customer id,name,billing address ,product name,quantity,price,order date and 
employee who deliver order*/

select c.customer_id,c.customer_name,c.billing_address,
p.product_name,o.quantity,o.unit_price,bo.order_date,bo.employee_id
from bab_customer c
inner join
bab_order_details o
on c.customer_id=o.customer_id
inner join
bab_order_products p
on o.product_id=p.product_id
inner join
bab_orders bo
on bo.order_id=o.order_id;

/*2.  display customer id, name who ordered maximum no of  item/minimum*/

select od.customer_id,c.customer_name from bab_order_details od
inner join bab_customer c
on od.customer_id=c.customer_id
group by od.customer_id
having count(od.customer_id)
=
(
    select max(cid) from
    (
        select count(customer_id) cid from bab_order_details
        group by customer_id
    ) t1
);

/*3.  display customer who booked same item more than 2 times*/
select od.customer_id,C.CUSTOMER_NAME from bab_order_details od
inner join
bab_customer c
on od.customer_id=c.customer_id
group by od.customer_id,od.product_id
having count(od.product_id)>2;

/*4.  display customer who spent max amount on items*/

SELECT CUSTOMER_ID FROM BAB_ORDER_DETAILS
GROUP BY CUSTOMER_ID
HAVING SUM(UNIT_PRICE*QUANTITY)=
(
SELECT MAX(SPENT) FROM
(
    SELECT SUM(UNIT_PRICE*QUANTITY) SPENT FROM BAB_ORDER_DETAILS
    GROUP BY CUSTOMER_ID
) T1
);
/*5.  display customer with his order date,ship date and payment date,paymewnt amount,payment type*/
SELECT O.ORDER_DATE,O.SHIP_DATE,P.PAYMENT_DATE,P.PAYMENT_AMOUNT,P.PAYMENT_TYPE
FROM BAB_CUSTOMER C
INNER JOIN BAB_ORDER_DETAILS OD
ON C.CUSTOMER_ID=OD.CUSTOMER_ID
INNER JOIN BAB_ORDERS O
ON OD.ORDER_ID=O.ORDER_ID
INNER JOIN
BAB_PAYMENTS P
ON P.ORDER_ID=O.ORDER_ID;


/*6.  display customer id and name, product name and price who take more than 50 (quantity)items*/

SELECT C.CUSTOMER_ID,C.CUSTOMER_NAME,P.PRODUCT_NAME,OD.UNIT_PRICE,od.quantity
FROM BAB_CUSTOMER C
INNER JOIN
BAB_ORDER_DETAILS OD
ON C.CUSTOMER_ID=OD.CUSTOMER_ID
INNER JOIN BAB_ORDER_PRODUCTS P
ON P.PRODUCT_ID=OD.PRODUCT_ID
where quantity>50;

/*8.  display customer who take product of type stationary and 
    whose order in the month of aug 2013 and payment is more then 5000*/
SELECT c.customer_id,c.customer_name FROM BAB_CUSTOMER C
INNER JOIN BAB_ORDER_DETAILS OD
ON C.CUSTOMER_ID=OD.CUSTOMER_ID
INNER JOIN BAB_ORDER_PRODUCTS P
ON OD.PRODUCT_ID=P.PRODUCT_ID
INNER JOIN BAB_ORDERS O
ON OD.ORDER_ID=O.ORDER_ID
inner join bab_payments p1
on p1.order_id=o.order_id
where p.category='stationary'
AND DATE_FORMAT(O.ORDER_DATE,'%b %Y')='Aug 2013'
and p1.payment_amount>=5000;
    
/*9.  display order id, product name ,category ,unit price who take 1 day whole for order shipping
    (diff between order date and ship date)*/
select od.order_id,p.product_name,p.category,od.unit_price
from
bab_order_details od
inner join
bab_order_products p
on od.product_id=p.product_id
inner join bab_orders o
on o.order_id=od.order_id
where datediff(o.ship_date,o.order_date)=1
order by od.order_id;
 
/*10  display customer name,id whose city and ship city is same*/
select c.customer_name,c.customer_id from bab_order_details od
inner join
bab_orders o
on od.order_id=o.order_id
inner join bab_customer c
on od.customer_id=c.customer_id
where o.ship_city=c.city;

/*11  display all order id, order date and payment which is deliver by employee whose first and last
    name start with 'X'*/
    
select o.order_id,o.order_date,p.payment_amount from bab_orders o
inner join bab_payments p
on o.order_id=p.order_id
inner join bab_employee e
on o.employee_id=e.employee_id
where e.first_name like 'x%'
and e.last_name like 'x%';
/*12  display all product id,name along with total income(sum of payment)*/
select pr.product_id,pr.product_name,sum(p.payment_amount)
from bab_payments p
inner join
bab_order_details od
on p.order_id=od.order_id
inner join
bab_order_products pr
on od.product_id=pr.product_id
group by od.product_id;

/*13  display customer id, order id, product name which having payment on 25-08-2013*/

select od.customer_id,od.order_id,pr.product_name from bab_payments p
inner join
bab_order_details od
on p.order_id=od.order_id
inner join
bab_ordeR_products pr
on od.product_id=pr.product_id
where p.payment_date='2013-08-25';